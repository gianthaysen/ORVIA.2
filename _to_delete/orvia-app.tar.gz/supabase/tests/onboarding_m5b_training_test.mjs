/* ============================================================
   ORVIA · M5b — A2 Sportauswahl (Essential) + A3 Trainingsstand.
   Test-first (RED → GREEN). Verträge:
   - sports-logic: Entry-Erweiterung level/sessionsPerWeek (nur valide Werte,
     erhalten über alle Mutationen), TRAINING_LEVELS kanonisch,
     setTrainingLevel/setSessionsPerWeek, validateTrainingLevel,
     SESSION_BANDS (UI-Band ↔ Int-Mapping, dokumentiert, deterministisch).
   - onboarding-logic: neuer aktiver Essential-Step 'training_level' nach
     'sports' (required, nicht skippbar), advanceTrainingLevel fail-closed,
     Progress-Total 6, Resume-Migration alter Drafts (Lücke → Rückführung),
     Review-Voraussetzungen enthalten training_level.
   - onboarding-ui: buildCompletionPatch überträgt level/sessionsPerWeek in
     PROFILE.sports[primary]; A3-Renderer nutzt Kit + getProgress().
   node supabase/tests/onboarding_m5b_training_test.mjs
   ============================================================ */
import { readFileSync } from 'node:fs';
import { existsSync as _exApp } from 'node:fs';
import { dirname as _dH } from 'node:path';
import { fileURLToPath as _fH } from 'node:url';
const HERE = _dH(_fH(import.meta.url));
/* Layoutrobuste App-Basis: kanonisch liegt js/ unter HERE/../.., umstrukturiert unter HERE/../../app. */
const _APPREL = _exApp(new URL('../../js/', import.meta.url)) ? '../../' : '../../app/';

let pass = 0, fail = 0;
const ok = (n, c, i) => { console.log((c ? '✅' : '❌') + ' ' + n + (i ? '  — ' + i : '')); c ? pass++ : fail++; };
const wait = () => new Promise(r => setTimeout(r, 5));

globalThis.ORVIA = {};
const gWinEv = {};
globalThis.addEventListener = (t, fn) => { gWinEv[t] = fn; };
await import(new URL(_APPREL + 'js/onboarding/onboarding-profile-logic.js', import.meta.url));
await import(new URL(_APPREL + 'js/onboarding/onboarding-sports-logic.js', import.meta.url));
await import(new URL(_APPREL + 'js/onboarding/onboarding-logic.js', import.meta.url));
await import(new URL(_APPREL + 'js/onboarding/onboarding-steps.js', import.meta.url));
await import(new URL(_APPREL + 'js/onboarding/onboarding-store.js', import.meta.url));
await import(new URL(_APPREL + 'js/profile-ui-kit.js', import.meta.url));
await import(new URL(_APPREL + 'js/profile-model.js', import.meta.url));
await import(new URL(_APPREL + 'js/i18n.js', import.meta.url)); await import(new URL(_APPREL + 'locales/de.js', import.meta.url));   /* B-13: Katalog */
await import(new URL(_APPREL + 'js/onboarding/onboarding-ui.js', import.meta.url));

const SL = globalThis.ORVIA.onboardingSportsLogic;
const PL = globalThis.ORVIA.onboardingProfileLogic;
const L = globalThis.ORVIA.onboardingV2Logic;
const PM = globalThis.ORVIA.profileModel;
const Store = globalThis.ORVIA.onboardingV2Store;
const KIT = globalThis.ORVIA.profileUiKit;
const NOW = '2026-07-03T12:00:00.000Z';

const VALID_PROFILE = { displayName: 'Gian', birthDate: '2003-08-01' };
function selWithPrimary() { let s = SL.normalizeSportsSelection({}); s = SL.toggleSport(s, 'running'); s = SL.toggleSport(s, 'gym'); s = SL.setPrimarySport(s, 'running'); return s; }
function selComplete() { let s = selWithPrimary(); s = SL.setTrainingLevel(s, 'running', 'intermediate'); s = SL.setSessionsPerWeek(s, 'running', 4); s = SL.setTypicalDuration(s, 'running', 60); return s; }
function primaryOf(sel) { let p = null; (SL.normalizeSportsSelection(sel).sports || []).forEach(e => { if (e.role === 'primary') p = e; }); return p; }

/* ================= S — sports-logic Erweiterung ================= */
ok('S1 Export: TRAINING_LEVELS', Array.isArray(SL.TRAINING_LEVELS) && SL.TRAINING_LEVELS.length === 4);
ok('S2 TRAINING_LEVELS identisch mit profile-logic LEVELS (Cross-Contract)',
  JSON.stringify(SL.TRAINING_LEVELS || []) === JSON.stringify(['beginner', 'intermediate', 'advanced', 'competitive']));
['setTrainingLevel', 'setSessionsPerWeek', 'validateTrainingLevel', 'trainingLevelComplete', 'sessionsForBand', 'bandForSessions'].forEach(fn =>
  ok('S3 Export: ' + fn, typeof SL[fn] === 'function'));
if (typeof SL.setTrainingLevel !== 'function') { console.log('\nErgebnis: ' + pass + ' bestanden, ' + fail + ' fehlgeschlagen. (RED)'); process.exit(1); }

{ // S4: Entry-Normalisierung erhält valide Werte, verwirft invalide
  const n = SL.normalizeSportEntry({ sportId: 'running', role: 'primary', level: 'intermediate', sessionsPerWeek: 4 });
  ok('S4a normalizeSportEntry erhält level/sessionsPerWeek', n.level === 'intermediate' && n.sessionsPerWeek === 4);
  const bad = SL.normalizeSportEntry({ sportId: 'running', level: 'fortgeschritten', sessionsPerWeek: 15 });
  ok('S4b invalides level → null (kein Fremd-Namespace)', bad.level === null);
  ok('S4c sessionsPerWeek außerhalb 0–14 → null', bad.sessionsPerWeek === null);
  const bad2 = SL.normalizeSportEntry({ sportId: 'running', sessionsPerWeek: 'x' });
  ok('S4d sessionsPerWeek non-int → null', bad2.sessionsPerWeek === null);
}
{ // S5: Setter — nicht-mutierend, zielgenau
  const base = selWithPrimary();
  const before = JSON.stringify(base);
  const withLvl = SL.setTrainingLevel(base, 'running', 'advanced');
  ok('S5a setTrainingLevel setzt Ziel-Sport', primaryOf(withLvl).level === 'advanced');
  ok('S5b Quelle unverändert (nicht-mutierend)', JSON.stringify(base) === before);
  ok('S5c unbekannter Sport → unverändert', JSON.stringify(SL.setTrainingLevel(base, 'curling', 'advanced')) === before);
  ok('S5d invalides Level → unverändert', primaryOf(SL.setTrainingLevel(base, 'running', 'profi')).level === null);
  const withS = SL.setSessionsPerWeek(base, 'running', 6);
  ok('S5e setSessionsPerWeek setzt Int', primaryOf(withS).sessionsPerWeek === 6);
  ok('S5f sessions out-of-range → unverändert', primaryOf(SL.setSessionsPerWeek(base, 'running', 20)).sessionsPerWeek === null);
}
{ // S6: Werte überleben Mutationen; Primary-Wechsel überträgt NICHT
  let s = selComplete();
  s = SL.toggleSport(s, 'cycling');
  ok('S6a Werte überleben toggleSport', primaryOf(s).level === 'intermediate' && primaryOf(s).sessionsPerWeek === 4);
  const sw = SL.setPrimarySport(s, 'gym');
  const gym = sw.sports.filter(e => e.sportId === 'gym')[0];
  const run = sw.sports.filter(e => e.sportId === 'running')[0];
  ok('S6b Primary-Wechsel: neue Primary hat KEINE übernommenen Werte', gym.role === 'primary' && gym.level === null && gym.sessionsPerWeek === null);
  ok('S6c Alt-Primary behält ihre Werte (pro Sport, nicht global)', run.level === 'intermediate' && run.sessionsPerWeek === 4);
  const rt = SL.normalizeSportsSelection(SL.normalizeSportsSelection(s));
  ok('S6d Normalisierung idempotent inkl. neuer Felder', JSON.stringify(rt) === JSON.stringify(SL.normalizeSportsSelection(s)));
}
{ // S7: validateTrainingLevel
  const noPrim = SL.toggleSport(SL.normalizeSportsSelection({}), 'other'); // 'other' nie primary
  const v0 = SL.validateTrainingLevel(noPrim);
  ok('S7a ohne Primary → invalid + _primary', !v0.valid && !!v0.errors._primary);
  const v1 = SL.validateTrainingLevel(selWithPrimary());
  ok('S7b Primary ohne Angaben → _level UND _sessions', !v1.valid && !!v1.errors._level && !!v1.errors._sessions);
  const halb = SL.setTrainingLevel(selWithPrimary(), 'running', 'beginner');
  const v2 = SL.validateTrainingLevel(halb);
  ok('S7c nur Level → _sessions bleibt', !v2.valid && !v2.errors._level && !!v2.errors._sessions);
  const v3 = SL.validateTrainingLevel(selComplete());
  ok('S7d vollständig → valid', v3.valid && Object.keys(v3.errors).length === 0);
  ok('S7e trainingLevelComplete-Wrapper', SL.trainingLevelComplete(selComplete()) === true && SL.trainingLevelComplete(selWithPrimary()) === false);
}
{ // S8: Band-Mapping (dokumentierter Vertrag: 1-2→2 · 3-4→4 · 5-6→6 · 7plus→7)
  ok('S8a sessionsForBand', SL.sessionsForBand('1-2') === 2 && SL.sessionsForBand('3-4') === 4 && SL.sessionsForBand('5-6') === 6 && SL.sessionsForBand('7plus') === 7);
  ok('S8b sessionsForBand unbekannt → null', SL.sessionsForBand('x') === null);
  ok('S8c bandForSessions Rückweg', SL.bandForSessions(1) === '1-2' && SL.bandForSessions(2) === '1-2' && SL.bandForSessions(3) === '3-4' && SL.bandForSessions(4) === '3-4' && SL.bandForSessions(5) === '5-6' && SL.bandForSessions(6) === '5-6' && SL.bandForSessions(7) === '7plus' && SL.bandForSessions(11) === '7plus');
  ok('S8d bandForSessions null/0 → null (kein Default)', SL.bandForSessions(null) === null && SL.bandForSessions(0) === null);
}

/* ================= L — onboarding-logic ================= */
{
  const cfg = L.getStepConfig('training_level');
  ok('L1 STEP_CONFIG: training_level essential/required/aktiv/nicht skippbar',
    !!cfg && cfg.tier === 'essential' && cfg.required === true && cfg.skippable === false && cfg.countsTowardProgress === true && cfg.active === true);
  ok('L2 STEP_IDS-Reihenfolge: sports → training_level → goals (v4)',
    JSON.stringify(L.STEP_IDS) === JSON.stringify(['welcome', 'profile', 'sports', 'training_level', 'goals', 'availability', 'safety', 'body', 'review']));
  ok('L3 Progress-Total = 8 (M7)', L.getProgress(L.newDraft()).total === 8);
}
function draftAt(step, completed, dd) {
  const d = L.newDraft();
  d.status = 'in_progress'; d.currentStep = step;
  d.completedSteps = (completed || []).slice();
  // M6: Review-Voraussetzungen verlangen zusätzlich ein valides Essential-Ziel.
  d.draftData = Object.assign({ profile: Object.assign({}, VALID_PROFILE), sports: selComplete(), goals: PM.normalizeGoals([{ title: 'Halbmarathon', category: 'half_marathon', priority: 1 }]), availability: { days: { di: { available: true } } }, safety: { hasComplaints: false } }, dd || {});
  return d;
}
{ // L4/L5: advance-Gates
  const d = draftAt('sports', ['welcome', 'profile']);
  L.advance(d, NOW);
  ok('L4 advance auf sports (valide) → training_level', d.currentStep === 'training_level' && d.completedSteps.indexOf('sports') >= 0);
  const d2 = draftAt('training_level', ['welcome', 'profile', 'sports'], { sports: selWithPrimary() });
  L.advance(d2, NOW);
  ok('L5 advance auf training_level OHNE Daten → fail-closed (kein Weiter)', d2.currentStep === 'training_level' && d2.completedSteps.indexOf('training_level') < 0);
}
{ // L6–L9: advanceTrainingLevel
  ok('L6 Export advanceTrainingLevel', typeof L.advanceTrainingLevel === 'function');
  const wrong = L.advanceTrainingLevel(draftAt('sports', ['welcome', 'profile']), NOW);
  ok('L6b falscher Schritt → ok:false/_step', wrong && wrong.ok === false && !!wrong.errors._step);
  const inv = L.advanceTrainingLevel(draftAt('training_level', ['welcome', 'profile', 'sports'], { sports: selWithPrimary() }), NOW);
  ok('L7 invalide Daten → ok:false + Feldfehler, Position unverändert', inv.ok === false && !!inv.errors._level && inv.draft.currentStep === 'training_level');
  // Modulvertrag: fehlende Validierung → _module (fail-closed)
  const saved = SL.validateTrainingLevel; delete globalThis.ORVIA.onboardingSportsLogic.validateTrainingLevel;
  const noMod = L.advanceTrainingLevel(draftAt('training_level', ['welcome', 'profile', 'sports']), NOW);
  ok('L8 fehlendes Validator-Modul → _module', noMod.ok === false && !!noMod.errors._module);
  globalThis.ORVIA.onboardingSportsLogic.validateTrainingLevel = saved;
  const good = L.advanceTrainingLevel(draftAt('training_level', ['welcome', 'profile', 'sports']), NOW);
  ok('L9 valide → ok:true, completed + Weiterschalten', good.ok === true && good.draft.currentStep === 'goals' && good.draft.completedSteps.indexOf('training_level') >= 0);
}
{ // L10/L11: kein Skip, kein Validierungs-Bypass
  const s = L.skipStep(draftAt('training_level', ['welcome', 'profile', 'sports']), 'training_level', NOW);
  ok('L10 skipStep(training_level) abgelehnt', s.ok === false);
  const c = L.completeStep(draftAt('training_level', ['welcome', 'profile', 'sports']), 'training_level', NOW);
  ok('L11 completeStep(training_level) abgelehnt (Fachvalidierung nötig)', c.ok === false);
}
{ // L12: Resume-Migration — Alt-Draft (vor M5b) steht auf goals_placeholder ohne training_level
  const oldRaw = { version: 3, status: 'in_progress', currentStep: 'goals_placeholder', completedSteps: ['welcome', 'profile', 'sports'], skippedSteps: [], draftData: { profile: Object.assign({}, VALID_PROFILE), sports: selWithPrimary() } };
  const d = L.normalizeDraft(oldRaw);
  ok('L12a Alt-Draft: Rückführung auf training_level (Lücke fail-closed geschlossen)', d.currentStep === 'training_level', 'currentStep=' + d.currentStep);
  ok('L12b Alt-Draft: Daten unangetastet (profile/sports erhalten)', d.draftData.profile.displayName === 'Gian' && Array.isArray(d.draftData.sports.sports) && d.draftData.sports.sports.length === 2);
  ok('L12c Alt-Draft: completedSteps bleiben lückenloses Präfix', JSON.stringify(d.completedSteps) === JSON.stringify(['welcome', 'profile', 'sports']));
  // Kontrollfall: Draft MIT Level-Daten, der regulär auf goals_placeholder steht, bleibt vorn
  const okRaw = { version: 3, status: 'in_progress', currentStep: 'goals_placeholder', completedSteps: ['welcome', 'profile', 'sports', 'training_level'], skippedSteps: [], draftData: { profile: Object.assign({}, VALID_PROFILE), sports: selComplete() } };
  const d2 = L.normalizeDraft(okRaw);
  ok('L12d vollständiger Draft bleibt auf goals (Alias-Migration)', d2.currentStep === 'goals' && d2.completedSteps.indexOf('training_level') >= 0);
  // Fail-closed: training_level in completedSteps, aber KEINE Daten → wird entfernt
  const lie = L.normalizeDraft(Object.assign({}, okRaw, { draftData: { profile: Object.assign({}, VALID_PROFILE), sports: selWithPrimary() } }));
  ok('L12e completed-Behauptung ohne Daten wird entfernt', lie.completedSteps.indexOf('training_level') < 0);
}
{ // L13: Review-Voraussetzungen
  const d = draftAt('review', ['welcome', 'profile', 'sports', 'training_level', 'goals', 'availability', 'safety', 'body']);
  ok('L13a Review-Voraussetzungen mit training_level erfüllt', L.reviewPrerequisitesComplete(d) === true);
  const d2 = draftAt('review', ['welcome', 'profile', 'sports', 'goals', 'availability', 'safety', 'body'], { sports: selWithPrimary() });
  ok('L13b ohne training_level nicht erfüllt', L.reviewPrerequisitesComplete(d2) === false);
}
{ // L14: firstIncompleteStep berücksichtigt Level-Validität
  const d = draftAt('review', ['welcome', 'profile', 'sports', 'training_level', 'goals', 'availability', 'safety', 'body'], { sports: selWithPrimary() });
  ok('L14 firstIncompleteStep → training_level bei fehlenden Daten', L.firstIncompleteStep(d) === 'training_level');
}

/* ================= P — Completion-Mapping (onboarding-ui._m4) ================= */
{
  const B = globalThis.ORVIA.onboardingV2._m4.buildCompletionPatch;
  const dd = { profile: Object.assign({}, VALID_PROFILE), sports: selComplete(), goals: [], availability: null };
  const patch = B(dd, PM);
  const prim = (patch.sports || []).filter(s => s.role === 'primary')[0];
  ok('P1 Patch: level/sessionsPerWeek erreichen PROFILE.sports[primary]', !!prim && prim.level === 'intermediate' && prim.sessionsPerWeek === 4);
  const ddOld = { profile: Object.assign({}, VALID_PROFILE, { experienceLevel: 'advanced' }), sports: selWithPrimary(), goals: [], availability: null };
  const p2 = B(ddOld, PM);
  const prim2 = (p2.sports || []).filter(s => s.role === 'primary')[0];
  ok('P2 Alt-Draft-Fallback: experienceLevel → primary.level', !!prim2 && prim2.level === 'advanced');
  const ddBoth = { profile: Object.assign({}, VALID_PROFILE, { experienceLevel: 'beginner' }), sports: selComplete(), goals: [], availability: null };
  const p3 = B(ddBoth, PM);
  const prim3 = (p3.sports || []).filter(s => s.role === 'primary')[0];
  ok('P3 Entry-Level gewinnt über experienceLevel', !!prim3 && prim3.level === 'intermediate');
  ok('P4 ESSENTIAL-Check: primary_level/primary_sessions_per_week erfüllt', (function () {
    const prof = { sports: patch.sports };
    const c = PM.computeSectionCompleteness(prof, 'sports');
    return c.missing.indexOf('primary_level') < 0 && c.missing.indexOf('primary_sessions_per_week') < 0;
  })());
}

/* ================= D — DOM: A2-Redesign + A3-Renderer ================= */
async function fresh(seedMem) {
  const reg = new Map();
  function registerHtmlIds(html) { var m, re = /id="([^"]+)"/g; while ((m = re.exec(String(html || '')))) { if (!reg.has('#' + m[1])) reg.set('#' + m[1], makeEl()); } }
  function appendEl(el) { if (el && el._id) reg.set('#' + el._id, el); if (el) registerHtmlIds(el._html); }
  function makeEl() {
    const el = {
      style: {}, _html: '', value: '', textContent: '', disabled: false, checked: false, onclick: null, _id: null, _ev: {}, _focused: false, _children: [],
      classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, contains(c) { return this._s.has(c); }, toggle(c, f) { if (f === undefined) f = !this._s.has(c); if (f) this._s.add(c); else this._s.delete(c); return f; } },
      set innerHTML(v) { this._html = v; registerHtmlIds(v); }, get innerHTML() { return this._html; },
      set id(v) { this._id = v; if (v) reg.set('#' + v, this); }, get id() { return this._id; },
      _attr: {}, setAttribute(k, v) { this._attr[k] = String(v); if (k === 'id' && v) { this._id = v; reg.set('#' + v, this); } }, removeAttribute(k) { delete this._attr[k]; }, getAttribute(k) { return this._attr[k] != null ? this._attr[k] : null; },
      addEventListener(ev, cb) { this._ev[ev] = cb; }, appendChild(c) { this._children.push(c); appendEl(c); return c; },
      remove() { if (this._id) reg.delete('#' + this._id); }, focus() { this._focused = true; },
      click() { if (this.disabled) return; if (this._ev.click) this._ev.click({ preventDefault() {} }); else if (typeof this.onclick === 'function') this.onclick(); },
      querySelector(sel) { return regGet(sel); }, querySelectorAll() { return []; }
    };
    return el;
  }
  function regGet(k) { if (!reg.has(k)) reg.set(k, makeEl()); return reg.get(k); }
  function byId(id) { return reg.has('#' + id) ? reg.get('#' + id) : null; }
  const docEv = {};
  const docEl = { activeElement: null, visibilityState: 'visible', documentElement: { classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, contains(c) { return this._s.has(c); } } }, body: { appendChild(c) { appendEl(c); } }, createElement: makeEl, getElementById: byId, querySelector: regGet, addEventListener(t, fn) { docEv[t] = fn; } };
  globalThis.document = docEl;
  const mem = Object.assign({}, seedMem || {});
  globalThis.localStorage = { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } };
  globalThis.ORVIA.user = null;
  globalThis.ORVIA.profile = null;
  globalThis.ORVIA.onboardingV2._reset();
  globalThis.ORVIA.onboardingV2._state.bound = false;
  return { reg, byId, docEl, mem };
}
const ST = () => globalThis.ORVIA.onboardingV2._state;
const card = h => h.reg.get('.ob2-card');
function seedDraft(draft) { const s = {}; s[Store.key(null)] = JSON.stringify(draft); return s; }

{ // D1: A2 — Essential-Sportauswahl über Kit-ChoiceCards, KEINE Modus-/Prio-/Sichtbarkeits-UI
  let cardCalls = [];
  const realCC = KIT.createChoiceCard;
  KIT.createChoiceCard = function (opts) { cardCalls.push(opts); return realCC(opts); };
  let h = await fresh(seedDraft(draftAt('sports', ['welcome', 'profile'], { sports: SL.normalizeSportsSelection({}) })));
  globalThis.ORVIA.onboardingV2.open({ fresh: false });
  await wait();
  const html = card(h).innerHTML || '';
  ok('D1a Katalog als ChoiceCards (24 Karten)', cardCalls.filter(o => o && String(o.id || '').indexOf('spc-') === 0).length === SL.SPORT_CATALOG.length);
  ok('D1b keine Essential-Fremd-UI (Modus/Priorität/Sichtbarkeit raus)', html.indexOf('mode-planned-') < 0 && html.indexOf('vis-') < 0 && html.indexOf('id="up-') < 0);
  // Leerauswahl: KEINE Hauptsport-Frage (nichts zu wählen); erst nach erster Auswahl erscheint sie.
  ok('D1c leere Auswahl → keine Hauptsport-Frage', html.indexOf('Hauptsport') < 0);
  const runCard = cardCalls.filter(o => o.id === 'spc-running')[0];
  runCard.onChange('running', true);   // toggelt running → Re-Render
  await wait();
  const html2 = card(h).innerHTML || '';
  ok('D1d nach Auswahl: Hauptsport-Frage + Auto-Primary (running)', html2.indexOf('Hauptsport') >= 0 && (function () { const p = ST().draft.draftData.sports.sports.filter(e => e.role === 'primary')[0]; return !!p && p.sportId === 'running'; })());
  KIT.createChoiceCard = realCC;
}
{ // D2: A3 — Renderer, Kit-Nutzung, Fehlerpfad, Erfolgspfad
  let phOpts = null; const realPH = KIT.createProgressHeader;
  KIT.createProgressHeader = function (o) { phOpts = o; return realPH(o); };
  let segOpts = []; const realSC = KIT.createSegmentedControl;
  KIT.createSegmentedControl = function (o) { segOpts.push(o); return realSC(o); };
  let ccOpts = []; const realCC2 = KIT.createChoiceCard;
  KIT.createChoiceCard = function (o) { ccOpts.push(o); return realCC2(o); };

  let h = await fresh(seedDraft(draftAt('training_level', ['welcome', 'profile', 'sports'], { sports: selWithPrimary() })));
  globalThis.ORVIA.onboardingV2.open({ fresh: false });
  await wait();
  const gp = L.getProgress(ST().draft);
  ok('D2a ProgressHeader aus getProgress()', !!phOpts && phOpts.current === gp.current && phOpts.total === gp.total);
  ok('D2b 4 Level-ChoiceCards mit Subtext', ccOpts.filter(o => String(o.id || '').indexOf('lvl-') === 0).length === 4 && ccOpts.filter(o => String(o.id || '').indexOf('lvl-') === 0).every(o => !!o.description));
  ok('D2c Frequenz als SegmentedControl (4 Bänder)', segOpts.some(o => Array.isArray(o.options) && o.options.length === 4));
  // Submit ohne Auswahl → Fehler sichtbar, kein Weiter
  ST().lastNav = 0;
  h.reg.get('#ob2-next').onclick();
  await wait();
  ok('D2d Submit ohne Auswahl bleibt auf training_level', ST().draft.currentStep === 'training_level');
  const errHtml = card(h).innerHTML || '';
  ok('D2e Fehlertexte als role=alert gerendert', errHtml.indexOf('role="alert"') >= 0 && errHtml.indexOf('err-level') >= 0 && errHtml.indexOf('err-sessions') >= 0);
  // Auswahl treffen (über Kit-Callbacks) → Draft aktualisiert
  const lvlCard = ccOpts.filter(o => o.id === 'lvl-intermediate')[0];
  lvlCard.onChange('intermediate', true);
  const band = segOpts.filter(o => o.name === 'sessions-band')[0];
  band.onChange('3-4');
  await wait();
  const prim = primaryOf(ST().draft.draftData.sports);
  ok('D2f Kartenwahl schreibt level in Draft (primary)', prim.level === 'intermediate');
  ok('D2g Bandwahl schreibt sessionsPerWeek=4 (Int-Mapping)', prim.sessionsPerWeek === 4);
  ST().lastNav = 0;
  h.reg.get('#ob2-next').onclick();
  await wait();
  ok('D2h Submit mit validen Daten → goals', ST().draft.currentStep === 'goals');
  ok('D2i Draft persistiert (Store enthält training_level als completed)', JSON.parse(h.mem[Store.key(null)]).completedSteps.indexOf('training_level') >= 0);
  KIT.createProgressHeader = realPH; KIT.createSegmentedControl = realSC; KIT.createChoiceCard = realCC2;
}
{ // D3: Zurück von training_level → sports; Primary-Wechsel erzwingt neue A3-Angaben
  let h = await fresh(seedDraft(draftAt('training_level', ['welcome', 'profile', 'sports'], { sports: selComplete() })));
  globalThis.ORVIA.onboardingV2.open({ fresh: false });
  await wait();
  ST().lastNav = 0;
  h.reg.get('#ob2-back').onclick();
  await wait();
  ok('D3a Zurück → sports', ST().draft.currentStep === 'sports');
  // Primary wechseln (auf gym) → training_level erneut Pflicht
  ST().draft.draftData.sports = SL.setPrimarySport(ST().draft.draftData.sports, 'gym');
  const v = SL.validateTrainingLevel(ST().draft.draftData.sports);
  ok('D3b Primary-Wechsel invalidiert A3 (neue Primary ohne Angaben)', v.valid === false);
}
{ // D4: Quelltext-Verträge
  const src = readFileSync(new URL(_APPREL + 'js/onboarding/onboarding-ui.js', import.meta.url), 'utf8');
  ok('D4a kein hart codiertes „Schritt X von Y"', !/Schritt \d+ von \d+/.test(src));
  ok('D4b kein PROFILE.level-Schreiben im Onboarding-UI', !/PROFILE\s*\.\s*level\s*=/.test(src));
  ok('D4c kitFull prüft SegmentedControl (Vertrag erweitert)', /createSegmentedControl/.test(String(src.match(/function kitFull[\s\S]{0,400}/))));
}

console.log('\nErgebnis: ' + pass + ' bestanden, ' + fail + ' fehlgeschlagen.');
process.exit(fail ? 1 : 0);
