/* ORVIA · i18n-extract (B-13, Band 6 e.2 Schritt 3) — datengetriebene Extraktion EINER Datei.
   Nutzersichtbare Literale (Heuristik: Whitespace+Grossbuchstabe/Umlaut, kuratierte Einzelwoerter,
   Text/Attribute in Markup-Literalen) werden NUR innerhalb von '…'-Literalen und mit Wortgrenzen
   durch ' + T('ns.slug') + ' ersetzt; der Katalog-Nachtrag landet in <out>.json (Key → Text).
   Danach: T() in der Datei definieren, Katalogblock in locales/de.js einfuegen, Tests mit Katalog laden.
     node app/tools/i18n-extract.mjs <datei.js> <namespace> <out.json>   (Datei wird IN PLACE geaendert) */
import { readFileSync, writeFileSync } from 'node:fs';
const [,, p, NS = 'ui', OUT = '_to_delete/extract.json'] = process.argv;
if (!p) { console.error('Aufruf: node app/tools/i18n-extract.mjs <datei.js> <namespace> <out.json>'); process.exit(2); }
let src = readFileSync(p, 'utf8');
/* KLASSIFIKATIONS-SCHUTZ (Befund ui.js 12.09.: {'Wettkampf':'race_week'}[act.n] wurde zu
   {'' + T('…') + '':…} — Syntaxfehler; schlimmer waere ein Label, das an einer Stelle Text
   und an einer anderen Vergleichswert ist). Ein Literal, das IRGENDWO in app/js als
   Objektschluessel, Vergleichsoperand (===, !==, ==, !=), case-Label oder Index (obj['x'])
   steht, ist ein Bezeichner und wird nirgends extrahiert. Zusaetzlich wird jede einzelne
   Fundstelle in solchem Kontext uebersprungen (auch fuer Teiltexte). */
import { readdirSync, statSync } from 'node:fs';
import { join as _join, dirname as _dirname } from 'node:path';
function _walk(dir, out) { for (const n of readdirSync(dir)) { const f = _join(dir, n); const st = statSync(f); if (st.isDirectory()) _walk(f, out); else if (/\.js$/.test(n)) out.push(f); } return out; }
const _jsRoot = (() => { let d = _dirname(p); while (d && !/(^|\/)js$/.test(d) && d !== '.' && d !== '/') d = _dirname(d); return /(^|\/)js$/.test(d) ? d : _dirname(p); })();
const IDENT = new Set();
function _identContext(text, before, after) {
  const b = before.replace(/\s+$/, ''), a = after.replace(/^\s+/, '');
  if (/(===|!==|==|!=)$/.test(b) || /^(===|!==|==|!=)/.test(a)) return true;     // Vergleich
  if (/\bcase$/.test(b)) return true;                                               // switch
  if (/\[$/.test(b) && /^\]/.test(a)) return true;                                  // obj['x']
  if (/[{,]$/.test(b) && /^:/.test(a) && !/\?[^:]*$/.test(b.slice(-80))) return true; // Objektschluessel (kein Ternary)
  return false;
}
for (const f of _walk(_jsRoot, [])) {
  const t = readFileSync(f, 'utf8'); const r = /'((?:[^'\\\n]|\\.)*)'|"((?:[^"\\\n]|\\.)*)"/g; let m;
  while ((m = r.exec(t))) { const body = m[1] != null ? m[1] : m[2]; if (!body) continue;
    if (_identContext(body, t.slice(Math.max(0, m.index - 80), m.index), t.slice(m.index + m[0].length, m.index + m[0].length + 8))) IDENT.add(body); }
}
const lines = src.split('\n');
const re = /'((?:[^'\\\n]|\\.)*)'/g;
const cand = new Map();
const SINGLE_OK = new Set(['Mo','Di','Mi','Do','Fr','Sa','So','Ausdauer','5-km-Lauf','10-km-Lauf','Halbmarathon','Marathon','Triathlon','Wiedereinstieg','Zielzeit','Nein','Ja','Links','Rechts','Beidseitig','Wettkampf','Training','Datum','Sportarten','Trainingsstand','Verfügbarkeit','Sicherheits-Check','Körperdaten','Zusammenfassung','Männlich','Weiblich','Divers','Anfänger','Fortgeschritten','Erfahren','Wettkampforientiert','Geburtsdatum','Weiter','Zurück','Speichern','Abbrechen','Überspringen','Fertig','Optional','Willkommen','Jahre','Alter','Name','Gewicht','Größe','Hauptsport','Gelegentlich','Regelmäßig']);
lines.forEach((line, i) => {
  /* Kommentare, Logs, Perf-Marken (_P.mark('…')), HTTP-Header: keine Nutzertexte (Befund auth.js 12.09.: 13 Perf-Labels + 'Bearer ' erfasst). */
  if (/^\s*(\/\/|\*|\/\*)/.test(line) || /console\./.test(line) || /\.mark\(/.test(line) || /headers\s*:/.test(line)) return;
  let m; re.lastIndex = 0;
  while ((m = re.exec(line))) {
    const s = m[1]; if (!s || s.length < 2) continue;
    if (/\\'/.test(s)) continue;                       // escaped quotes: manuell
    const hasWs = /\s/.test(s);
    if (!hasWs) { if (!SINGLE_OK.has(s)) continue; }
    else {
      if (/^[a-z0-9_ -]*$/.test(s) && !/[äöüß]/.test(s)) continue;     // technische Werte
      if (/^(\[|#|\.|orvia:|https?:|data-|aria-)/.test(s)) continue;
      if (/^<[^>]*>$/.test(s)) continue;                              // reines Markup
      if (!/</.test(s) && /[\w:-]+="/.test(s)) continue;                           // Attribut-Fragmente (onclick="…", aria-label, SVG-Attribute) — Befund profile.js/activity.js
      if (/^[\s·•–—|:()/.,+×~&]+$/.test(s)) continue;
      if (!/[A-ZÄÖÜ]/.test(s) && !/[äöüß]/.test(s)) continue;         // keine Grossbuchstaben/Umlaute → eher technisch
      if (/^\s*(px|em|%)/.test(s)) continue;
    }
    if (!cand.has(s)) cand.set(s, i + 1);
  }
});
// Markup-haltige Literale: nur den Textanteil zwischen Tags extrahieren, wenn er eindeutig ist
const texts = [];
for (const [s] of cand) {
  if (/</.test(s)) {
    const parts = [...s.matchAll(/>([^<>]*[A-Za-zÄÖÜäöüß][^<>]*)</g)].map(x => x[1]).filter(x => /[A-ZÄÖÜ]|[äöüß]/.test(x) && x.trim().length > 1);
    parts.forEach(t => texts.push(t));
    // Attribute: placeholder/aria-label/title
    [...s.matchAll(/(?:placeholder|aria-label|title)="([^"]+)"/g)].forEach(x => texts.push(x[1]));
  } else texts.push(s);
}
const uniq = [...new Set(texts.map(t => t))].filter(t => t.trim().length > 1 && !/^[\s·•–—|:()/.,+×~&]+$/.test(t) && t !== 'ORVIA' && !/^\[ORVIA/.test(t));   // Markenname nie uebersetzen
const uniq2 = uniq.filter(t => !IDENT.has(t));
const skippedIdent = uniq.length - uniq2.length;
uniq2.sort((a, b) => b.length - a.length);
const slug = t => t.toLowerCase().replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss').replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'').split('_').slice(0,5).join('_');
const used = new Set(); const catalog = {};
let n = 0;
for (const t of uniq2) {
  let k = NS + '.' + slug(t); if (!k.replace(NS + '.','')) continue; while (used.has(k)) k += '_'; used.add(k);
  const before = src.length;
  // nur innerhalb von Literalen: Vorkommen des Textes, das in einer '…'-Zeichenkette liegt — wir ersetzen alle Vorkommen mit Bindestrich-Splice
  // Sicherheit: ersetze nur, wenn das Vorkommen NICHT Teil eines laengeren bereits ersetzten Keys ist
  // nur innerhalb einfach-quotierter Literale, mit Wortgrenzen
  const esc = t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const rx = new RegExp("(^|[^A-Za-zÄÖÜäöüß0-9])" + esc + "(?=$|[^A-Za-zÄÖÜäöüß0-9])");
  let out = '', i = 0, hit = false;
  const lit = /'((?:[^'\\\n]|\\.)*)'/g; let mm;
  while ((mm = lit.exec(src))) {
    out += src.slice(i, mm.index);
    let body = mm[1];
    if (body.indexOf(t) >= 0 && !_identContext(body, src.slice(Math.max(0, mm.index - 80), mm.index), src.slice(mm.index + mm[0].length, mm.index + mm[0].length + 8))) {
      let nb = '', j = 0, r;
      const g = new RegExp(rx.source, 'g');
      while ((r = g.exec(body))) { nb += body.slice(j, r.index) + r[1] + "' + T('" + k + "') + '"; j = r.index + r[0].length; hit = true; }
      body = nb + body.slice(j);
    }
    out += "'" + body + "'"; i = mm.index + mm[0].length;
  }
  out += src.slice(i);
  if (hit) { src = out; catalog[k] = t; n++; }
}
writeFileSync(p, src);
writeFileSync(OUT, JSON.stringify(catalog, null, 1));
console.log('candidates', cand.size, 'texts', uniq.length, 'als Bezeichner ausgeschlossen', skippedIdent, 'replaced', n);
