/* ============================================================
   ORVIA · gym-volume — Muskelvolumen-Engine (Inkrement 2C).
   Aus REALEN Workout-Sätzen (lokale Snapshots). STRIKTE Trennung:
   realWorkingSets ≠ directSets ≠ indirectSetEquivalents ≠ effectiveSetEquivalents.
   Jeder (Dezimal-)Wert ist über explainMuscleVolume() auf Übungen + reale Sätze + Ausschlüsse
   rückführbar. KEINE universelle 10–20-Regel; konservative, individuell anpassbare Startkorridore.
   Koeffizienten zentral konfigurierbar; sekundär NICHT pauschal 0,5. Unbekannte Übung = unclassified.
   ============================================================ */
(function (root) {
  root.ORVIA = root.ORVIA || {};
  var O = root.ORVIA;

  var MAPPING_VERSION = '2c.1';
  // Zählbare Satztypen = real geleistete Arbeitssätze. Aufwärm-/Technik-/Probe-Sätze zählen NICHT.
  var COUNTABLE_SET_TYPES = { working: 1, top_set: 1, backoff: 1, dropset: 1, amrap: 1, myo_reps: 1 };
  var NONCOUNT_TYPES = { warmup: 'warmup', technique: 'technique', test: 'test' };
  var DIRECT = 1.0, INDIRECT = 0.5;   // Default-Koeffizienten; pro Mapping überschreibbar.

  // Muskel-IDs (getrennte Schulterköpfe; Lats vs. oberer Rücken; Quads/Hamstrings/Glutes getrennt).
  var MUSCLES = ['chest', 'front_delts', 'side_delts', 'rear_delts', 'triceps', 'biceps',
    'lats', 'upper_back', 'lower_back', 'quads', 'hamstrings', 'glutes', 'calves', 'abs', 'forearms'];
  var MUSCLE_LABEL = {
    chest: 'Brust', front_delts: 'Vordere Schulter', side_delts: 'Seitliche Schulter', rear_delts: 'Hintere Schulter',
    triceps: 'Trizeps', biceps: 'Bizeps', lats: 'Lats', upper_back: 'Oberer Rücken', lower_back: 'Unterer Rücken',
    quads: 'Quadrizeps', hamstrings: 'Beinbeuger', glutes: 'Gesäß', calves: 'Waden', abs: 'Core', forearms: 'Unterarme'
  };

  // Koeffizient eines Mapping-Werts: 'direct'→1.0, 'indirect'→0.5, Zahl→exakt. (sekundär nicht pauschal 0,5)
  function coeffOf(v) { if (v === 'direct') return DIRECT; if (v === 'indirect') return INDIRECT; var n = +v; return isFinite(n) ? n : INDIRECT; }
  function roleOf(v) { var c = coeffOf(v); return c >= 1 ? 'direct' : 'indirect'; }

  // Name-basiertes Mapping (normalisierte deutsche/engl. Übungsnamen). Sekundär mit spezifischem Koeffizient.
  var NAME_MUSCLES = {
    'brustpresse': { chest: 'direct', triceps: 0.5, front_delts: 0.5 },
    'bankdrücken': { chest: 'direct', triceps: 0.5, front_delts: 0.5 },
    'bankdruecken': { chest: 'direct', triceps: 0.5, front_delts: 0.5 },
    'schrägbankdrücken': { chest: 'direct', front_delts: 0.5, triceps: 0.5 },
    'schraegbankdruecken': { chest: 'direct', front_delts: 0.5, triceps: 0.5 },
    'flys': { chest: 'direct', front_delts: 0.25 },
    'fliegende': { chest: 'direct', front_delts: 0.25 },
    'cable fly': { chest: 'direct', front_delts: 0.25 },
    'schulterdrücken': { front_delts: 'direct', side_delts: 0.5, triceps: 0.5 },
    'schulterdruecken': { front_delts: 'direct', side_delts: 0.5, triceps: 0.5 },
    'overhead press': { front_delts: 'direct', side_delts: 0.5, triceps: 0.5 },
    'seitheben': { side_delts: 'direct' },
    'lateral raise': { side_delts: 'direct' },
    'reverse pec deck': { rear_delts: 'direct' },
    'reverse fly': { rear_delts: 'direct' },
    'reverse flys': { rear_delts: 'direct' },
    'rudern': { upper_back: 'direct', lats: 0.5, biceps: 0.5, rear_delts: 0.5 },
    'row': { upper_back: 'direct', lats: 0.5, biceps: 0.5, rear_delts: 0.5 },
    'latzug': { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    'lat pulldown': { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    'klimmzüge': { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    'klimmzuege': { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    'pull up': { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    'bizepscurls': { biceps: 'direct' },
    'bizeps curls': { biceps: 'direct' },
    'curl': { biceps: 'direct' },
    'trizepsdrücken': { triceps: 'direct' },
    'trizepsdruecken': { triceps: 'direct' },
    'triceps pushdown': { triceps: 'direct' },
    'kniebeuge': { quads: 'direct', glutes: 0.5, lower_back: 0.25 },
    'squat': { quads: 'direct', glutes: 0.5, lower_back: 0.25 },
    'beinpresse': { quads: 'direct', glutes: 0.5 },
    'leg press': { quads: 'direct', glutes: 0.5 },
    'beinstrecker': { quads: 'direct' },
    'leg extension': { quads: 'direct' },
    'beinbeuger': { hamstrings: 'direct' },
    'leg curl': { hamstrings: 'direct' },
    'romanian deadlift': { hamstrings: 'direct', glutes: 'direct', lower_back: 0.5 },
    'rdl': { hamstrings: 'direct', glutes: 'direct', lower_back: 0.5 },
    'hip thrust': { glutes: 'direct', hamstrings: 0.5 },
    'wadenheben': { calves: 'direct' },
    'calf raise': { calves: 'direct' },
    'plank': { abs: 'direct' }, 'crunch': { abs: 'direct' }, 'core': { abs: 'direct' },
    // Step-up: einbeiniges knie-dominantes Muster → Quads + Gesäß primär, Beinbeuger sekundär.
    'step-up': { quads: 'direct', glutes: 'direct', hamstrings: 0.25 },
    'step up': { quads: 'direct', glutes: 'direct', hamstrings: 0.25 },
    'stepup': { quads: 'direct', glutes: 'direct', hamstrings: 0.25 },
    'step-ups': { quads: 'direct', glutes: 'direct', hamstrings: 0.25 },
    'step ups': { quads: 'direct', glutes: 'direct', hamstrings: 0.25 },
    // Hyperextensions / Rückenstrecker: unterer Rücken primär, Gesäß/Beinbeuger sekundär.
    'hyperextensions': { lower_back: 'direct', glutes: 0.5, hamstrings: 0.5 },
    'hyperextension': { lower_back: 'direct', glutes: 0.5, hamstrings: 0.5 },
    'hyperextentions': { lower_back: 'direct', glutes: 0.5, hamstrings: 0.5 },
    'hyperextention': { lower_back: 'direct', glutes: 0.5, hamstrings: 0.5 },
    'back extension': { lower_back: 'direct', glutes: 0.5, hamstrings: 0.5 },
    'back extensions': { lower_back: 'direct', glutes: 0.5, hamstrings: 0.5 },
    'rückenstrecker': { lower_back: 'direct', glutes: 0.5, hamstrings: 0.5 },
    'rueckenstrecker': { lower_back: 'direct', glutes: 0.5, hamstrings: 0.5 },
    // Trizeps-Pushdown (Ellbogenstreckung) → Trizeps primär.
    'trizeps pushdown': { triceps: 'direct' }, 'triceps pushdown': { triceps: 'direct' },
    'cable pushdown': { triceps: 'direct' }, 'rope pushdown': { triceps: 'direct' }, 'pushdown': { triceps: 'direct' },
    // Bizeps-Curl (Ellbogenbeugung) → Bizeps primär. 'curl'/'curls' generisch NUR Bizeps; 'leg curl'/'beinbeuger'
    // haben eigene exakte Keys (Hamstrings) und gewinnen über die exakte Lookup-Priorität.
    'bizeps curl': { biceps: 'direct' }, 'biceps curl': { biceps: 'direct' }, 'curls': { biceps: 'direct' },
    'kurzhantelcurl': { biceps: 'direct' }, 'langhantelcurl': { biceps: 'direct' }, 'cable curl': { biceps: 'direct' }, 'hammer curl': { biceps: 'direct' },
    // Face Pull → hintere Schulter primär, oberer Rücken sekundär (Präfix deckt „Face Pull Jacob" ab).
    'face pull': { rear_delts: 'direct', upper_back: 0.5 }, 'face pulls': { rear_delts: 'direct', upper_back: 0.5 },
    // Ab-Rollout / Bauchroller → Core (abs) primär. KEIN Brust/Lats/Hüftbeuger.
    'abroll': { abs: 'direct' }, 'ab roll': { abs: 'direct' }, 'ab rollout': { abs: 'direct' },
    'ab wheel': { abs: 'direct' }, 'ab wheel rollout': { abs: 'direct' }, 'bauchroller': { abs: 'direct' }, 'bauchrollen': { abs: 'direct' },
    // Breiter Klimmzug → Lats primär, Bizeps + oberer Rücken sekundär.
    'klimmzug breit': { lats: 'direct', biceps: 0.5, upper_back: 0.5 }, 'breiter klimmzug': { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    'wide grip pull up': { lats: 'direct', biceps: 0.5, upper_back: 0.5 }, 'wide grip pullup': { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    'pull up breit': { lats: 'direct', biceps: 0.5, upper_back: 0.5 }, 'pullup breit': { lats: 'direct', biceps: 0.5, upper_back: 0.5 }
  };
  // ID-basiert (kanonische Slugs) + Movement-Pattern-Fallback (additiv, abwärtskompatibel).
  var EXERCISE_MUSCLES = {
    bench_press: { chest: 'direct', triceps: 0.5, front_delts: 0.5 },
    bench_press_machine: { chest: 'direct', triceps: 0.5, front_delts: 0.5 },
    incline_bench_press: { chest: 'direct', front_delts: 0.5, triceps: 0.5 },
    overhead_press: { front_delts: 'direct', side_delts: 0.5, triceps: 0.5 },
    lateral_raise: { side_delts: 'direct' }, reverse_pec_deck: { rear_delts: 'direct' },
    pull_up: { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    lat_pulldown: { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    barbell_row: { upper_back: 'direct', lats: 0.5, biceps: 0.5, rear_delts: 0.5 },
    biceps_curl: { biceps: 'direct' }, triceps_pushdown: { triceps: 'direct' },
    squat: { quads: 'direct', glutes: 0.5, lower_back: 0.25 }, leg_press: { quads: 'direct', glutes: 0.5 },
    romanian_deadlift: { hamstrings: 'direct', glutes: 'direct', lower_back: 0.5 },
    deadlift: { glutes: 'direct', hamstrings: 'direct', lower_back: 'direct', upper_back: 0.5 },
    leg_curl: { hamstrings: 'direct' }, leg_extension: { quads: 'direct' },
    hip_thrust: { glutes: 'direct', hamstrings: 0.5 }, calf_raise: { calves: 'direct' }, plank: { abs: 'direct' }
  };
  var PATTERN_MUSCLES = {
    horizontal_push: { chest: 'direct', triceps: 0.5, front_delts: 0.5 },
    vertical_push: { front_delts: 'direct', side_delts: 0.5, triceps: 0.5 },
    horizontal_pull: { upper_back: 'direct', lats: 0.5, biceps: 0.5 },
    vertical_pull: { lats: 'direct', biceps: 0.5, upper_back: 0.5 },
    squat: { quads: 'direct', glutes: 0.5 }, hinge: { hamstrings: 'direct', glutes: 'direct', lower_back: 0.5 },
    lunge: { quads: 'direct', glutes: 0.5 }, knee_extension: { quads: 'direct' }, knee_flexion: { hamstrings: 'direct' },
    hip_extension: { glutes: 'direct' }, calf: { calves: 'direct' }, elbow_flexion: { biceps: 'direct' },
    elbow_extension: { triceps: 'direct' }, shoulder_abduction: { side_delts: 'direct' }, trunk_flexion: { abs: 'direct' }
  };

  // Zentrale Normalisierung: lowercase, Binde-/Unterstriche/Slash → Leerzeichen, Mehrfachspaces weg, trim.
  function normName(n) { return String(n == null ? '' : n).toLowerCase().replace(/[-_/]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  // Normalisiertes Lookup aus NAME_MUSCLES (alle Schreibvarianten → ein Eintrag).
  var NAME_LOOKUP = null;
  function nameLookup() { if (NAME_LOOKUP) return NAME_LOOKUP; NAME_LOOKUP = {}; Object.keys(NAME_MUSCLES).forEach(function (k) { NAME_LOOKUP[normName(k)] = NAME_MUSCLES[k]; }); return NAME_LOOKUP; }
  // Präfix-Aliasse (gleiche Bewegung, individuelle Namenszusätze wie „Face Pull Jacob").
  var NAME_PREFIXES = [
    { p: 'face pull', m: { rear_delts: 'direct', upper_back: 0.5 } },
    { p: 'klimmzug breit', m: { lats: 'direct', biceps: 0.5, upper_back: 0.5 } },
    { p: 'breiter klimmzug', m: { lats: 'direct', biceps: 0.5, upper_back: 0.5 } }
  ];
  // Muskelzuordnung: exakter normalisierter Name → Präfix-Alias → ID-Slug → Movement-Pattern. Sonst null.
  function musclesFor(ex, mapOverride) {
    var nameMap = (mapOverride && mapOverride.names) || nameLookup();
    var idMap = (mapOverride && mapOverride.ids) || EXERCISE_MUSCLES;
    var patMap = (mapOverride && mapOverride.patterns) || PATTERN_MUSCLES;
    var nm = normName(ex && (ex.exerciseNameSnapshot || ex.exerciseName || ex.name));
    if (nm && nameMap[nm]) return nameMap[nm];
    if (nm) { for (var i = 0; i < NAME_PREFIXES.length; i++) { if (nm.indexOf(NAME_PREFIXES[i].p) === 0) return NAME_PREFIXES[i].m; } }
    var id = ex && (ex.exerciseId || ex.exercise_id);
    if (id && idMap[id]) return idMap[id];
    var pat = ex && (ex.movementPattern || ex.movement_pattern);
    if (pat && patMap[pat]) return patMap[pat];
    return null;   // unbekannt → KEINE erfundene Zuordnung
  }
  function isClassified(ex, mapOverride) { return !!musclesFor(ex, mapOverride); }

  // Gültiger Arbeitssatz: completed, zählbarer Typ, reps>0 (oder Zeit/Dauer für Isometrie). RIR ist NUR Kontext.
  function setExclusionReason(set) {
    if (!set) return 'empty';
    if (set.completed !== true) return 'not_completed';
    var t = set.setType || set.set_type || 'working';
    if (NONCOUNT_TYPES[t]) return NONCOUNT_TYPES[t];           // warmup/technique/test
    if (!COUNTABLE_SET_TYPES[t]) return 'noncountable_type';
    var reps = (set.reps != null) ? +set.reps : null;
    var dur = (set.durationS != null ? +set.durationS : (set.timeS != null ? +set.timeS : (set.time_s != null ? +set.time_s : null)));
    if ((reps == null || !(reps > 0)) && !(dur > 0)) return 'no_reps';
    return null;                                               // null = zählt
  }
  function isCountable(set) { return setExclusionReason(set) == null; }
  function realSetsOf(ex) { return ((ex && ex.sets) || []).filter(isCountable).length; }

  // Kern: je Muskel getrennte Kennzahlen + Beitragsliste + Ausschlüsse aus Snapshots.
  // snapshots: [{ workoutId, startedAt, exercises:[{exerciseId, exerciseNameSnapshot, sets:[...]}] }]
  function computeMuscleVolume(snapshots, opts) {
    opts = opts || {}; var map = opts.mapping;
    var byMuscle = {}, exclusions = [], unclassified = {};
    (snapshots || []).forEach(function (w) {
      (w && w.exercises || []).forEach(function (ex) {
        var name = (ex && (ex.exerciseNameSnapshot || ex.exerciseName)) || (ex && (ex.exerciseId || ex.exercise_id)) || 'Übung';
        var sets = (ex && ex.sets) || [];
        // Ausschlüsse erfassen (Aufwärm/unvollständig/leer …) — begründet, rückführbar.
        sets.forEach(function (st) { var rsn = setExclusionReason(st); if (rsn) exclusions.push({ setId: st && (st.id || st.client_set_id || st.setNumber || null), exerciseId: ex && (ex.exerciseId || ex.exercise_id) || null, exerciseName: name, reason: rsn, workoutId: w.workoutId || null }); });
        var real = sets.filter(isCountable).length; if (real <= 0) return;
        var muscles = musclesFor(ex, map);
        if (!muscles) { var u = unclassified[name] || (unclassified[name] = { workingSetCount: 0, occurrenceCount: 0 }); u.workingSetCount += real; u.occurrenceCount += 1; return; }  // sichtbar als unklassifiziert
        Object.keys(muscles).forEach(function (mk) {
          var c = coeffOf(muscles[mk]), role = roleOf(muscles[mk]);
          var m = byMuscle[mk] || (byMuscle[mk] = { muscle: mk, realWorkingSets: 0, directSets: 0, indirectSetEquivalents: 0, effectiveSets: 0, contributions: [] });
          m.realWorkingSets += real;
          if (role === 'direct') m.directSets += real; else m.indirectSetEquivalents += real * c;
          m.effectiveSets += real * c;
          m.contributions.push({ workoutId: w.workoutId || null, date: (w.startedAt || '').slice(0, 10) || null, exerciseId: ex && (ex.exerciseId || ex.exercise_id) || null, exerciseName: name, completedWorkingSets: real, relationship: role, coefficient: c, contribution: Math.round(real * c * 100) / 100 });
        });
      });
    });
    Object.keys(byMuscle).forEach(function (k) { var m = byMuscle[k]; m.directSets = Math.round(m.directSets * 10) / 10; m.indirectSetEquivalents = Math.round(m.indirectSetEquivalents * 10) / 10; m.effectiveSets = Math.round(m.effectiveSets * 10) / 10; });
    return { byMuscle: byMuscle, exclusions: exclusions, unclassified: unclassified };
  }

  function weeklyEquivalent(effectiveSets, days) { days = (days == null || isNaN(days)) ? 7 : +days; if (days <= 0) return 0; return Math.round((+effectiveSets || 0) / days * 7 * 10) / 10; }

  /* ============================================================
     ZIELKORRIDORE — konservativ, individuell anpassbar, KEINE universelle
     10–20-Regel. experience: beginner|intermediate|advanced;
     goal: hypertrophy|maintenance|strength.

     v8-352 · WAS DIESE ZAHLEN SIND UND WAS NICHT. Sie sind ein
     PRODUKTWERT: ein vorsichtiger Startbereich, den ORVIA gesetzt hat. Sie
     stammen aus KEINER eingespeisten Quelle, tragen keine Evidenzklasse und
     sind fachlich nie geprueft worden.

     Bis v8-351 stand der Korridor auf der Muskelkarte als „Ziel:
     6–12/Woche" — ohne jeden Zusatz. In derselben App traegt inzwischen
     jede Zahl aus Wissen ihre Herkunft, ihre Evidenzklasse und ihre
     Ausschluesse mit sich. Eine unbelegte Zahl daneben, die auch noch
     „Ziel" heisst, ist damit die unglaubwuerdigste Stelle des Bildschirms:
     sie sieht genauso verbindlich aus und ist es am wenigsten.

     Deshalb fuehrt der Rueckgabewert jetzt `basis` und `label`. Wer die
     Zahl herausgibt, gibt ihre Herkunft mit heraus — sie kann nicht mehr
     unterwegs verlorengehen.

     ZUR ABGRENZUNG von GYM-HYP-002 (5–6 Saetze je Muskelgruppe und
     EINHEIT): das ist eine ANDERE Bezugsgroesse. Verbunden waeren beide
     ueber die Wochenfrequenz — und die nennt die Quelle ausdruecklich
     nicht („Keine Angabe zur Wochenfrequenz, ohne die eine Satzzahl je
     Einheit wenig aussagt"). Hier wird deshalb NICHT umgerechnet.
     ============================================================ */
  var CORRIDORS = {
    hypertrophy: { beginner: [4, 8], intermediate: [6, 12], advanced: [8, 16] },
    maintenance: { beginner: [3, 6], intermediate: [4, 8], advanced: [5, 9] }
  };
  function targetCorridor(opts) {
    opts = opts || {};
    if (opts.dataWeeks != null && opts.dataWeeks < 2) {
      return { min: null, max: null, source: 'insufficient_data',
        basis: 'keine', label: 'noch keine Datengrundlage' };
    }
    var goal = opts.goal || 'hypertrophy';
    if (goal === 'strength') {
      return { min: null, max: null, source: 'strength_movement_based',
        basis: 'keine', label: 'bei Kraftzielen bewegungsspezifisch, kein Satzkorridor' };
    }
    var exp = opts.experience || 'beginner';
    var table = CORRIDORS[goal] || CORRIDORS.hypertrophy;
    var r = table[exp] || table.beginner;
    return { min: r[0], max: r[1], source: 'conservative_start:' + goal + ':' + exp,
      basis: 'produktwert',
      label: 'ORVIA-Richtwert, konservativ gesetzt — keine Quelle, fachlich ungeprüft',
      einheit: 'effektive Satzäquivalente je Muskelgruppe und Woche' };
  }

  // Konfidenz aus Datenlage: Wochen, Gesamtsätze, Anteil unklassifiziert.
  function confidenceOf(opts) {
    opts = opts || {}; var weeks = opts.weeks || 0, sets = opts.totalSets || 0, unclassRatio = opts.unclassifiedRatio || 0;
    if (weeks < 2 || sets < 4) return 'low';
    if (unclassRatio > 0.25) return 'low';
    if (weeks >= 4 && sets >= 12 && unclassRatio <= 0.1) return 'high';
    return 'medium';
  }

  // Rückführbarer Volumenbericht eines Muskels (vollständige Explainability).
  function explainMuscleVolume(muscle, snapshots, opts) {
    opts = opts || {}; var days = opts.days != null ? opts.days : 7;
    var res = computeMuscleVolume(snapshots, opts);
    var vol = res.byMuscle[muscle] || { realWorkingSets: 0, directSets: 0, indirectSetEquivalents: 0, effectiveSets: 0, contributions: [] };
    var totalSets = 0; Object.keys(res.byMuscle).forEach(function (k) { totalSets += res.byMuscle[k].directSets; });
    var unclassCount = Object.keys(res.unclassified).reduce(function (a, k) { return a + res.unclassified[k].workingSetCount; }, 0);
    var target = targetCorridor({ goal: opts.goal, experience: opts.experience, dataWeeks: opts.weeks });
    return {
      muscleId: muscle,
      period: { days: days, from: opts.from || null, to: opts.to || null },
      realWorkingSets: vol.realWorkingSets,
      directSets: vol.directSets,
      indirectSetEquivalents: vol.indirectSetEquivalents,
      effectiveSetEquivalents: vol.effectiveSets,
      effectiveSetsPerWeek: weeklyEquivalent(vol.effectiveSets, days),
      targetRange: target,
      confidence: confidenceOf({ weeks: opts.weeks, totalSets: vol.realWorkingSets, unclassifiedRatio: (vol.realWorkingSets + unclassCount) ? unclassCount / (vol.realWorkingSets + unclassCount) : 0 }),
      contributions: vol.contributions,
      exclusions: res.exclusions.filter(function (e) { return true; })
    };
  }

  // Status eines Muskels gegen seinen Korridor (Farbe NIE als einzige Info; nicht aggressiv bei Einzelwert).
  function statusFor(effectiveWeekly, target) {
    if (!target || target.min == null) return { key: 'insufficient_data', label: 'Noch zu wenig Daten' };
    if (effectiveWeekly == null || effectiveWeekly <= 0) return { key: 'insufficient_data', label: 'Noch zu wenig Daten' };
    if (effectiveWeekly < target.min) return { key: 'below', label: 'Unter aktuellem Zielkorridor' };
    if (effectiveWeekly <= target.max) return { key: 'in', label: 'Im Zielkorridor' };
    return { key: 'above', label: 'Oberhalb des Zielkorridors' };
  }

  // Adaptive Empfehlung (konservativ): erhöht NIE bei schlechter Erholung/hoher Ausdauerlast.
  // ctx: { performanceTrend:'up|flat|down', painUp, poorRecovery, highDoms, rirMissed, poorSleep, highEndurance, weeks }
  // Liefert: 'insufficient' | 'hold' | 'observe' | 'reduce' | 'room_to_progress' (nie „übertraining").
  function volumeAdvice(ctx) {
    ctx = ctx || {};
    if ((ctx.weeks || 0) < 2) return { advice: 'insufficient', text: 'Noch nicht genug Daten für eine Empfehlung.' };
    var caution = ctx.painUp || ctx.poorRecovery || ctx.highDoms || ctx.poorSleep || ctx.rirMissed || (ctx.performanceTrend === 'down');
    if (caution) return { advice: 'reduce', text: 'Das Volumen könnte aktuell oberhalb deiner gut tolerierten Belastung liegen.' };
    if (ctx.highEndurance) return { advice: 'hold', text: 'Hohe parallele Ausdauerbelastung — Kraftvolumen vorerst halten.' };
    if (ctx.performanceTrend === 'up') return { advice: 'room_to_progress', text: 'Stabil und gut erholt — vorsichtige Steigerung möglich.' };
    return { advice: 'hold', text: 'Volumen stabil halten und beobachten.' };
  }

  // Shadow-Vergleich gegen alte Server-Effektivwerte (Verifikation vor UI-Umschaltung).
  function compareToLegacy(snapshots, legacyEffectiveByMuscle, opts) {
    var res = computeMuscleVolume(snapshots, opts); var shadow = res.byMuscle; var out = {};
    var keys = {}; Object.keys(shadow).forEach(function (k) { keys[k] = 1; }); Object.keys(legacyEffectiveByMuscle || {}).forEach(function (k) { keys[k] = 1; });
    Object.keys(keys).forEach(function (k) {
      var s = shadow[k] ? shadow[k].effectiveSets : 0; var l = (legacyEffectiveByMuscle && legacyEffectiveByMuscle[k]) || 0;
      out[k] = { muscleId: k, shadow: s, legacy: l, difference: Math.round((s - l) * 10) / 10, contributions: shadow[k] ? shadow[k].contributions : [] };
    });
    return out;
  }

  // ---- Robuste Sport-/Status-/Feld-Auflösung (mehrere historische Schemata) ----
  var GYM_ALIASES = { gym: 1, strength: 1, strength_training: 1, weight_training: 1, weights: 1, krafttraining: 1, kraft: 1, workout: 1 };
  function isGymSport(a) {
    var raw = a && (a.sportId != null ? a.sportId : (a.sport_id != null ? a.sport_id : (a.type != null ? a.type : (a.summary && a.summary.sportId) || (a.metrics && a.metrics.sportId))));
    if (raw == null) return a && a.source === 'orvia_workout';   // Workout ohne Sportfeld → als Gym werten
    var n = (O.trainingDomain && O.trainingDomain.normSport) ? O.trainingDomain.normSport(raw) : String(raw).toLowerCase();
    return n === 'gym' || GYM_ALIASES[String(raw).trim().toLowerCase()] === 1;
  }
  function isCompleted(a) {
    var st = a && (a.status || a.state);
    if (st && /^(completed|finished|done|complete)$/i.test(st)) return true;
    if (a && (a.endedAt || a.ended_at || a.finished_at)) return true;
    if (a && a.source === 'orvia_workout' && (a.durationSeconds != null || a.endedAt)) return true;
    return !st;   // kein expliziter Status → nicht allein deswegen verwerfen
  }
  function dateOf(a) {
    var d = a && (a.startedAt || a.started_at || a.date || (a.snapshot && a.snapshot.startedAt) || (a.summary && a.summary.startedAt));
    return d || null;
  }
  function exercisesOf(a) {
    return (a && (a.workoutSnapshot || a.snapshot && a.snapshot.exercises || a.exercises || (a.metrics && a.metrics.exercises))) || null;
  }
  // Dedup-Key NUR aus stabilen Identitäten. Kein gemeinsamer Fallback auf undefined/leer
  // (sonst kollabieren mehrere Legacy-Sessions fälschlich zu einer einzigen).
  function dedupKey(a) {
    if (a.workoutSessionId) return 'wsid:' + a.workoutSessionId;
    if (a.clientRecordId) return 'crid:' + a.clientRecordId;
    if (a.source && a.sourceRecordId) return 'src:' + a.source + '|' + a.sourceRecordId;
    if (a.id) return 'id:' + a.id;
    return null;   // keine stabile Identität → NICHT deduplizieren
  }

  // Zugriff auf den Legacy-Tagesspeicher DB (data.js: globales `let DB`).
  function getDB() { try { if (typeof DB !== 'undefined') return DB; } catch (e) {} return (typeof window !== 'undefined' && window.DB) ? window.DB : null; }
  // Legacy DB[date].sessions.Gym.exLog → kandidaten im internen Activity-Schema (mit synthetischen Sätzen).
  // Projektionen kanonischer Activities (derivedFromActivity) werden NICHT erneut gezählt.
  function legacyGymCandidates() {
    var db = getDB(); if (!db) return [];
    var out = [];
    try {
      Object.keys(db).forEach(function (k) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(k)) return;
        var s = db[k] && db[k].sessions; var g = s && s.Gym; if (!g) return;
        if (g.derivedFromActivity) return;                  // Projektion → kanonisch existiert
        var log = (g.exLog && g.exLog.length) ? g.exLog : null;
        /* GM7: numerisches sessions.Gym.sets ohne exLog nicht mehr verwerfen — die Session
           zaehlt als Workout, die Saetze laufen bewusst als „nicht zugeordnete Uebung"
           (kein erfundenes Muskel-Mapping; Konfidenz-Reason: unclassified_exercises). */
        if (!log && g.sets != null && g.sets > 0) log = [{ n: 'Krafttraining (ohne Übungsdetail)', sets: g.sets, reps: null, kg: null }];
        if (!log) return;
        var exercises = log.map(function (x) {
          var n = (x.sets != null && x.sets > 0) ? x.sets : ((x.reps != null || x.kg != null) ? 1 : 0);
          var sets = []; for (var i = 0; i < n; i++) sets.push({ set_type: 'working', completed: true, reps: (x.reps != null ? x.reps : 1), weight: (x.kg != null ? x.kg : null) });
          return { exerciseNameSnapshot: x.n, sets: sets };
        });
        out.push({ source: 'legacy_db', sportId: 'gym', status: 'completed', startedAt: k + 'T12:00:00.000Z',
          // Deterministischer, lokaler Schlüssel je Legacy-Session (DB hält max. eine Gym-Session/Tag).
          sourceRecordId: 'legacy:' + k + ':gym',
          workoutSessionId: g.workoutSessionId || g.clientSessionId || null, clientRecordId: g.canonicalActivityId || null, exercises: exercises });
      });
    } catch (e) {}
    return out;
  }

  // Vollständige Pipeline: liefert {snapshots, diagnostics}. Quellen werden in opts übergeben (Server/refresh
  // via gymPipelineAsync). Reine, synchrone Filterung + Diagnose; kein Netzwerk hier.
  function gymPipeline(opts) {
    opts = opts || {}; var store = O.activityStore;
    var days = opts.days || 28; var toMs = Date.now(), fromMs = toMs - (days - 1) * 864e5;
    var local = (store && store.listActivities) ? store.listActivities() : [];
    var server = opts.serverActivities || (O.activityServerCache ? O.activityServerCache() : []) || [];
    var legacy = opts.legacyActivities || legacyGymCandidates();
    var diag = {
      rawLocalActivityCount: local.length, rawServerActivityCount: server.length,
      rawWorkoutSessionCount: (opts.workoutSessions || []).length, rawLegacySessionCount: legacy.length,
      gymCandidatesBeforeDateFilter: 0, gymCandidatesAfterDateFilter: 0, completedCandidates: 0, snapshotCandidates: 0,
      rejectedByReason: { wrongSport: 0, wrongStatus: 0, outsidePeriod: 0, tombstoned: 0, missingSnapshot: 0, missingExercises: 0, malformed: 0 },
      detectedSchemas: []
    };
    function schema(src, arr) { if (!arr || !arr.length) return; var f = {}; arr.slice(0, 8).forEach(function (a) { Object.keys(a || {}).forEach(function (k) { f[k] = 1; }); }); diag.detectedSchemas.push({ source: src, count: arr.length, fields: Object.keys(f) }); }
    schema('activityStore', local); schema('serverActivities', server); schema('legacy_db', legacy); schema('workoutSessions', opts.workoutSessions || []);
    var all = local.concat(server).concat(opts.workoutSessions || []).concat(legacy);
    var seen = {}, out = [];
    all.forEach(function (a) {
      if (!a || typeof a !== 'object') { diag.rejectedByReason.malformed++; return; }
      if (!isGymSport(a)) { diag.rejectedByReason.wrongSport++; return; }
      diag.gymCandidatesBeforeDateFilter++;
      var d = dateOf(a); var t = d ? new Date(d).getTime() : null;
      if (t != null && (t < fromMs || t > toMs)) { diag.rejectedByReason.outsidePeriod++; return; }
      diag.gymCandidatesAfterDateFilter++;
      if (!isCompleted(a)) { diag.rejectedByReason.wrongStatus++; return; }
      diag.completedCandidates++;
      if (store && store.isTombstoned && store.isTombstoned(a)) { diag.rejectedByReason.tombstoned++; return; }
      var exs = exercisesOf(a);
      if (!exs) { diag.rejectedByReason.missingSnapshot++; return; }
      if (!exs.length) { diag.rejectedByReason.missingExercises++; return; }
      var key = dedupKey(a);
      if (key && seen[key]) return;            // Dedup: lokal/Server/Legacy desselben Workouts nur einmal
      if (key) seen[key] = true;
      diag.snapshotCandidates++;
      out.push({ workoutId: a.workoutSessionId || a.clientRecordId || null, startedAt: d, exercises: exs });
    });
    return { snapshots: out, diagnostics: diag };
  }
  function snapshotsFromStore(opts) { return gymPipeline(opts).snapshots; }

  // Auf App-Daten warten (Auth/Stores/Repos), max. ~12 s. Kein Endlos-Warten.
  function gymDataReadiness() {
    return {
      authReady: !!(O.user && O.user.id),
      localStoreReady: !!(O.activityStore && O.activityStore.listActivities),
      activityRepositoryReady: !!(O.repos && O.repos.activity && O.repos.activity.list),
      workoutRepositoryReady: !!(O.repos && O.repos.workout && O.repos.workout.loadWorkoutTree)
    };
  }
  function waitForGymDataDependencies(maxMs) {
    maxMs = maxMs || 12000; var step = 300;
    return new Promise(function (resolve) {
      var waited = 0;
      (function poll() {
        var r = gymDataReadiness();
        /* Phase 4 (2026-08-05): timedOut heisst „aufgegeben OHNE erreichte Bereitschaft" —
           nicht „das Warten hat maxMs erreicht". Vorher wurde eine im letzten Poll doch
           noch bereite Datenlage als timedOut klassifiziert und der Report faelschlich
           auf data_unavailable gekippt, obwohl lokale Daten vorhanden waren. */
        var authGraceMs = Math.min(3000, maxMs);   /* Auth-Wartefrist nie laenger als das Gesamtbudget */
        var ready = r.localStoreReady && (r.authReady || waited >= authGraceMs);
        if (ready || waited >= maxMs) { r.timedOut = !ready; resolve(r); return; }
        waited += step; setTimeout(poll, step);
      })();
    });
  }

  // Asynchrone Quellensammlung: Server-Repo (bei refresh) + Workout-Detail-Nachladen für Server-Gym ohne Snapshot.
  /* Phase 4 (2026-08-05, Perf): Kurzzeit-Cache. renderMuscleVolume() (Dashboard) und
     gmAnaBodyModel() (Analyse-Koerperkarte) verdrahten beide refresh:true — vorher lief
     die volle Server-Quellensammlung bei JEDEM Tab-Wechsel erneut. Der Cache haelt das
     Pipeline-Ergebnis 60 s bzw. bis ein Workout gespeichert/geaendert wird
     (orvia:activity-updated → Invalidierung). Jeder Aufrufer erhaelt eine eigene
     diagnostics-Kopie (buildShadowReport mutiert sie nachtraeglich). */
  var _gymPipeCache = null;                       // { key, at, promise }
  var GYM_PIPE_TTL_MS = 60000;
  function invalidateGymPipelineCache() { _gymPipeCache = null; }
  try { if (typeof window !== 'undefined' && window.addEventListener) window.addEventListener('orvia:activity-updated', invalidateGymPipelineCache); } catch (e) {}
  async function gymPipelineAsync(opts) {
    opts = opts || {};
    /* Nur der teure refresh-Pfad (Server-Round-Trips) wird gecacht. Ohne refresh liest
       die Pipeline rein lokal/synchron — Cachen braechte nichts und wuerde Aenderungen
       am Store verschleiern (z. B. in Umgebungen ohne window/Event-Invalidierung). */
    if (!opts.refresh || opts.force) {
      var direct = await _gymPipelineFetch(opts);
      return { snapshots: direct.snapshots, diagnostics: Object.assign({}, direct.diagnostics) };
    }
    var key = (opts.days || 28) + '|refresh';
    if (_gymPipeCache && _gymPipeCache.key === key && (Date.now() - _gymPipeCache.at) < GYM_PIPE_TTL_MS) {
      var cached = await _gymPipeCache.promise;
      return { snapshots: cached.snapshots, diagnostics: Object.assign({ fromCache: true }, cached.diagnostics) };
    }
    var p = _gymPipelineFetch(opts);
    _gymPipeCache = { key: key, at: Date.now(), promise: p };
    p.catch(function () { if (_gymPipeCache && _gymPipeCache.promise === p) _gymPipeCache = null; });
    var pipe = await p;
    return { snapshots: pipe.snapshots, diagnostics: Object.assign({}, pipe.diagnostics) };
  }
  async function _gymPipelineFetch(opts) {
    opts = opts || {}; var days = opts.days || 28; var calls = [];
    // PERF-INSTRUMENTIERUNG (Audit 2026-07-15): dieser Pfad ist Hauptverdächtiger für die
    // gemeldeten 5-10s-Navigationsverzögerungen (Dashboard/Insights-Tab, refresh:true).
    var P = O.perf || { now: function () { return Date.now(); }, mark: function () {} };
    var _tAll = P.now();
    function call(source, attempted, success, returnedCount, errorCode) { calls.push({ source: source, attempted: attempted, success: success, returnedCount: returnedCount, errorCode: errorCode || null }); }
    var store = O.activityStore;
    var local = (store && store.listActivities) ? store.listActivities() : [];
    call('activityStore', true, !!store, local.length, store ? null : 'STORE_NOT_READY');
    var legacy = legacyGymCandidates();
    call('legacy_db', true, !!getDB(), legacy.length, getDB() ? null : 'NO_DATA_SOURCE');
    // Server: bei refresh authoritative Repository-Abfrage, sonst Cache.
    var server = [];
    if (opts.refresh && O.repos && O.repos.activity && O.repos.activity.list) {
      var _tList = P.now();
      try { var rs = await O.repos.activity.list({ limit: 300 }); if (rs && rs.success) { server = (rs.data || []).map(function (r) { return O.activityConfig ? O.activityConfig.normalizeServerActivity(r) : r; }); call('activityRepository.list', true, true, server.length, null); } else { call('activityRepository.list', true, false, 0, (rs && rs.error && rs.error.code) || 'SERVER_LIST_FAILED'); } }
      catch (e) { call('activityRepository.list', true, false, 0, 'SERVER_LIST_FAILED'); }
      P.mark('gymPipelineAsync: activityRepository.list(limit:300)', _tList);
    } else { server = (O.activityServerCache ? O.activityServerCache() : []) || []; call('activityServerCache', true, true, server.length, null); }
    // Workout-Detail-Nachladen für Server-Gym-Activities mit workoutSessionId aber ohne lokalen Snapshot.
    var workoutSessions = [];
    if (opts.refresh && O.repos && O.repos.workout && O.repos.workout.loadWorkoutTree) {
      var need = server.filter(function (a) { return isGymSport(a) && a.workoutSessionId && !exercisesOf(a); });
      var loadedIds = {}; var detailFails = 0;
      var uniqueIds = [];
      need.forEach(function (a) { var sid = a.workoutSessionId; if (!loadedIds[sid]) { loadedIds[sid] = true; uniqueIds.push(sid); } });
      var _tLoop = P.now();
      /* Phase 4 (2026-08-05, Perf): vorher EINE sequentielle await-Round-Trip PRO fehlendem
         Snapshot — im Code selbst als Ursache der 5–10 s-Verzoegerung markiert. Jetzt
         Promise.all: Wall-Clock = langsamster Einzelabruf statt Summe aller Abrufe.
         Fehler je Abruf bleiben einzeln gezaehlt (WORKOUT_DETAILS_FAILED wie zuvor). */
      var loaded = await Promise.all(uniqueIds.map(function (sid) {
        return O.repos.workout.loadWorkoutTree(sid)
          .then(function (tr) { return { sid: sid, tr: tr }; })
          .catch(function () { return { sid: sid, tr: null }; });
      }));
      loaded.forEach(function (r) {
        var tr = r.tr;
        if (tr && tr.success && tr.data && tr.data.session) {
          var exs = (tr.data.exercises || []).map(function (ex) { return { exerciseNameSnapshot: (ex.exercise && ex.exercise.name) || null, sets: (ex.sets || []) }; });
          workoutSessions.push({ source: 'workout_session', sportId: 'gym', status: 'completed', startedAt: tr.data.session.started_at || tr.data.session.local_date, workoutSessionId: r.sid, exercises: exs });
        } else detailFails++;
      });
      P.mark('gymPipelineAsync: parallel loadWorkoutTree (' + uniqueIds.length + ' round-trips via Promise.all)', _tLoop);
      call('workoutRepository.loadWorkoutTree', need.length > 0, detailFails === 0, workoutSessions.length, detailFails ? 'WORKOUT_DETAILS_FAILED' : null);
    }
    var pipe = gymPipeline({ days: days, serverActivities: server, legacyActivities: legacy, workoutSessions: workoutSessions });
    pipe.diagnostics.sourceCalls = calls;
    P.mark('gymPipelineAsync: TOTAL', _tAll);
    return pipe;
  }

  // ---- On-Device-Shadow-Report (rein, serialisierbar, KEIN Netzwerk, KEINE Mutation) ----
  // Storage-Key → anonymisierte KATEGORIE (nie der echte Key/UUID).
  function keyCategory(k) {
    if (/orvia_activities_/.test(k)) return 'activities';
    if (/orvia_activity_tombstones/.test(k)) return 'activity_tombstones';
    if (/orvia_active_workout/.test(k)) return 'active_workout';
    if (/onboarding/.test(k)) return 'onboarding';
    if (/profile/.test(k)) return 'profile';
    if (/checkin/.test(k)) return 'checkin';
    if (/readiness/.test(k)) return 'readiness';
    if (/sync|revision/.test(k)) return 'sync_revision';
    if (/owner|data_owner/.test(k)) return 'data_owner';
    if (/user|auth/.test(k)) return 'active_user';
    if (/env|device/.test(k)) return 'device';
    if (/^orvia/.test(k)) return 'other_orvia';
    return null;
  }
  function storageInspection() {
    var out = { availableKeyTypes: [], matchingKeyCounts: {} };
    try {
      if (typeof localStorage === 'undefined' || !localStorage) return out;
      var keys = []; try { for (var i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i)); } catch (e) { keys = Object.keys(localStorage); }
      var typeset = {};
      keys.forEach(function (k) {
        if (!k) return; var cat = keyCategory(k); if (!cat) return; typeset[cat] = 1;
        if (cat === 'activities') { try { var v = JSON.parse(localStorage.getItem(k)); out.matchingKeyCounts.activities = (out.matchingKeyCounts.activities || 0) + (Array.isArray(v) ? v.length : 0); } catch (e) {} }
      });
      out.availableKeyTypes = Object.keys(typeset);
    } catch (e) {}
    return out;
  }
  // Globaler Sanitizer: entfernt UUID-/E-Mail-/JWT-Werte und sensible Felder aus dem gesamten Report.
  function sanitizeReport(obj) {
    var uuid = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/ig;
    var email = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
    var jwt = /eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{4,}/g;
    var DROP = /^(userid|user_id|email|token|access_token|refresh_token|jwt|authorization|apikey|api_key)$/i;
    function clean(v) {
      if (typeof v === 'string') return v.replace(uuid, '[redacted]').replace(jwt, '[redacted]').replace(email, '[redacted]');
      if (Array.isArray(v)) return v.map(clean);
      if (v && typeof v === 'object') { var o = {}; Object.keys(v).forEach(function (k) { if (DROP.test(k)) return; o[k] = clean(v[k]); }); return o; }
      return v;
    }
    return clean(obj);
  }
  function visibleActivityPipeline(pipe) {
    pipe = pipe || {};
    var info = { functionName: null, resultCount: null, gymResultCount: null,
      gymRealWorkoutCount: (pipe.diagnostics && pipe.diagnostics.snapshotCandidates) || 0,   // AUTHORITATIV: echte Workouts mit Sätzen
      gymCheckinOnlyCount: 0, gymEmptyCount: 0, gymProjectionCount: 0, gymLegacyCount: 0, gymCanonicalCount: 0, gymDuplicateGroups: 0 };
    try {
      // Sichtbare Liste nur für resultCount/gymResultCount (Mismatch-Erkennung), NICHT für „echte Workouts".
      if (typeof window !== 'undefined' && typeof window.listActivitiesUnified === 'function') {
        info.functionName = 'listActivitiesUnified';
        var list = window.listActivitiesUnified(2000) || [];
        info.resultCount = list.length;
        info.gymResultCount = list.filter(function (a) { return isGymSport(a); }).length;
      }
      // Strikte Aufschlüsselung aus den Rohquellen (DB-Legacy + Store/Server kanonisch).
      var db = getDB(); var dayGroups = {};
      if (db) {
        Object.keys(db).forEach(function (k) {
          if (!/^\d{4}-\d{2}-\d{2}$/.test(k)) return; var g = db[k] && db[k].sessions && db[k].sessions.Gym; if (!g) return;
          info.gymLegacyCount++; dayGroups[k] = (dayGroups[k] || 0) + 1;
          if (g.derivedFromActivity) { info.gymProjectionCount++; return; }
          var hasSets = g.exLog && g.exLog.some(function (x) { return (x.sets != null && x.sets > 0) || x.reps != null || x.kg != null; });
          if (hasSets) { /* echtes Legacy-Workout: zählt bereits via snapshotCandidates */ }
          else if (g.dur != null && g.dur > 0) info.gymCheckinOnlyCount++;   // nur Dauer/Check-in, kein Satzprotokoll
          else info.gymEmptyCount++;
        });
      }
      var store = O.activityStore; var canon = [];
      if (store && store.listActivities) canon = store.listActivities().filter(function (a) { return a.source === 'orvia_workout'; });
      var server = (O.activityServerCache ? O.activityServerCache() : []).filter(function (a) { return a && a.source === 'orvia_workout'; });
      info.gymCanonicalCount = canon.length + server.length;
      canon.concat(server).forEach(function (a) { var d = (a.startedAt || '').slice(0, 10); if (d) dayGroups[d] = (dayGroups[d] || 0) + 1; });
      Object.keys(dayGroups).forEach(function (d) { if (dayGroups[d] > 1) info.gymDuplicateGroups++; });
    } catch (e) {}
    return info;
  }
  async function buildShadowReport(opts) {
    opts = opts || {}; var days = opts.days || 28;
    var P = O.perf || { now: function () { return Date.now(); }, mark: function () {} };
    var _tReport = P.now();
    var _t = P.now();
    var readiness = await waitForGymDataDependencies(opts.maxWaitMs);
    P.mark('buildShadowReport: waitForGymDataDependencies', _t);
    _t = P.now();
    var pipe = await gymPipelineAsync({ days: days, refresh: opts.refresh });
    P.mark('buildShadowReport: gymPipelineAsync', _t);
    pipe.diagnostics.readiness = readiness;
    _t = P.now();
    pipe.diagnostics.storageInspection = storageInspection();
    P.mark('buildShadowReport: storageInspection (full localStorage key scan)', _t);
    _t = P.now();
    pipe.diagnostics.visibleActivityPipeline = visibleActivityPipeline(pipe);
    P.mark('buildShadowReport: visibleActivityPipeline', _t);
    _t = P.now();
    var snaps = pipe.snapshots;
    var res = computeMuscleVolume(snaps);
    P.mark('buildShadowReport: computeMuscleVolume', _t);
    var toMs = Date.now(), fromMs = toMs - (days - 1) * 864e5;
    var weeks = Math.round((days / 7) * 10) / 10;
    var exerciseCount = 0, validSets = 0;
    snaps.forEach(function (w) { (w.exercises || []).forEach(function (e) { exerciseCount++; validSets += realSetsOf(e); }); });
    var legacy = opts.legacyByMuscle || null;   // Server-Legacy offline nicht verfügbar → optional übergeben
    var workoutCount = snaps.length;
    var legacySynthetic = snaps.length > 0 && (pipe.diagnostics.rawLegacySessionCount > 0) && pipe.diagnostics.snapshotCandidates <= pipe.diagnostics.rawLegacySessionCount && (pipe.diagnostics.rawLocalActivityCount + pipe.diagnostics.rawServerActivityCount + (pipe.diagnostics.rawWorkoutSessionCount || 0) === 0);
    var muscles = MUSCLES.map(function (mk) {
      var m = res.byMuscle[mk]; var eff = m ? m.effectiveSets : 0;
      var lv = (legacy && legacy[mk] != null) ? legacy[mk] : null;
      var conf = confidenceOf({ weeks: weeks, totalSets: m ? m.realWorkingSets : 0, unclassifiedRatio: 0 });
      var confReason = null;
      // Legacy-synthetische Sätze / wenige Workouts / <2 Wochen → Konfidenz konservativ auf 'low'.
      if (legacySynthetic) { conf = 'low'; confReason = 'legacy_synthetic_data'; }
      else if (workoutCount < 4) { conf = 'low'; confReason = 'too_few_workouts'; }
      else if (weeks < 2) { conf = 'low'; confReason = 'too_short_period'; }
      var target = targetCorridor({ goal: opts.goal, experience: opts.experience, dataWeeks: weeks });
      // displayStatus: bei <2 Wochen / wenig Workouts / niedriger Konfidenz / Legacy-synthetisch KEIN
      // vermeintlich personalisierter Sollwert anzeigen.
      target.displayStatus = (weeks < 2 || workoutCount < 4 || conf === 'low' || legacySynthetic || target.source === 'insufficient_data' || target.source === 'strength_movement_based') ? 'insufficient_data' : 'ok';
      return {
        muscleId: mk, label: MUSCLE_LABEL[mk],
        realWorkingSets: m ? m.realWorkingSets : 0, directSets: m ? m.directSets : 0,
        indirectSetEquivalents: m ? m.indirectSetEquivalents : 0, effectiveSetEquivalents: eff,
        weeklyEquivalent: weeklyEquivalent(eff, days),
        legacyValue: lv, differenceToLegacy: lv != null ? Math.round((eff - lv) * 10) / 10 : null,
        targetRange: target, confidence: conf, confidenceReason: confReason
      };
    }).filter(function (x) { return x.realWorkingSets > 0 || x.legacyValue != null; });
    var unclassifiedExercises = Object.keys(res.unclassified).map(function (n) { return { exerciseId: null, exerciseName: n, occurrenceCount: res.unclassified[n].occurrenceCount, workingSetCount: res.unclassified[n].workingSetCount }; });
    var exclusionsByReason = {}; res.exclusions.forEach(function (e) { exclusionsByReason[e.reason] = (exclusionsByReason[e.reason] || 0) + 1; });
    var dg = pipe.diagnostics;
    var anyRaw = (dg.rawLocalActivityCount + dg.rawServerActivityCount + dg.rawWorkoutSessionCount + dg.rawLegacySessionCount) > 0;
    /* KF-005: erwartbare Nicht-Verfuegbarkeit ist KEIN Fehler. offline, keine
       Session und ein leerer Legacy-Blob (NO_DATA_SOURCE) sind Normalzustaende —
       ein reiner Garmin-/Cloud-Nutzer hat schlicht keinen Tages-Blob, und offline
       ist ein Zustand, kein Defekt. Vorher kippte jeder dieser Normalzustaende
       die Muskelkarte in „konnte nicht geladen werden". Echte Fehler (Store kaputt,
       Server-Liste fehlgeschlagen, Workout-Details fehlgeschlagen) bleiben Fehler. */
    var EXPECTED_UNAVAILABLE = { offline: true, no_session: true, NO_DATA_SOURCE: true };
    var anyFail = (dg.sourceCalls || []).some(function (c) {
      return c.attempted && !c.success && !EXPECTED_UNAVAILABLE[c.errorCode];
    });
    var visGym = dg.visibleActivityPipeline && dg.visibleActivityPipeline.gymResultCount;
    var reportStatus;
    /* Phase 4: massgeblich ist der Store — timedOut impliziert nach der neuen Semantik
       !localStoreReady; ein bereiter Store mit vorhandenen Daten wird nie mehr allein
       wegen einer abgelaufenen Wartefrist als data_unavailable fehlklassifiziert. */
    if (!readiness.localStoreReady) reportStatus = 'data_unavailable';
    else if (snaps.length > 0) reportStatus = anyFail ? 'partial_data' : 'ok';
    else if (!anyRaw) reportStatus = 'data_unavailable';
    else reportStatus = anyFail ? 'load_error' : 'no_gym_workouts';
    var warnings = [];
    if (reportStatus === 'data_unavailable') warnings.push('NO_DATA_SOURCE');
    if (reportStatus === 'no_gym_workouts') warnings.push('Keine abgeschlossenen Gym-Workouts im Zeitraum.');
    if (visGym && snaps.length === 0) warnings.push('ACTIVITY_PIPELINE_MISMATCH');
    var vap = dg.visibleActivityPipeline || {};
    // NUR bei belegter Duplikation (echte Mehrfach-Gruppen am selben Tag); viele Check-in-only-Tage
    // sind KEINE Duplikation → separate, neutrale Info.
    if (vap.gymDuplicateGroups > 0) warnings.push('VISIBLE_GYM_DUPLICATION_SUSPECTED');
    if (vap.gymCheckinOnlyCount > 0) warnings.push('VISIBLE_GYM_CHECKIN_ENTRIES_PRESENT');
    if (anyFail) warnings.push('Teilweise Quelle nicht geladen.');
    if (unclassifiedExercises.length) warnings.push(unclassifiedExercises.length + ' unklassifizierte Übung(en) — bitte melden.');
    if (weeks < 2) warnings.push('Weniger als 2 Wochen Daten — Korridor/Empfehlung unsicher.');
    var report = {
      generatedAt: new Date().toISOString(), mappingVersion: MAPPING_VERSION, reportStatus: reportStatus,
      period: { days: days, from: new Date(fromMs).toISOString().slice(0, 10), to: new Date(toMs).toISOString().slice(0, 10) },
      source: { workoutCount: snaps.length, exerciseCount: exerciseCount, validWorkingSetCount: validSets, excludedSetCount: res.exclusions.length },
      muscles: muscles, unclassifiedExercises: unclassifiedExercises, exclusionsByReason: exclusionsByReason, warnings: warnings,
      diagnostics: dg
    };
    _t = P.now();
    var _sanitized = sanitizeReport(report);   // entfernt jegliche UUID-/E-Mail-/Token-Werte aus dem gesamten Report
    P.mark('buildShadowReport: sanitizeReport (recursive regex clean)', _t);
    P.mark('buildShadowReport: TOTAL', _tReport);
    return _sanitized;
  }
  // Produktives Modell für die Muskelübersicht/Body-Map. Nutzt dieselbe getestete Pipeline/Berechnung.
  async function getProductiveVolumeModel(opts) {
    opts = opts || {};
    var r = await buildShadowReport({ days: opts.days || 28, refresh: opts.refresh !== false, goal: opts.goal, experience: opts.experience });
    var muscles = r.muscles.map(function (m) {
      var st = (m.targetRange && m.targetRange.displayStatus === 'insufficient_data')
        ? { key: 'insufficient_data', label: 'Noch nicht ausreichend bewertet' }
        : statusFor(m.weeklyEquivalent, m.targetRange);
      return {
        muscleId: m.muscleId, label: m.label, realWorkingSets: m.realWorkingSets, directSets: m.directSets,
        indirectSetEquivalents: m.indirectSetEquivalents, effectiveSetEquivalents: m.effectiveSetEquivalents,
        weeklyEquivalent: m.weeklyEquivalent, confidence: m.confidence, confidenceReason: m.confidenceReason || null,
        targetRange: m.targetRange, status: st, explanationAvailable: m.realWorkingSets > 0
      };
    });
    var fallbackUsed = (r.reportStatus === 'data_unavailable' || r.reportStatus === 'load_error');
    return {
      status: r.reportStatus, period: r.period, source: r.source, muscles: muscles, warnings: r.warnings,
      sourceQuality: { confidence: muscles.length ? muscles[0].confidence : 'low', confidenceReason: muscles.length ? muscles[0].confidenceReason : null },
      fallbackUsed: fallbackUsed
    };
  }
  // Konsolen-Diagnose (verändert nichts).
  async function printShadowReport(opts) {
    var r = await buildShadowReport(opts);
    try {
      console.log('[ORVIA Shadow] Zeitraum ' + r.period.from + '–' + r.period.to + ' · Workouts: ' + r.source.workoutCount + ' · gültige Sätze: ' + r.source.validWorkingSetCount + ' · ausgeschlossen: ' + r.source.excludedSetCount);
      if (console.table) console.table(r.muscles.map(function (m) { return { Muskel: m.label, real: m.realWorkingSets, direkt: m.directSets, indirekt: m.indirectSetEquivalents, effektiv: m.effectiveSetEquivalents, woche: m.weeklyEquivalent, legacy: m.legacyValue, diff: m.differenceToLegacy }; }));
      if (r.unclassifiedExercises.length) console.warn('[ORVIA Shadow] unklassifiziert:', r.unclassifiedExercises);
      console.log('[ORVIA Shadow] Ausschlüsse:', r.exclusionsByReason, '· Warnungen:', r.warnings);
    } catch (e) {}
    return r;
  }
  // iPhone-tauglicher Diagnosezugang: eigenständiges Modal mit kopierbarem JSON (nicht in der normalen UI).
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); }
  function summaryHTML(r) {
    var lines = [];
    lines.push('Zeitraum: ' + r.period.from + ' – ' + r.period.to + ' (' + r.period.days + ' Tage)');
    lines.push('Gym-Workouts: ' + r.source.workoutCount + ' · gültige Arbeitssätze: ' + r.source.validWorkingSetCount + ' · ausgeschlossen: ' + r.source.excludedSetCount);
    var ms = r.muscles.map(function (m) { return esc(m.label) + ': ' + m.realWorkingSets + ' real / ' + m.directSets + ' direkt + ' + m.indirectSetEquivalents + ' indirekt = ' + m.effectiveSetEquivalents + ' eff (' + m.weeklyEquivalent + '/Wo)' + (m.differenceToLegacy != null ? ' · Δalt ' + m.differenceToLegacy : ''); });
    var unk = r.unclassifiedExercises.map(function (u) { return esc(u.exerciseName) + ' (' + u.workingSetCount + ')'; });
    var html = '<div style="font:13px/1.6 system-ui;color:#cbd5e1">' +
      lines.map(function (l) { return '<div>' + esc(l) + '</div>'; }).join('') +
      (ms.length ? '<div style="margin-top:8px;font-weight:700;color:#dcc79a">Muskeln</div>' + ms.map(function (l) { return '<div>' + l + '</div>'; }).join('') : '<div style="margin-top:8px;color:#94a3b8">Keine Muskelwerte im Zeitraum.</div>') +
      (unk.length ? '<div style="margin-top:8px;font-weight:700;color:#fb923c">Unklassifiziert</div><div>' + unk.join(', ') + '</div>' : '') +
      (r.warnings.length ? '<div style="margin-top:8px;font-weight:700;color:#fb7185">Warnungen</div>' + r.warnings.map(function (w) { return '<div>' + esc(w) + '</div>'; }).join('') : '') +
      (r.diagnostics ? '<div style="margin-top:8px;font-weight:700;color:#94a3b8">Diagnose</div>' +
        '<div>lokal: ' + r.diagnostics.rawLocalActivityCount + ' · server: ' + r.diagnostics.rawServerActivityCount + ' · Gym-Kandidaten: ' + r.diagnostics.gymCandidatesBeforeDateFilter + ' → im Zeitraum: ' + r.diagnostics.gymCandidatesAfterDateFilter + ' → mit Snapshot: ' + r.diagnostics.snapshotCandidates + '</div>' +
        '<div>abgelehnt: ' + esc(JSON.stringify(r.diagnostics.rejectedByReason)) + '</div>' : '') +
      '</div>';
    return html;
  }
  async function showShadowReport(opts) {
    if (typeof document === 'undefined') return buildShadowReport(opts);
    // Ladezustand sofort anzeigen.
    var load = document.createElement('div');
    load.setAttribute('style', 'position:fixed;inset:0;z-index:99999;background:rgba(4,6,10,.9);display:flex;align-items:center;justify-content:center;color:#cbd5e1;font:14px system-ui');
    load.innerHTML = '<div>Gym-Daten werden geladen …</div>';
    document.body.appendChild(load);
    var r;
    try { r = await buildShadowReport(Object.assign({ refresh: true }, opts)); }
    catch (e) { load.innerHTML = '<div style="text-align:center"><div>Gym-Daten konnten nicht geladen werden.</div><button id="sr-x" style="margin-top:12px;min-height:44px;padding:0 16px;border-radius:10px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.04);color:#e2e8f0">Schließen</button></div>'; load.querySelector('#sr-x').onclick = function () { try { load.remove(); } catch (e2) {} }; return null; }
    try { load.remove(); } catch (e) {}
    var json = JSON.stringify(r, null, 2);
    try {
      var bg = document.createElement('div');
      bg.setAttribute('style', 'position:fixed;inset:0;z-index:99999;background:rgba(4,6,10,.9);display:flex;align-items:center;justify-content:center;padding:16px;-webkit-overflow-scrolling:touch');
      bg.innerHTML = '<div style="width:100%;max-width:560px;max-height:88vh;display:flex;flex-direction:column;background:#0d131d;border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:14px;overflow:auto">' +
        '<div style="font-weight:700;color:#dcc79a;margin-bottom:8px">Gym-Shadow-Report</div>' +
        '<div id="sr-sum" style="margin-bottom:10px"></div>' +
        '<textarea id="sr-ta" readonly style="min-height:220px;width:100%;font:12px/1.4 monospace;color:#cbd5e1;background:#0b1118;border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:10px"></textarea>' +
        '<div id="sr-msg" style="font:12px system-ui;color:#34d399;min-height:16px;margin-top:6px"></div>' +
        '<div style="display:flex;gap:8px;margin-top:6px">' +
        '<button id="sr-copy" style="flex:1;min-height:44px;border-radius:10px;border:1px solid rgba(201,174,124,.4);background:rgba(201,174,124,.16);color:#dcc79a">Report kopieren</button>' +
        '<button id="sr-close" style="flex:1;min-height:44px;border-radius:10px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.04);color:#e2e8f0">Schließen</button></div></div>';
      document.body.appendChild(bg);
      bg.querySelector('#sr-sum').innerHTML = summaryHTML(r);
      var ta = bg.querySelector('#sr-ta'); ta.value = json;
      var msg = bg.querySelector('#sr-msg');
      bg.querySelector('#sr-close').onclick = function () { try { bg.remove(); } catch (e) {} };
      bg.querySelector('#sr-copy').onclick = function () {
        var done = function () { msg.style.color = '#34d399'; msg.textContent = 'Report kopiert'; };
        var manual = function () { try { ta.focus(); ta.select(); ta.setSelectionRange(0, json.length); } catch (e) {} msg.style.color = '#fb923c'; msg.textContent = 'Text markieren und kopieren'; };
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(json).then(done).catch(function () { try { ta.select(); if (document.execCommand('copy')) done(); else manual(); } catch (e) { manual(); } }); }
          else { ta.select(); if (document.execCommand && document.execCommand('copy')) done(); else manual(); }
        } catch (e) { manual(); }
      };
      bg.addEventListener('click', function (ev) { if (ev.target === bg) { try { bg.remove(); } catch (e) {} } });
    } catch (e) {}
    return r;
  }

  var api = {
    MAPPING_VERSION: MAPPING_VERSION, MUSCLES: MUSCLES, MUSCLE_LABEL: MUSCLE_LABEL,
    buildShadowReport: buildShadowReport, printShadowReport: printShadowReport, showShadowReport: showShadowReport,
    getProductiveVolumeModel: getProductiveVolumeModel,
    COUNTABLE_SET_TYPES: COUNTABLE_SET_TYPES, DIRECT: DIRECT, INDIRECT: INDIRECT,
    EXERCISE_MUSCLES: EXERCISE_MUSCLES, NAME_MUSCLES: NAME_MUSCLES, PATTERN_MUSCLES: PATTERN_MUSCLES,
    coeffOf: coeffOf, roleOf: roleOf, isCountable: isCountable, setExclusionReason: setExclusionReason,
    realSetsOf: realSetsOf, musclesFor: musclesFor, isClassified: isClassified,
    computeMuscleVolume: computeMuscleVolume, weeklyEquivalent: weeklyEquivalent,
    targetCorridor: targetCorridor, confidenceOf: confidenceOf, statusFor: statusFor,
    explainMuscleVolume: explainMuscleVolume, compareToLegacy: compareToLegacy, snapshotsFromStore: snapshotsFromStore,
    gymPipeline: gymPipeline, volumeAdvice: volumeAdvice, CORRIDORS: CORRIDORS,
    invalidateGymPipelineCache: invalidateGymPipelineCache
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  O.gymVolume = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
