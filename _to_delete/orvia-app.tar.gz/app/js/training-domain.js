/* ============================================================
   ORVIA · training-domain — Fachliche Konstanten + DTO-Mapper (Phase 4.1, NUR Modell)
   Single Source of Truth für Enums/Schlüssel der Trainingsdomäne (deckt sich mit 0003-Seeds).
   KEINE Plan-Engine, KEINE Volumen-Ampel, KEINE Berechnungen — nur Modell + Mapping + Validierung.
   ============================================================ */
(function () {
  window.ORVIA = window.ORVIA || {};
  const O = window.ORVIA;

  const D = {
    // --- Sportarten & Positionen ---
    SPORTS: ['gym', 'running', 'cycling', 'swimming', 'triathlon', 'football', 'handball', 'padel', 'tennis', 'athletics'],
    SPORT_ROLES: ['main', 'supplemental', 'occasional', 'club'],
    POSITIONS: {
      football: ['gk', 'cb', 'fb', 'dm', 'cm', 'am', 'wing', 'st'],
      handball: ['gk', 'wing', 'back', 'center', 'pivot']
    },
    SEASON_PHASES: ['offseason', 'preseason', 'inseason', 'transition'],
    EXPERIENCE_LEVELS: ['beginner', 'intermediate', 'experienced', 'performance', 'pro'],

    // --- Ziele ---
    GOAL_TYPES: ['hypertrophy', 'aesthetic_hypertrophy', 'max_strength', 'powerbuilding', 'fat_loss_muscle',
      'general_fitness', 'athletic', 'explosiveness', 'speed', 'injury_prevention', 'endurance',
      'competition_prep', 'sport_performance', 'maintenance'],
    GYM_GOAL_TYPES: ['hypertrophy', 'aesthetic_hypertrophy', 'max_strength', 'powerbuilding', 'athletic',
      'sport_specific_strength', 'explosiveness', 'robustness', 'injury_prevention', 'maintenance', 'comeback'],
    GOAL_PRIORITIES: ['primary', 'secondary', 'optional'],
    GOAL_STATUS: ['active', 'paused', 'completed'],

    // --- Bewegungsmuster (deckt sich mit movement_patterns-Seeds) ---
    MOVEMENT_PATTERNS: ['horizontal_push', 'vertical_push', 'horizontal_pull', 'vertical_pull', 'squat', 'hinge',
      'lunge', 'knee_flexion', 'knee_extension', 'hip_extension', 'hip_adduction', 'hip_abduction', 'calf',
      'elbow_flexion', 'elbow_extension', 'shoulder_abduction',
      'shoulder_extension', 'trunk_flexion', 'trunk_extension', 'rotation', 'anti_rotation', 'carry', 'jump',
      'sprint', 'change_of_direction', 'throw', 'stability', 'mobility'],

    // --- Muskelgruppen (Schlüssel + Körperregion/Seite/Ansicht für spätere Körperkarte) ---
    MUSCLE_GROUPS: [
      { key: 'chest', region: 'torso', view: 'front' }, { key: 'front_delts', region: 'torso', view: 'front' },
      { key: 'side_delts', region: 'torso', view: 'front' }, { key: 'rear_delts', region: 'torso', view: 'back' },
      { key: 'biceps', region: 'arms', view: 'front' }, { key: 'triceps', region: 'arms', view: 'back' },
      { key: 'forearms', region: 'arms', view: 'front' }, { key: 'abs', region: 'core', view: 'front' },
      { key: 'lats', region: 'torso', view: 'back' }, { key: 'upper_back', region: 'torso', view: 'back' },
      { key: 'traps', region: 'torso', view: 'back' }, { key: 'lower_back', region: 'core', view: 'back' },
      { key: 'quads', region: 'legs', view: 'front' }, { key: 'hamstrings', region: 'legs', view: 'back' },
      { key: 'glutes', region: 'legs', view: 'back' }, { key: 'adductors', region: 'legs', view: 'front' },
      { key: 'abductors', region: 'legs', view: 'front' }, { key: 'calves', region: 'legs', view: 'back' },
      { key: 'hip_flexors', region: 'legs', view: 'front' }
    ],
    MUSCLE_INVOLVEMENT: ['direct', 'indirect'],
    // Spätere Körperkarten-Zustände (noch KEINE Grenzwerte berechnet) — nur Vokabular.
    BODY_MAP_STATES: ['no_data', 'insufficient', 'under_target', 'optimal', 'over_target', 'overloaded', 'not_prioritized'],
    MUSCLE_PRIORITIES: ['weak_point', 'normal', 'maintain', 'not_prioritized', 'sport_specific'],

    // --- Equipment & Umgebung ---
    EQUIPMENT: ['barbell', 'dumbbell', 'cable', 'machine', 'smith', 'pullup_bar', 'dip_bars', 'band', 'kettlebell',
      'bodyweight', 'rack', 'bench', 'leg_press', 'treadmill', 'ergometer', 'open_floor'],
    ENVIRONMENTS: ['full_gym', 'home_gym', 'minimal', 'none'],

    // --- Trainingsqualitäten (sportartspezifisch nutzbar) ---
    TRAINING_QUALITIES: ['hypertrophy', 'max_strength', 'power', 'speed', 'acceleration', 'cod', 'jump', 'robustness',
      'aerobic', 'threshold', 'vo2max', 'running_economy', 'core_stability', 'single_leg', 'injury_prevention'],

    // --- Pläne / Splits ---
    SPLIT_TYPES: ['full_body', 'upper_lower', 'push_pull', 'push_pull_legs', 'torso_limbs', 'upper_lower_full',
      'push_full_pull_full', 'arnold', 'bro_split', 'powerbuilding', 'sport_specific_strength', 'custom'],
    PLAN_STATUS: ['draft', 'active', 'archived'],

    // --- Workout / Sätze ---
    // Deckungsgleich mit 0004/0005-Constraint. 'aborted' = begonnen, vorzeitig beendet;
    // 'cancelled' = geplante Session vor Start abgesagt; 'paused' = pausiert (Live-Fluss nutzt
    // jedoch status='active' + paused_at, 'paused' ist als Wert dennoch gültig).
    SESSION_STATUS: ['planned', 'active', 'paused', 'completed', 'skipped', 'cancelled', 'aborted', 'legacy'],
    SESSION_STATUS_LABELS: { planned: 'Geplant', active: 'Aktiv', paused: 'Pausiert', completed: 'Fertig', skipped: 'Übersprungen', cancelled: 'Abgesagt', aborted: 'Abgebrochen', legacy: 'Altbestand' },
    SET_TYPES: ['warmup', 'working', 'top_set', 'backoff', 'dropset', 'rest_pause', 'myo_reps', 'amrap', 'technique', 'test'],

    // --- Beschwerden / Einschränkungen (Anschluss an daily_checkins complaints) ---
    COMPLAINT_REGIONS: ['knee', 'back', 'hip', 'shoulder', 'ankle', 'shin', 'foot', 'neck', 'elbow', 'wrist'],
    RESTRICTION_RULES: ['avoid', 'reduce', 'alternative']
  };

  // Sportart-Normalisierung → konsistenter lowercase-Key (verhindert getrennte Kategorien
  // für dieselbe Sportart, z.B. 'Gym'/'gym'/'Krafttraining' oder 'Laufen'/'run').
  // ENTSCHEIDUNG Mobilität: KEINE eigenständige Hauptsportart. Sie ist eine Modalität
  // (session_type='mobility') und wird sportartlich der Kraftkategorie zugeordnet → sport_key='gym'.
  // Dadurch liefert normSport() nur Keys, die valid.sport() akzeptiert (kein 'mobility' als Sport).
  const SPORT_ALIASES = {
    gym: 'gym', krafttraining: 'gym', kraft: 'gym', strength: 'gym', 'strength training': 'gym', traditional_strength_training: 'gym',
    // Mobility ist eine EIGENE kanonische Sportart (NICHT 'gym'): darf nie in Gym-Statistik/Muskelvolumen fließen.
    'mobilität': 'mobility', mobilitaet: 'mobility', mobility: 'mobility', 'mobility training': 'mobility',
    laufen: 'running', lauf: 'running', run: 'running', running: 'running',
    rad: 'cycling', radsport: 'cycling', radfahren: 'cycling', bike: 'cycling', cycling: 'cycling', ride: 'cycling',
    schwimmen: 'swimming', swim: 'swimming', swimming: 'swimming',
    'fußball': 'football', fussball: 'football', football: 'football', soccer: 'football',
    handball: 'handball', padel: 'padel', paddel: 'padel', tennis: 'tennis', triathlon: 'triathlon',
    athletics: 'athletics', leichtathletik: 'athletics', athletik: 'athletics',
    basketball: 'basketball', korbball: 'basketball',
    rudern: 'rowing', rowing: 'rowing',
    wandern: 'hiking', hiking: 'hiking',
    gehen: 'walking', walking: 'walking', spazieren: 'walking',
    andere: 'other', sonstige: 'other', sonstiges: 'other', other: 'other'
  };
  // Aktivitäts-Sportarten = trainierbare SPORTS + erfassbare Zusatzsportarten (decken sich mit
  // onboardingSportsLogic.SPORT_CATALOG). sport_key ist freier Text (kein DB-CHECK), daher sicher.
  const ACTIVITY_SPORTS = D.SPORTS.concat(['basketball', 'rowing', 'hiking', 'walking', 'mobility', 'other']);
  // STRIKT: bekannte Sportart → kanonische ID, sonst null. KEIN Raten (früher fälschlich 'athletics').
  function normSportStrict(v) { if (v == null) return null; const s = String(v).trim().toLowerCase(); if (SPORT_ALIASES[s]) return SPORT_ALIASES[s]; return ACTIVITY_SPORTS.indexOf(s) >= 0 ? s : null; }
  // SICHER: wie strikt, aber unbekannt → neutral 'other' (gültiger Aktivitäts-Key, fabriziert keine
  // falsche Sportidentität wie zuvor 'athletics'). Für sport_key-Ableitung in Repos/Store.
  function normSport(v) { if (v == null) return null; return normSportStrict(v) || 'other'; }

  // --- Deutsche Anzeige-Labels (keine technischen Keys in der UI) ---
  const MOVEMENT_LABELS = {
    horizontal_push: 'Horizontal drücken', vertical_push: 'Vertikal drücken', horizontal_pull: 'Horizontal ziehen',
    vertical_pull: 'Vertikal ziehen', squat: 'Kniebeuge', hinge: 'Hüftbeuge', lunge: 'Ausfallschritt',
    knee_flexion: 'Kniebeugung', hip_extension: 'Hüftstreckung', calf: 'Wade', elbow_flexion: 'Armbeugung',
    elbow_extension: 'Armstreckung', shoulder_abduction: 'Seitheben', shoulder_extension: 'Schulterstreckung',
    trunk_flexion: 'Rumpfbeugung', trunk_extension: 'Rumpfstreckung', rotation: 'Rotation', anti_rotation: 'Anti-Rotation',
    carry: 'Tragen', jump: 'Sprung', sprint: 'Sprint', change_of_direction: 'Richtungswechsel', throw: 'Wurf',
    stability: 'Stabilität', mobility: 'Mobilität',
    knee_extension: 'Beinstreckung', hip_adduction: 'Adduktion', hip_abduction: 'Abduktion'
  };
  const MUSCLE_LABELS = {
    chest: 'Brust', front_delts: 'Vordere Schulter', side_delts: 'Seitliche Schulter', rear_delts: 'Hintere Schulter',
    biceps: 'Bizeps', triceps: 'Trizeps', forearms: 'Unterarme', abs: 'Bauch', lats: 'Lat/Breiter Rücken',
    upper_back: 'Oberer Rücken', traps: 'Trapez', lower_back: 'Unterer Rücken', quads: 'Quadrizeps',
    hamstrings: 'Beinbeuger', glutes: 'Gesäß', adductors: 'Adduktoren', abductors: 'Abduktoren', calves: 'Waden',
    hip_flexors: 'Hüftbeuger'
  };
  const EQUIPMENT_LABELS = {
    barbell: 'Langhantel', dumbbell: 'Kurzhantel', cable: 'Kabelzug', machine: 'Maschine', smith: 'Multipresse',
    pullup_bar: 'Klimmzugstange', dip_bars: 'Dip-Barren', band: 'Band', kettlebell: 'Kettlebell',
    bodyweight: 'Körpergewicht', rack: 'Rack', bench: 'Bank', leg_press: 'Beinpresse', treadmill: 'Laufband',
    ergometer: 'Ergometer', open_floor: 'Freie Fläche'
  };
  // Bewegungsmuster → grobe Muskelgruppe (für Filter „Brust/Rücken/Beine/…").
  const MOVEMENT_GROUP = {
    horizontal_push: 'chest', vertical_push: 'shoulders', shoulder_abduction: 'shoulders', shoulder_extension: 'shoulders',
    horizontal_pull: 'back', vertical_pull: 'back', squat: 'legs', hinge: 'legs', lunge: 'legs', knee_flexion: 'legs',
    knee_extension: 'legs', hip_extension: 'legs', hip_adduction: 'legs', hip_abduction: 'legs', calf: 'legs',
    elbow_flexion: 'arms', elbow_extension: 'arms',
    trunk_flexion: 'core', trunk_extension: 'core', rotation: 'core', anti_rotation: 'core', carry: 'core'
  };
  const MUSCLE_GROUPS_DE = [
    { key: 'chest', label: 'Brust' }, { key: 'back', label: 'Rücken' }, { key: 'legs', label: 'Beine' },
    { key: 'shoulders', label: 'Schultern' }, { key: 'arms', label: 'Arme' }, { key: 'core', label: 'Core' }
  ];
  function labelMovement(k) { return MOVEMENT_LABELS[k] || (k ? String(k).replace(/_/g, ' ') : ''); }
  function labelMuscle(k) { return MUSCLE_LABELS[k] || (k ? String(k).replace(/_/g, ' ') : ''); }
  function labelEquipment(k) { return EQUIPMENT_LABELS[k] || (k ? String(k).replace(/_/g, ' ') : ''); }
  function groupOfMovement(k) { return MOVEMENT_GROUP[k] || null; }

  function inList(list, v) { return list.indexOf(v) >= 0; }
  const valid = {
    sport: v => inList(D.SPORTS, v),
    splitType: v => inList(D.SPLIT_TYPES, v),
    setType: v => inList(D.SET_TYPES, v),
    movementPattern: v => inList(D.MOVEMENT_PATTERNS, v),
    goalType: v => inList(D.GOAL_TYPES, v),
    sessionStatus: v => inList(D.SESSION_STATUS, v),
    position: (sport, p) => !!(D.POSITIONS[sport] && D.POSITIONS[sport].indexOf(p) >= 0)
  };

  // --- DTO-Mapper (DB-Zeile ⇆ App-Objekt), tolerant gegenüber fehlenden Feldern ---
  const map = {
    exerciseFromRow(r) {
      r = r || {};
      return {
        id: r.id, slug: r.slug || null, name: r.name, aliases: r.aliases || [], description: r.description || null,
        category: r.category || null, movementPattern: r.movement_pattern || null, difficulty: r.difficulty || null,
        stability: r.stability || null, complexity: r.complexity || null, fatigueCost: r.fatigue_cost != null ? r.fatigue_cost : null,
        jointStress: r.joint_stress || {}, unilateral: !!r.unilateral, bodyweight: !!r.bodyweight,
        isSystem: r.is_system !== false, userId: r.user_id || null, active: r.active !== false
      };
    },
    exerciseToRow(e) {
      e = e || {};
      return {
        name: e.name, aliases: e.aliases || [], description: e.description || null, category: e.category || null,
        movement_pattern: e.movementPattern || null, difficulty: e.difficulty || null, stability: e.stability || null,
        complexity: e.complexity || null, fatigue_cost: e.fatigueCost != null ? e.fatigueCost : null,
        joint_stress: e.jointStress || {}, unilateral: !!e.unilateral, bodyweight: !!e.bodyweight,
        is_system: false   // nutzerdefinierte Übungen sind NIE system
      };
    },
    setToRow(s) {
      s = s || {};
      return {
        set_number: s.setNumber, set_type: s.setType || 'working',
        weight: s.weight != null ? s.weight : null, reps: s.reps != null ? s.reps : null,
        rir: s.rir != null ? s.rir : null, rpe: s.rpe != null ? s.rpe : null,
        duration_s: s.durationS != null ? s.durationS : null, distance_m: s.distanceM != null ? s.distanceM : null,
        time_s: s.timeS != null ? s.timeS : null, tempo: s.tempo || null, rest_s: s.restS != null ? s.restS : null,
        completed: !!s.completed, pain: s.pain != null ? s.pain : null, technique: s.technique != null ? s.technique : null,
        recorded_at: s.recordedAt || new Date().toISOString()
      };
    }
  };

  O.trainingDomain = Object.assign({}, D, {
    valid: valid, map: map, inList: inList, normSport: normSport, normSportStrict: normSportStrict, ACTIVITY_SPORTS: ACTIVITY_SPORTS,
    MOVEMENT_LABELS: MOVEMENT_LABELS, MUSCLE_LABELS: MUSCLE_LABELS, EQUIPMENT_LABELS: EQUIPMENT_LABELS,
    MUSCLE_GROUPS_DE: MUSCLE_GROUPS_DE, labelMovement: labelMovement, labelMuscle: labelMuscle,
    labelEquipment: labelEquipment, groupOfMovement: groupOfMovement
  });
})();
