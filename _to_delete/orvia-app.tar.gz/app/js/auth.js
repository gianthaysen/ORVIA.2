/* ============================================================
   ORVIA · Supabase Auth + Closed Beta Gate
   - Login: Supabase Auth E-Mail + Passwort.
   - Registrierung: nur via Edge Function register-with-invite.
   - App-Zugriff: gültige Session + aktives Profil.
   ============================================================ */
(function () {
  const CFG = window.ORVIA_CFG || {};
  window.ORVIA = window.ORVIA || {};
  const O = window.ORVIA;
  /* B-13: nutzersichtbare Texte ueber t() (locales/de.js); ohne i18n-Modul bleibt der Key sichtbar. */
  function T(k, p) { try { if (O.i18n && typeof O.i18n.t === 'function') return O.i18n.t(k, p); } catch (e) {} return String(k); }

  // VOR jedem möglichen failClosedAuth()-Aufruf deklarieren (sonst Temporal Dead Zone in buildGate).
  let mode = 'login';
  let gateEl = null;
  let activeUserId = null;
  let recoveryReady = false;
  let recoveryTimer = null;

  const SAFE_MESSAGES = {
    invite_only: '' + T('auth.registrierung_ist_nur_mit_gueltigem') + '',
    invalid_invite: '' + T('auth.beta_code_ungueltig') + '',
    invite_used: '' + T('auth.beta_code_wurde_zu_oft') + '',
    invite_expired: '' + T('auth.beta_code_abgelaufen') + '',
    // #16.7: bewusst neutraler Server-Wortlaut (keine Account-Enumeration verschärfen),
    // aber NICHT mehr als „Beta-Code ungültig" maskiert (Diagnose-Verschleierung, Issue #14).
    email_taken: '' + T('auth.diese_e_mail_kann_nicht') + '',
    email_failed: '' + T('auth.e_mail_konnte_nicht_bestaetigt') + '',
    password_mismatch: '' + T('auth.die_passwoerter_stimmen_nicht_ueberein') + '',
    weak_password: '' + T('auth.das_passwort_muss_mindestens_8') + ''
  };

  // Reine Auth-Entscheidungen aus auth-logic.js (Single Source of Truth). KEIN stiller Fallback.
  const AL = window.ORVIA && window.ORVIA.authLogic;

  function pwRulesHTML(c) {
    function row(ok, t) { return '<span class="pwrule ' + (ok ? 'ok' : '') + '">' + (ok ? '✓' : '○') + ' ' + t + '</span>'; }
    return row(c.len, '' + T('auth.min_8_zeichen') + '') + row(c.upper, 'Großbuchstabe') + row(c.lower, 'Kleinbuchstabe') + row(c.digit, 'Zahl');
  }
  // Zweckgebundene Redirect-URL: action bleibt als ?auth_action erhalten, damit der Client den
  // PKCE-Callback nach dem Code-Austausch korrekt routen kann (recovery/signup/email_change).
  // auth_action ist kein Geheimnis — nur Client-Routensteuerung.
  function authRedirectUrl(action) {
    var url = new URL(location.origin + location.pathname);
    if (action) url.searchParams.set('auth_action', action);
    return url.toString();
  }
  // NUR bekannte Auth-Parameter aus Query+Hash entfernen (fachliche App-Parameter bleiben). Quelle: auth-logic.
  function cleanAuthUrl() { try { history.replaceState({}, document.title, AL.stripAuthParams(location.href)); } catch (e) {} }

  // Fail-closed: App gesperrt, Login/Registrierung deaktiviert, kein Session/Sync/Onboarding.
  function failClosedAuth(msg) {
    document.documentElement.classList.add('orvia-gated');
    try {
      buildGate();
      showGate('login');
      err(msg);
      var _s = document.getElementById('ogSubmit'); if (_s) { _s.disabled = true; _s.style.opacity = '.6'; }
    } catch (e) { try { console.error('[ORVIA auth] Fail-closed-Gate-Aufbau fehlgeschlagen.', e); } catch (_) {} }
    if (window.orviaSetSyncState) window.orviaSetSyncState('local');
    if (window.renderAccountCard) window.renderAccountCard();
  }

  // Fehlende/unvollständige Auth-Logik → fail-closed (NICHT still als 'normal' degradieren).
  if (!AL || typeof AL.detectAuthFlow !== 'function' || typeof AL.acceptRegistration !== 'function'
    || typeof AL.pwValid !== 'function' || typeof AL.stripAuthParams !== 'function') {
    failClosedAuth('' + T('auth.anmeldung_wird_gerade_vorbereitet_bitte') + '');
    return;
  }

  if (!CFG.configured) {
    failClosedAuth('' + T('auth.zugang_wird_gerade_vorbereitet_bitte') + '');
    return;
  }

  let sb;
  try {
    // PRODUKTIVE Flow-Strategie: PKCE konsequent (E-Mail-Aktionen liefern ?code + ?auth_action).
    // Implicit (type= im Hash) wird nur als Kompatibilitäts-Fallback noch behandelt.
    sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'pkce' }
    });
  } catch (e) {
    console.error('[ORVIA auth] Supabase-Init fehlgeschlagen.', e);
    failClosedAuth('' + T('auth.anmeldung_aktuell_nicht_verfuegbar_bitte') + '');
    return;
  }

  O.sb = sb;

  buildGate();

  // Auth-Flow aus der vollständigen URL VOR der normalen Freigabe bestimmen. Bei Recovery/Fehler/
  // Callback NIEMALS parallel die App über den Normalpfad öffnen.
  // FLOW-ART: Supabase-JS Standard ist Implicit (Token im Hash, type=recovery/signup). PKCE-Links
  // (?code) werden zusätzlich via exchangeCodeForSession unterstützt — beide Pfade abgedeckt.
  var authFlow = AL.detectAuthFlow(location.href);

  if (authFlow === 'pkce_recovery') {
    handlePkce('recovery');
  } else if (authFlow === 'pkce_signup' || authFlow === 'pkce_email_change') {
    handlePkce('signup');
  } else if (authFlow === 'pkce_unknown') {
    // ?code ohne gültige auth_action → NIEMALS automatisch die App öffnen.
    cleanAuthUrl();
    authFlow = 'normal';
    showGate('login');
    err('' + T('auth.der_link_ist_ungueltig_oder') + '');
  } else if (authFlow === 'implicit_recovery') {
    // Kompatibilitäts-Fallback. Recovery-Screen im Status „checking"; Freigabe erst bei PASSWORD_RECOVERY.
    showRecovery();
  } else if (authFlow === 'implicit_signup') {
    handleSignupConfirmation();
  } else if (authFlow === 'error') {
    cleanAuthUrl();
    showGate('login');
    err('' + T('auth.der_link_ist_ungueltig_oder') + '');
  } else {
    sb.auth.getSession()
      .then(({ data }) => {
        if (data && data.session) return onAuthed(data.session);
        showGate('login');
      })
      .catch(() => showGate('login'));
  }

  // PKCE-Callback: Code gegen Session tauschen, dann ZWECKABHÄNGIG routen. Ein Recovery-Code
  // öffnet NIE direkt die App, sondern führt zum „Neues Passwort"-Screen.
  async function handlePkce(action) {
    // Recovery vor dem Austausch sperren, damit ein paralleles SIGNED_IN die App nicht öffnet.
    if (action === 'recovery') authFlow = 'recovery';
    var code = null; try { code = new URL(location.href).searchParams.get('code'); } catch (e) {}
    if (!code) { cleanAuthUrl(); authFlow = 'normal'; showGate('login'); return; }
    var res;
    try { res = await sb.auth.exchangeCodeForSession(code); }
    catch (e) { res = { error: e }; }
    if (!res || res.error || !(res.data && res.data.session)) {
      cleanAuthUrl();
      authFlow = 'normal';
      showGate('login');
      err('' + T('auth.der_link_ist_ungueltig_oder') + '');
      return;
    }
    if (action === 'recovery') {
      cleanAuthUrl();
      authFlow = 'recovery';
      recoveryReady = true;
      showRecovery();
      enableRecoveryForm();
      return;
    }
    // signup / email_change → App öffnen
    cleanAuthUrl();
    authFlow = 'normal';
    await onAuthed(res.data.session);
  }

  // Signup-Bestätigungs-Callback: Session prüfen, Auth-Parameter bereinigen, bei gültigem Profil
  // App öffnen, sonst kontrolliert zum Login mit neutraler Erfolgsmeldung.
  async function handleSignupConfirmation() {
    var session = null;
    try { var r = await sb.auth.getSession(); session = r && r.data && r.data.session; } catch (e) {}
    cleanAuthUrl();
    authFlow = 'normal';
    if (session) { onAuthed(session); return; }
    showGate('login');
    err('' + T('auth.e_mail_bestaetigt_bitte_melde') + '');
  }

  sb.auth.onAuthStateChange((evt, session) => {
    // Recovery-Deep-Link (Passwort-Reset): Supabase feuert PASSWORD_RECOVERY mit temporärer Session.
    // NICHT die App entsperren — Screen zeigen und das Formular erst JETZT freischalten.
    if (evt === 'PASSWORD_RECOVERY') { recoveryReady = true; showRecovery(); enableRecoveryForm(); return; }
    if (evt === 'SIGNED_OUT') {
      // SIGNED_OUT kann auch OHNE safeSignOut() kommen (abgelaufene Session, Logout in
      // anderem Tab, serverseitige Abmeldung, Token-Entzug). Deshalb IMMER defensiv den
      // lokalen nutzerspezifischen Zustand bereinigen — VOR dem Nullen von O.user, falls
      // der Cleanup noch Infos zum vorherigen Nutzer benötigt. orviaClearLocal() ist idempotent
      // und löscht NICHT die (user-gescopte) Offline-Queue.
      try { if (window.orviaClearLocal) window.orviaClearLocal(); }
      catch (e) { console.error('[ORVIA auth] Lokaler Logout-Cleanup fehlgeschlagen.', e); }
      activeUserId = null;
      onAuthed._initFor = null;   // INCIDENT-FIX: Latch freigeben für nächsten Login
      O.user = null;
      /* ROLLEN-FIX: O.profile ist der Profil-API-Adapter (profile.js) und gehört NICHT auth.
         Die Access-Zeile lebt in O.accessProfile — nur diese wird hier genullt. */
      O.accessProfile = null;
      if (window.orviaSetSyncState) window.orviaSetSyncState('local');
      showGate('login');
      return;
    }
    if (session && (evt === 'SIGNED_IN' || evt === 'TOKEN_REFRESHED' || evt === 'USER_UPDATED')) {
      onAuthed(session);
    }
  });

  async function onAuthed(session) {
    if (authFlow === 'recovery' || authFlow === 'error') return;   // App während Recovery/Fehler-Link nicht öffnen
    if (!session || !session.user) {
      showGate('login');
      return;
    }

    if (activeUserId === session.user.id && gateEl && gateEl.style.display === 'none') return;

    const profileResult = await loadAccessProfile(session.user.id);
    if (!profileResult.ok) {
      await safeSignOut();
      activeUserId = null;
      O.user = null;
      O.accessProfile = null;
      showGate('login');
      err(profileResult.message);
      return;
    }

    // INCIDENT-FIX (2026-07-11): getSession-Pfad + SIGNED_IN-Event konnten onAuthed
    // beim Kaltstart DOPPELT durchlaufen lassen (Gate noch sichtbar ⇒ Guard oben griff
    // nicht) → doppelte Sync-Starts/Hydrationen/Merge-Dialoge. Latch je Nutzer.
    if (onAuthed._initFor === session.user.id) return;
    onAuthed._initFor = session.user.id;

    activeUserId = session.user.id;
    O.user = session.user;
    /* ROLLEN-FIX (Root Cause der „Tester"-Anzeige): Vorher überschrieb diese Zuweisung den
       Profil-API-Adapter aus profile.js (ORVIA.profile = {get, save, activeSports, …}) mit der
       Access-Zeile — und umgekehrt las renderAccountCard je nach Timing ein Objekt OHNE role-Feld,
       dessen binäres Fallback-Mapping still „Tester" ergab. Die Access-Zeile hat jetzt einen
       eigenen, kollisionsfreien Namen. */
    O.accessProfile = profileResult.profile;

    try { if (window.orviaApplyUserScope) window.orviaApplyUserScope(O.user.id); } catch (e) {}

    hideGate();
    document.documentElement.classList.remove('orvia-gated');
    if (window.renderAccountCard) window.renderAccountCard();
    // PERF-INSTRUMENTIERUNG (Audit 2026-07-15, s. config.js ORVIA.perf): reine Zeitmessung,
    // keine Verhaltensänderung. _P fällt lautlos auf No-Ops zurück, falls perf-Helper fehlt.
    var _P = O.perf || { now: function () { return Date.now(); }, mark: function () {} };
    var _loginT0 = _P.now();
    if (window.orviaSyncStart) {
      var _tSync = _P.now();
      try { await window.orviaSyncStart(); } catch (e) {}
      _P.mark('onAuthed: orviaSyncStart', _tSync);
    }

    // Datenfundament: zuerst offene Offline-Schreibvorgänge des AKTUELLEN Nutzers flushen,
    // dann idempotente Blob→Tabellen-Migration, danach Profil aus user_profiles hydrieren
    // (Tabelle gewinnt über Blob für die Profil-Mapped-Felder).
    // E7 (2B-①): Flush wird AWAITED, damit die anschließende Hydration eigene frische
    // Schreibvorgänge sieht — aber mit Timeout-Fallback: der Login darf nie hängen.
    try {
      if (O.offlineQueue && O.offlineQueue.flush) {
        var _tFlush = _P.now();
        await Promise.race([
          Promise.resolve(O.offlineQueue.flush()).catch(function (e) {
            console.warn('[ORVIA auth] Offline-Flush fehlgeschlagen — Login läuft weiter.', e && e.message);
          }),
          new Promise(function (resolve) { setTimeout(function () { resolve({ flush_timeout: true }); }, 4000); })
        ]);
        _P.mark('onAuthed: offlineQueue.flush (races a 4s timeout)', _tFlush);
      }
    } catch (e) { console.warn('[ORVIA auth] Offline-Flush übersprungen.', e && e.message); }
    try {
      var _t;
      if (O.blobMigration) { _t = _P.now(); await O.blobMigration.run(); _P.mark('onAuthed: blobMigration.run', _t); }
      if (O.profileStore) { _t = _P.now(); await O.profileStore.hydrate(); _P.mark('onAuthed: profileStore.hydrate', _t); }
      // 2B-①: sports-Sektion aus user_sports hydrieren (K1-LWW; Erstmigration bei leerer Cloud).
      if (O.profileStore && O.profileStore.hydrateSports) { _t = _P.now(); await O.profileStore.hydrateSports(); _P.mark('onAuthed: profileStore.hydrateSports', _t); }
      // P9: weitere Sektions-Zyklen (gleiche K1/K2/K3-Regeln; jeder fail-soft).
      if (O.profileStore && O.profileStore.hydrateAvailability) { _t = _P.now(); await O.profileStore.hydrateAvailability(); _P.mark('onAuthed: profileStore.hydrateAvailability', _t); }
      if (O.profileStore && O.profileStore.hydrateGoals) { _t = _P.now(); await O.profileStore.hydrateGoals(); _P.mark('onAuthed: profileStore.hydrateGoals', _t); }
      if (O.profileStore && O.profileStore.hydrateConstraints) { _t = _P.now(); await O.profileStore.hydrateConstraints(); _P.mark('onAuthed: profileStore.hydrateConstraints', _t); }
      /* 0016 · Avatar-Hydration stand hier und ist am 17.08.2026 aus der Kette
         genommen worden — sie laeuft jetzt NACH dem Rendern (siehe unten, direkt
         hinter dem Auth-Ready-Signal). Gemessen war sie mit 1296 ms von 4781 ms der
         zweitgroesste Posten des Logins. Fuer ein Profilbild. */
      if (O.checkinStore) { _t = _P.now(); await O.checkinStore.hydrateRecentTypes(35, ['morning', 'live', 'pre', 'post', 'evening']); _P.mark('onAuthed: checkinStore.hydrateRecentTypes', _t); }
      if (O.readinessStore) { _t = _P.now(); await O.readinessStore.hydrateRecentScores(60); _P.mark('onAuthed: readinessStore.hydrateRecentScores', _t); }
      if (O.workoutUI && O.workoutUI.tryRestore) { _t = _P.now(); await O.workoutUI.tryRestore(); _P.mark('onAuthed: workoutUI.tryRestore', _t); }
    } catch (e) {}
    _P.mark('onAuthed: TOTAL login-init chain', _loginT0);

    // GM6.1 (2026-07-27): Hydration abgeschlossen. Die letzten Schritte
    // (checkin/readiness/workout) melden sich nicht selbst — readinessStore
    // rendert gar nichts. Genau ein bereits erwartetes Signal am tatsächlichen
    // Ende der Kette; Konsumenten sind ORVIA.uiRefresh (sichtbarer Tab) und der
    // vorhandene Listener in activity-sync.js. Einmaligkeit garantiert der Latch
    // onAuthed._initFor oben — kein neues Feld, kein paralleler Ready-State.
    try { if (typeof CustomEvent === 'function' && window.dispatchEvent) window.dispatchEvent(new CustomEvent('orvia:auth-ready')); } catch (e) {}

    /* ═══ Avatar NACH dem kritischen Pfad ════════════════════════════════════
       BEFUND (Messung 17.08.2026): avatarStore.hydrate lag mit 1296 ms auf Platz 2
       der Login-Kette (4781 ms gesamt) — zwoelf sequenzielle await, deren Summe
       per Konstruktion die Wartezeit IST. Ein Profilbild gehoert dort nicht hin.

       WARUM DAS GEFAHRLOS IST: hydrate() rendert selbst nach, sobald die signierte
       URL vorliegt (avatar-store.js: renderTopAvatar / renderProfileScreen /
       renderGMProfile). Jeder Konsument liest ueber avatarStore.currentSrc() mit
       Rueckfall auf PROFILE.avatar — bis das Bild da ist, steht das lokale Bild
       oder die Initialen. Kein spaeterer Schritt der Kette liest den Avatar.

       setTimeout(0) statt await: erst rendern, dann nachladen. Die Messmarke bleibt
       bestehen — der Posten verschwindet aus der KETTE, nicht aus der MESSUNG. */
    try {
      if (O.avatarStore) setTimeout(function () {
        var _tAv = _P.now();
        Promise.resolve(O.avatarStore.hydrate())
          .then(function () { _P.mark('avatarStore.hydrate (nachgelagert, ausserhalb der Login-Kette)', _tAv); })
          .catch(function (e) { console.warn('[ORVIA auth] Avatar-Hydration fehlgeschlagen — Anzeige bleibt beim lokalen Bild.', e && e.message); });
      }, 0);
    } catch (e) {}

    try {
      // Onboarding nur bei pending öffnen. Dispatcher (onboarding-ui) öffnet AUSSCHLIESSLICH v2 (kein Legacy).
      // Pending-Key ERST nach erfolgreichem Öffnen entfernen (bei Fehler/fehlendem v2 behalten).
      if (localStorage.getItem('orvia_onboard_pending')) {
        setTimeout(function () {
          try { if (window.openPendingOnboarding && window.openPendingOnboarding()) localStorage.removeItem('orvia_onboard_pending'); } catch (e) {}
        }, 400);
      }
    } catch (e) {}
  }

  /* ROLLEN-FIX (2026-07-15): Verbindliche Rollenquelle ist AUSSCHLIESSLICH public.profiles.role.
     - Identität wird serverseitig via sb.auth.getUser() verifiziert (kein lokaler Zustand als Quelle).
     - Query strikt eigene Zeile: .eq('user_id', <verifizierte ID>) + maybeSingle (0 Zeilen = kontrollierter Fehler).
     - Bekannte Rollen: owner|admin|coach|tester|athlete (Anzeige-Mapping in renderAccountCard).
     - Cache ist STRIKT nutzergebunden (orvia:{userId}:profile); der Serverwert überschreibt ihn
       bei jedem erfolgreichen Login. Alte globale Schlüssel werden entfernt und nie gelesen.
     - Bei Ladefehler: strukturierter Log + ok:false — NIE ein stiller Rollen-Default. */
  const KNOWN_ROLES = ['owner', 'admin', 'coach', 'tester', 'athlete'];
  function accessCacheKey(userId) { return 'orvia:' + userId + ':profile'; }
  const LEGACY_PROFILE_CACHE_KEYS = ['role', 'userRole', 'profile', 'userProfile', 'currentUser', 'athleteProfile', 'orvia_role'];
  function roleLog(code, detail) {
    try { console.error('[ORVIA auth] role_load_failed', JSON.stringify({ code: code, detail: detail || null, at: new Date().toISOString() })); } catch (e) {}
  }

  async function loadAccessProfile(sessionUserId) {
    try {
      // 1) Verbindliche Nutzer-ID: serverseitig bestätigter Auth-Nutzer.
      let verifiedId = null;
      try { const u = await sb.auth.getUser(); verifiedId = (u && u.data && u.data.user && u.data.user.id) || null; } catch (e) {}
      /* LIVE-FIX (2026-07-17): getUser() kann TRANSIENT scheitern (beobachtet bei paralleler
         Token-Rotation mehrerer Geräte) — das sperrte einen gültig eingeloggten Owner aus
         (AUTH_GETUSER_FAILED → Gate). Die Session stammt vom SDK selbst und ist als Identität
         zulässig: Fallback auf session.user.id mit Log. Ein MISMATCH bleibt harter Fehler. */
      if (!verifiedId && sessionUserId) { roleLog('AUTH_GETUSER_TRANSIENT_FALLBACK'); verifiedId = sessionUserId; }
      if (!verifiedId) { roleLog('AUTH_GETUSER_FAILED'); return { ok: false, message: SAFE_MESSAGES.invite_only }; }
      if (sessionUserId && verifiedId !== sessionUserId) { roleLog('USER_ID_MISMATCH'); return { ok: false, message: SAFE_MESSAGES.invite_only }; }

      // 2) Genau die eigene Profilzeile.
      const { data, error } = await sb
        .from('profiles')
        .select('user_id,email,role,is_active,name')
        .eq('user_id', verifiedId)
        .maybeSingle();

      if (error) {
        roleLog('PROFILE_QUERY_FAILED', error.message);
        return { ok: false, message: SAFE_MESSAGES.invite_only };
      }
      if (!data) {
        roleLog('PROFILE_ROW_MISSING');
        return { ok: false, message: '' + T('auth.es_wurde_kein_gueltiges_profil') + '' };
      }
      if (data.is_active !== true) {
        return { ok: false, message: '' + T('auth.dein_zugang_ist_nicht_aktiv') + '' };
      }
      if (KNOWN_ROLES.indexOf(data.role) < 0) {
        roleLog('UNKNOWN_ROLE', String(data.role));
        return { ok: false, message: '' + T('auth.dein_zugang_ist_nicht_aktiv') + '' };
      }
      // 3) Serverwert überschreibt IMMER einen alten Cache; alte globale Schlüssel entfernen.
      try {
        localStorage.setItem(accessCacheKey(verifiedId), JSON.stringify(data));
        LEGACY_PROFILE_CACHE_KEYS.forEach(function (k) { localStorage.removeItem(k); });
      } catch (e) {}
      return { ok: true, profile: data };
    } catch (e) {
      roleLog('PROFILE_EXCEPTION', String(e && e.message || e));
      return { ok: false, message: SAFE_MESSAGES.invite_only };
    }
  }

  function buildGate() {
    gateEl = document.createElement('div');
    gateEl.className = 'orvia-gate';
    gateEl.style.display = 'none';
    gateEl.innerHTML =
      '<div class="og-card">' +
        '<svg class="og-mark" viewBox="0 0 512 512" aria-hidden="true"><use href="#orvia-mark"/></svg>' +
        '<div class="og-wm">ORVIA</div>' +
        '<div class="og-claim">' + T('auth.know_your_state_move_with') + '</div>' +
        '<div class="og-tabs">' +
          '<button type="button" data-m="login">' + T('auth.anmelden') + '</button>' +
          '<button type="button" data-m="register">' + T('auth.registrieren') + '</button>' +
        '</div>' +
        '<form class="og-form" autocomplete="on">' +
          '<div class="og-field og-invite"><label>' + T('auth.beta_code') + '</label>' +
            '<input type="text" id="ogCode" autocapitalize="characters" autocomplete="one-time-code" placeholder="' + T('auth.orvia_beta') + '"></div>' +
          '<div class="og-field"><label>' + T('auth.e_mail') + '</label>' +
            '<input type="email" id="ogEmail" autocomplete="email" placeholder="' + T('auth.du_mail_de') + '"></div>' +
          '<div class="og-field"><label>' + T('auth.passwort') + '</label>' +
            '<input type="password" id="ogPw" autocomplete="current-password" placeholder="' + T('auth.mind_8_zeichen') + '"></div>' +
          '<div class="og-pwrules og-pw-confirm" id="ogPwRules"></div>' +
          '<div class="og-field og-pw-confirm"><label>' + T('auth.passwort_bestaetigen') + '</label>' +
            '<input type="password" id="ogPw2" autocomplete="new-password" placeholder="' + T('auth.noch_einmal_eingeben') + '"></div>' +
          '<label class="og-show"><input type="checkbox" id="ogShow">' + T('auth.passwort_anzeigen') + '</label>' +
          '<div class="og-err" id="ogErr"></div>' +
          '<button type="submit" class="btn" id="ogSubmit">' + T('auth.anmelden') + '</button>' +
        '</form>' +
        '<button type="button" class="og-link" id="ogForgot">' + T('auth.passwort_vergessen') + '</button>' +
        '<div class="og-note">' + T('auth.geschlossene_beta_registrierung_nur_mit') + '</div>' +
      '</div>';
    document.body.appendChild(gateEl);

    gateEl.querySelectorAll('.og-tabs button').forEach(b =>
      b.onclick = () => setMode(b.dataset.m));
    gateEl.querySelector('.og-form').addEventListener('submit', onSubmit);
    gateEl.querySelector('#ogForgot').onclick = onForgot;
    // Live-Passwortregeln (nur im Registrieren-Modus sichtbar, s. setMode).
    var pwEl = gateEl.querySelector('#ogPw'), rules = gateEl.querySelector('#ogPwRules');
    pwEl.addEventListener('input', function () { if (mode === 'register') rules.innerHTML = pwRulesHTML(AL.pwChecks(pwEl.value)); });
    // Show/Hide für beide Passwortfelder.
    gateEl.querySelector('#ogShow').addEventListener('change', function () {
      var t = this.checked ? 'text' : 'password';
      gateEl.querySelector('#ogPw').type = t; gateEl.querySelector('#ogPw2').type = t;
    });
  }

  function setMode(m) {
    mode = m;
    var reg = (m === 'register');
    gateEl.querySelectorAll('.og-tabs button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
    gateEl.querySelector('.og-invite').style.display = reg ? '' : 'none';
    gateEl.querySelectorAll('.og-pw-confirm').forEach(el => { el.style.display = reg ? '' : 'none'; });
    gateEl.querySelector('.og-show').style.display = reg ? '' : 'none';
    gateEl.querySelector('#ogSubmit').textContent = reg ? '' + T('auth.account_erstellen') + '' : '' + T('auth.anmelden') + '';
    gateEl.querySelector('#ogPw').setAttribute('autocomplete', reg ? 'new-password' : 'current-password');
    gateEl.querySelector('#ogForgot').style.display = reg ? 'none' : 'block';
    if (reg) gateEl.querySelector('#ogPwRules').innerHTML = pwRulesHTML(AL.pwChecks(gateEl.querySelector('#ogPw').value));
    err('');
  }

  function showGate(m) {
    if (!gateEl) return;
    gateEl.style.display = 'flex';
    document.documentElement.classList.add('orvia-gated');
    setMode(m || 'login');
  }

  function hideGate() {
    if (gateEl) gateEl.style.display = 'none';
  }

  function err(msg) {
    const e = gateEl && gateEl.querySelector('#ogErr');
    if (e) {
      e.textContent = msg || '';
      e.style.display = msg ? 'block' : 'none';
    }
  }

  function busy(on) {
    const b = gateEl.querySelector('#ogSubmit');
    b.disabled = on;
    b.style.opacity = on ? '.6' : '1';
  }

  async function onSubmit(ev) {
    ev.preventDefault();
    err('');
    if (!sb) { err('' + T('auth.anmeldung_aktuell_nicht_verfuegbar') + ''); return; }
    const email = val('ogEmail').trim().toLowerCase();
    const pw = val('ogPw');

    if (!email || !pw) {
      err('' + T('auth.bitte_e_mail_und_passwort') + '');
      return;
    }

    busy(true);
    try {
      if (mode === 'register') {
        const code = val('ogCode').trim();
        const pw2 = val('ogPw2');
        if (!code) {
          err(SAFE_MESSAGES.invalid_invite);
          busy(false);
          return;
        }
        if (!AL.pwValid(pw)) {
          err('' + T('auth.passwort_min_8_zeichen_gross') + '');
          busy(false);
          return;
        }
        if (pw !== pw2) {
          err(SAFE_MESSAGES.password_mismatch);
          busy(false);
          return;
        }

        const reg = await registerWithInvite(email, code, pw);
        if (!reg.ok) {
          err(reg.message);
          busy(false);
          return;
        }

        // FAIL-CLOSED: nur ein ausdrücklich versionierter Bestätigungs-Vertrag gilt als gültige
        // Registrierung. KEIN stiller Fallback auf einen vorbestätigten Account.
        if (!AL.acceptRegistration(reg.data)) {
          err('' + T('auth.registrierung_wurde_serverseitig_nicht_korrekt') + '');
          busy(false);
          return;
        }
        localStorage.setItem('orvia_onboard_pending', '1');
        showConfirmPending(email, reg.data);
        busy(false);
        return;
      } else {
        const { data, error } = await sb.auth.signInWithPassword({ email, password: pw });
        if (error || !data || !data.session) {
          // #16 (2026-07-02): unbestätigte E-Mail NICHT als „Passwort falsch" maskieren —
          // stattdessen Bestätigungs-Screen mit Resend-Pfad zeigen (GoTrue: "Email not confirmed").
          const em = String((error && error.message) || '').toLowerCase();
          if (em.includes('not confirmed') || em.includes('' + T('auth.nicht_bestaetigt') + '')) {
            showConfirmPending(email);
            busy(false);
            return;
          }
          err('' + T('auth.e_mail_oder_passwort_ist') + '');
          busy(false);
          return;
        }
        await onAuthed(data.session);
      }
    } catch (e) {
      console.error(e);
      err('' + T('auth.unerwarteter_fehler_bitte_erneut_versuchen') + '');
    }
    busy(false);
  }

  async function registerWithInvite(email, betaCode, password) {
    try {
      const { data, error } = await sb.functions.invoke('register-with-invite', {
        // redirectTo: zweckgebundene Signup-Callback-URL (?auth_action=signup).
        // GoTrue validiert sie gegen die Redirect-Allowlist (kein Open Redirect).
        body: { email, betaCode, inviteCode: betaCode, password, redirectTo: authRedirectUrl('signup') }
      });
      if (error) return { ok: false, message: await functionErrorMessage(error) };
      // Rohdaten durchreichen; der versionierte Vertrag (flowVersion/status) wird im Aufrufer geprüft.
      return { ok: true, data: data || null };
    } catch (e) {
      console.error('[ORVIA auth] register-with-invite fehlgeschlagen.', e);
      return { ok: false, message: SAFE_MESSAGES.invite_only };
    }
  }

  async function functionErrorMessage(error) {
    // supabase-js: error.context ist die Response. Body robust auslesen (json ODER text).
    try {
      var ctx = error && error.context;
      if (ctx && typeof ctx.clone === 'function') {
        var body = await ctx.clone().json().catch(function () { return null; });
        if (!body && typeof ctx.text === 'function') {
          var t = await ctx.text().catch(function () { return ''; });
          if (t) { try { body = JSON.parse(t); } catch (e) { body = { message: t }; } }
        }
        if (body) return safeMessage(body.code || body.message, body.message);
      }
    } catch (e) {}
    return safeMessage(error && error.message);
  }

  function safeMessage(raw, serverMsg) {
    const m = String(raw || '').toLowerCase();
    if (raw && Object.values(SAFE_MESSAGES).includes(String(raw))) return String(raw);
    // #16.7: bekannte sichere Server-Message gewinnt über den Code (z. B. email_taken teilt
    // sich den Code invalid_invite mit der echten Code-Prüfung — Message differenziert).
    if (serverMsg && Object.values(SAFE_MESSAGES).includes(String(serverMsg))) return String(serverMsg);
    // #16.7: generischer Serverfehler (invite_only, 500) NICHT als „Beta-Code ungültig" tarnen.
    if (m.includes('invite_only')) return SAFE_MESSAGES.invite_only;
    if (m.includes('invite_used') || m.includes('zu oft') || m.includes('bereits verwendet')) return SAFE_MESSAGES.invite_used;
    if (m.includes('invite_expired') || m.includes('abgelaufen')) return SAFE_MESSAGES.invite_expired;
    if (m.includes('weak_password') || m.includes('password')) return SAFE_MESSAGES.weak_password;
    if (m.includes('invalid_invite') || m.includes('invite') || m.includes('beta-code') || m.includes('ungültig')) return SAFE_MESSAGES.invalid_invite;
    return SAFE_MESSAGES.invite_only;
  }

  async function onForgot() {
    const email = val('ogEmail').trim().toLowerCase();
    if (!email) {
      err('' + T('auth.e_mail_eingeben_dann_passwort') + '');
      return;
    }
    try {
      // Zweckgebundene Redirect-URL → muss bei Supabase unter Additional Redirect URLs eingetragen sein.
      await sb.auth.resetPasswordForEmail(email, { redirectTo: authRedirectUrl('recovery') });
      err('' + T('auth.falls_die_e_mail_existiert') + '');
    } catch (e) {
      err('' + T('auth.reset_aktuell_nicht_moeglich') + '');
    }
  }

  // Bestätigungs-Screen nach Registrierung (Hybrid): E-Mail anzeigen, erneut senden, Adresse korrigieren.
  // regData: Server-Antwort des Registrierungsvertrags. emailSent === false → ehrlicher Hinweis,
  // dass der Versand fehlschlug (Account existiert; "Erneut senden" ist der Recovery-Pfad).
  function showConfirmPending(email, regData) {
    if (gateEl) gateEl.style.display = 'none';
    document.documentElement.classList.add('orvia-gated');
    var ex = document.getElementById('orviaConfirm'); if (ex) ex.remove();
    var wrap = document.createElement('div');
    wrap.id = 'orviaConfirm'; wrap.className = 'orvia-gate'; wrap.style.display = 'flex';
    // E-Mail NICHT in innerHTML interpolieren (XSS) → neutrales Element + textContent.
    wrap.innerHTML =
      '<div class="og-card">' +
        '<div class="og-wm">ORVIA</div>' +
        '<div class="og-claim">' + T('auth.e_mail_bestaetigen') + '</div>' +
        '<p class="og-note" style="text-align:center">' + T('auth.wir_haben_einen_bestaetigungslink_an') + '<br><b id="cfEmail"></b>' + T('auth.gesendet_oeffne_den_link_dann') + '</p>' +
        '<div class="og-err" id="cfErr"></div>' +
        '<button type="button" class="btn" id="cfDone">' + T('auth.ich_habe_meine_e_mail') + '</button>' +
        '<button type="button" class="og-link" id="cfResend">' + T('auth.bestaetigung_erneut_senden') + '</button>' +
        '<button type="button" class="og-link" id="cfBack">' + T('auth.adresse_korrigieren_zurueck') + '</button>' +
      '</div>';
    document.body.appendChild(wrap);
    wrap.querySelector('#cfEmail').textContent = email || '';
    function se(m) { var e = wrap.querySelector('#cfErr'); e.style.display = 'block'; e.textContent = m; }
    if (regData && regData.emailSent === false) {
      se('' + T('auth.dein_konto_wurde_erstellt_aber') + '');
    }
    wrap.querySelector('#cfBack').onclick = function () { wrap.remove(); showGate('register'); };
    // „Ich habe bestätigt": NUR lokale Session prüfen (Remote-Status kann der Client nicht
    // nachweisen). Mit Session → App; sonst kontrolliert zum Login mit vorausgefüllter E-Mail.
    wrap.querySelector('#cfDone').onclick = async function () {
      this.disabled = true;
      try {
        var { data } = await sb.auth.getSession();
        if (data && data.session) { wrap.remove(); onAuthed(data.session); return; }
      } catch (_) {}
      wrap.remove();
      showGate('login');
      var emEl = document.getElementById('ogEmail'); if (emEl) emEl.value = email || '';
      err('' + T('auth.bitte_melde_dich_mit_deiner') + '');
    };
    wrap.querySelector('#cfResend').onclick = async function () {
      this.disabled = true;
      try {
        var r = await sb.auth.resend({ type: 'signup', email: email, options: { emailRedirectTo: authRedirectUrl('signup') } });
        se((r && r.error) ? '' + T('auth.erneut_senden_fehlgeschlagen') + '' : '' + T('auth.bestaetigung_erneut_gesendet') + '');
      } catch (_) { se('' + T('auth.erneut_senden_fehlgeschlagen') + ''); }
      this.disabled = false;
    };
  }

  function rcErrShow(m) { var e = document.getElementById('rcErr'); if (e) { e.textContent = m; e.style.display = 'block'; } }
  // Recovery-Formular erst freischalten, wenn eine gültige Recovery-Session vorliegt (PASSWORD_RECOVERY).
  function enableRecoveryForm() {
    recoveryReady = true;
    if (recoveryTimer) { clearTimeout(recoveryTimer); recoveryTimer = null; }
    var st = document.getElementById('rcStatus'); if (st) st.style.display = 'none';
    ['rcPw', 'rcPw2', 'rcSubmit'].forEach(function (id) { var el = document.getElementById(id); if (el) el.disabled = false; });
  }
  // Recovery-Screen. Startzustand „checking": Felder/Speichern deaktiviert, bis PASSWORD_RECOVERY kommt.
  function showRecovery() {
    document.documentElement.classList.add('orvia-gated');
    if (gateEl) gateEl.style.display = 'none';
    if (document.getElementById('orviaRecovery')) { if (recoveryReady) enableRecoveryForm(); return; } // idempotent
    var wrap = document.createElement('div');
    wrap.id = 'orviaRecovery'; wrap.className = 'orvia-gate'; wrap.style.display = 'flex';
    wrap.innerHTML =
      '<div class="og-card">' +
        '<div class="og-wm">ORVIA</div>' +
        '<div class="og-claim">' + T('auth.neues_passwort_setzen') + '</div>' +
        '<div class="og-note" id="rcStatus" style="text-align:center">' + T('auth.reset_link_wird_geprueft') + '</div>' +
        '<form class="og-form" autocomplete="off">' +
          '<div class="og-field"><label>' + T('auth.neues_passwort') + '</label>' +
            '<input type="password" id="rcPw" autocomplete="new-password" placeholder="' + T('auth.min_8_zeichen') + '" disabled></div>' +
          '<div class="og-pwrules" id="rcRules"></div>' +
          '<div class="og-field"><label>' + T('auth.passwort_bestaetigen') + '</label>' +
            '<input type="password" id="rcPw2" autocomplete="new-password" placeholder="' + T('auth.noch_einmal_eingeben') + '" disabled></div>' +
          '<label class="og-show"><input type="checkbox" id="rcShow">' + T('auth.passwort_anzeigen') + '</label>' +
          '<div class="og-err" id="rcErr"></div>' +
          '<button type="submit" class="btn" id="rcSubmit" disabled>' + T('auth.passwort_speichern') + '</button>' +
        '</form>' +
      '</div>';
    document.body.appendChild(wrap);
    var pwEl = document.getElementById('rcPw'), pw2El = document.getElementById('rcPw2');
    // Initial programmatisch sperren (zusätzlich zum HTML-disabled), bis Recovery-Session bestätigt.
    if (!recoveryReady) { ['rcPw', 'rcPw2', 'rcSubmit'].forEach(function (id) { var el = document.getElementById(id); if (el) el.disabled = true; }); }
    function upd() { var r = document.getElementById('rcRules'); if (r) r.innerHTML = pwRulesHTML(AL.pwChecks(pwEl.value)); }
    pwEl.addEventListener('input', upd); upd();
    document.getElementById('rcShow').addEventListener('change', function () { var t = this.checked ? 'text' : 'password'; pwEl.type = t; pw2El.type = t; });
    wrap.querySelector('.og-form').addEventListener('submit', async function (ev) {
      ev.preventDefault();
      // Race-Schutz: vor gültiger Recovery-Session NICHT updateUser aufrufen.
      if (!recoveryReady) { rcErrShow('' + T('auth.der_reset_link_ist_noch') + ''); return; }
      var pw = pwEl.value, pw2 = pw2El.value;
      if (!AL.pwValid(pw)) { rcErrShow('' + T('auth.passwort_min_8_zeichen_gross') + ''); return; }
      if (pw !== pw2) { rcErrShow('' + T('auth.die_passwoerter_stimmen_nicht_ueberein') + ''); return; }
      var btn = document.getElementById('rcSubmit'); btn.disabled = true;
      try {
        var r = await sb.auth.updateUser({ password: pw });
        if (r && r.error) { rcErrShow('' + T('auth.konnte_nicht_gespeichert_werden_der') + ''); btn.disabled = false; return; }
        await safeSignOut();
        cleanAuthUrl();
        authFlow = 'normal';
        wrap.remove();
        showGate('login');
        err('' + T('auth.passwort_geaendert_bitte_neu_anmelden') + '');
      } catch (_) { rcErrShow('' + T('auth.unerwarteter_fehler_bitte_erneut_versuchen') + ''); btn.disabled = false; }
    });
    if (recoveryReady) { enableRecoveryForm(); return; }
    // Kontrollierter Timeout: kommt keine Recovery-Session, neutralen Fehler zeigen (kein falsches „abgelaufen").
    recoveryTimer = setTimeout(function () {
      if (recoveryReady) return;
      var st = document.getElementById('rcStatus'); if (st) st.style.display = 'none';
      rcErrShow('' + T('auth.der_reset_link_konnte_nicht') + '');
    }, 12000);
  }

  async function safeSignOut() {
    try { await sb.auth.signOut(); } catch (e) {}
  }

  window.orviaLogout = async function () {
    await safeSignOut();
    try { if (window.orviaClearLocal) window.orviaClearLocal(); } catch (e) {}
    try { ['orvia_active_user', 'orvia_onboard_pending'].forEach(function (k) { localStorage.removeItem(k); }); } catch (e) {}
    O.user = null;
    O.accessProfile = null;
    location.reload();
  };

  /* H4 (2026-07-11): echte Konto-Flows für eingeloggte Nutzer. */
  window.orviaChangePassword = async function () {
    var p1 = prompt('' + T('auth.neues_passwort_min_8_zeichen') + '');
    if (p1 == null) return;
    if (!AL.pwValid(p1)) { alert('' + T('auth.passwort_erfuellt_die_regeln_nicht') + ''); return; }
    var p2 = prompt('' + T('auth.neues_passwort_wiederholen') + '');
    if (p2 !== p1) { alert(SAFE_MESSAGES.password_mismatch); return; }
    try {
      var r = await sb.auth.updateUser({ password: p1 });
      if (r && r.error) throw r.error;
      alert('' + T('auth.passwort_geaendert') + '');
    } catch (e) { alert('' + T('auth.passwort_aenderung_fehlgeschlagen') + '' + ((e && e.message) || 'unbekannt')); }
  };
  window.orviaChangeEmail = async function () {
    var mail = prompt('' + T('auth.neue_e_mail_adresse') + '');
    if (!mail) return;
    try {
      // Bestätigungslink nutzt den bereits vorhandenen pkce_email_change-Callback-Router.
      var r = await sb.auth.updateUser({ email: mail.trim() }, { emailRedirectTo: authRedirectUrl('email_change') });
      if (r && r.error) throw r.error;
      alert('' + T('auth.bestaetigungs_e_mail_versendet_bitte') + '');
    } catch (e) { alert('' + T('auth.e_mail_aenderung_fehlgeschlagen') + '' + ((e && e.message) || 'unbekannt')); }
  };
  /* H4: ECHTE serverseitige Löschung über die Edge Function delete-account
     (löscht den Auth-User; alle Tabellen hängen mit on delete cascade daran).
     Fail-closed: ohne Server-Erfolg wird lokal NICHTS gelöscht. */
  window.orviaDeleteAccount = async function () {
    var sure = prompt('' + T('auth.konto_dauerhaft_loeschen_alle_cloud') + '');
    if (sure !== 'LÖSCHEN') { if (sure != null) alert('' + T('auth.nicht_bestaetigt_es_wurde_nichts') + ''); return; }
    try {
      var sess = await sb.auth.getSession();
      var token = sess && sess.data && sess.data.session && sess.data.session.access_token;
      if (!token) { alert('' + T('auth.keine_aktive_sitzung') + ''); return; }
      var resp = await fetch(CFG.SUPABASE_URL + '/functions/v1/delete-account', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + token, 'apikey': CFG.SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
        body: JSON.stringify({ confirm: true })
      });
      var body = null; try { body = await resp.json(); } catch (e) {}
      if (!resp.ok || !(body && body.ok)) {
        alert(T('auth.serverseitige_loeschung_fehlgeschlagen_status', { status: resp.status }));
        return;
      }
      try { await sb.auth.signOut(); } catch (e) {}
      try { if (window.clearLocalUserData) window.clearLocalUserData(); } catch (e) {}
      try {
        localStorage.removeItem('orvia_profile_v1');
        localStorage.removeItem('gian_checkins_v2');
        localStorage.removeItem('orvia_consent');
        localStorage.removeItem('orvia_data_owner');
        localStorage.removeItem('orvia_sync_rev');
      } catch (e) {}
      alert('' + T('auth.konto_und_daten_wurden_geloescht') + '');
      location.reload();
    } catch (e) { alert(T('auth.loeschung_fehlgeschlagen_nichts_geloescht', { msg: (e && e.message) || 'unbekannt' })); }
  };

  function val(id) {
    const e = document.getElementById(id);
    return e ? e.value : '';
  }
})();

/* B-13: Texte der globalen Konto-Karte ueber t(); eigener Name, weil dieser Teil ausserhalb
   der IIFE liegt und profile.js bereits ein globales T fuehrt (kein Redeclare-Risiko). */
var _authT = function (k, p) { try { var I = window.ORVIA && window.ORVIA.i18n; if (I && typeof I.t === 'function') return I.t(k, p); } catch (e) {} return String(k); };

/* ============================================================
   Konto-/Sync-Karte im Profil  (global, von Profil-Render + Sync genutzt)
   ============================================================ */
/* ROLLEN-FIX (2026-07-15): Anzeige liest AUSSCHLIESSLICH ORVIA.accessProfile.role
   (= public.profiles.role, von auth.js nach Server-Verifikation gesetzt).
   Explizites Mapping; unbekannte Rolle → Rohwert (escaped); Ladefehler → Fehlerstatus,
   NIE ein stiller Default wie früher (`role==='owner' ? 'Owner' : 'Tester'`). */
window.ORVIA_ROLE_LABELS = { owner: 'Owner', admin: 'Administrator', coach: 'Coach', tester: 'Tester', athlete: 'Athlet' };
window.orviaRoleLabel = function (accessProfile) {
  if (!accessProfile || accessProfile.role == null || accessProfile.role === '') return null;   // Fehler-/Ladezustand — Aufrufer zeigt Status
  return window.ORVIA_ROLE_LABELS[accessProfile.role] || String(accessProfile.role);
};
window.renderAccountCard = function () {
  const box = document.getElementById('accountBox');
  if (!box) return;
  const O = window.ORVIA || {};
  const cfg = window.ORVIA_CFG || {};
  const state = (window.orviaSyncState ? window.orviaSyncState() : 'local');
  const badge = '<span class="syncbadge" id="syncBadge"></span>';
  // Nutzerkontrollierter Text (E-Mail/Rolle) NIE unescaped in innerHTML.
  function _esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  const roleName = window.orviaRoleLabel ? window.orviaRoleLabel(O.accessProfile) : null;
  let roleHTML;
  if (roleName != null) {
    roleHTML = '<b>' + _esc(roleName) + '</b>';
  } else {
    roleHTML = '<b class="err" style="color:var(--danger,#f66)">' + _authT('auth.konnte_nicht_geladen_werden') + '</b>';
    // Nur loggen, wenn tatsächlich ein eingeloggter Nutzer eine Rolle sehen müsste.
    if (O.user && cfg.configured) { try { console.error('[ORVIA auth] role_display_failed', JSON.stringify({ code: 'ACCESS_PROFILE_MISSING', at: new Date().toISOString() })); } catch (e) {} }
  }

  if (!cfg.configured) {
    box.innerHTML =
      '<div class="acc-row"><span>' + _authT('auth.modus') + '</span><b>' + _authT('auth.lokal_kein_konto') + '</b></div>' +
      '<div class="acc-row"><span>' + _authT('auth.status') + '</span>' + badge + '</div>' +
      '<p class="note" style="text-align:left">' + _authT('auth.cloud_sync_amp_accounts_sind') + '</p>';
  } else if (O.user) {
    box.innerHTML =
      '<div class="acc-row"><span>' + _authT('auth.angemeldet') + '</span><b>' + _esc(O.user.email || '—') + '</b></div>' +
      '<div class="acc-row"><span>' + _authT('auth.rolle') + '</span>' + roleHTML + '</div>' +
      '<div class="acc-row"><span>' + _authT('auth.sync') + '</span>' + badge + '</div>' +
      '<div class="row2" style="margin-top:12px">' +
        '<button class="btn sec" onclick="orviaSchedulePush&&orviaSchedulePush()">' + _authT('auth.jetzt_synchronisieren') + '</button>' +
        '<button class="btn sec" onclick="orviaLogout&&orviaLogout()">' + _authT('auth.abmelden') + '</button>' +
      '</div>' +
      '<div class="row2" style="margin-top:10px">' +
        '<button class="btn sec" onclick="orviaChangePassword&&orviaChangePassword()">' + _authT('auth.passwort_aendern') + '</button>' +
        '<button class="btn sec" onclick="orviaChangeEmail&&orviaChangeEmail()">' + _authT('auth.e_mail_aendern') + '</button>' +
      '</div>' +
      '<button class="btn gline" style="margin-top:10px" onclick="orviaDeleteAccount&&orviaDeleteAccount()">' + _authT('auth.konto_loeschen') + '</button>';
  } else {
    box.innerHTML = '<div class="acc-row"><span>' + _authT('auth.status') + '</span><b>' + _authT('auth.nicht_angemeldet') + '</b></div>';
  }

  const el = document.getElementById('syncBadge');
  if (el) {
    const L = {
      local: ['' + _authT('auth.lokaler_modus') + '', 'muted'],
      synced: ['Synchronisiert', 'ok'],
      pending: ['' + _authT('auth.sync_laeuft') + '', 'warn'],
      error: ['' + _authT('auth.sync') + '-Fehler', 'err'],
      offline: ['' + _authT('auth.offline_lokal') + '', 'warn']
    }[state] || ['' + _authT('auth.lokaler_modus') + '', 'muted'];
    el.textContent = L[0];
    el.className = 'syncbadge ' + L[1];
  }
};
