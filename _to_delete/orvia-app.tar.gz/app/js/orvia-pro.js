/* ============================================================
   ORVIA — Pro Layer (Phase 5, final)
   Premium-Modal-System, What-if-Simulation, Coach Mode,
   Pattern Detection, Weekly Review, Data Hub, Consent/Legal/
   Medical, Quick Actions, Splash, Offline-State.
   Additiv. Keine medizinische Diagnose, keine Heilversprechen.
   ============================================================ */

/* ---- Generisches Premium-Modal (nutzt vorhandenes #suppModal) ---- */
function oModal(title,body,footer){
  document.getElementById('suppSheet').innerHTML=
    '<div class="sheethead"><h2>'+escH(title)+'</h2><button class="xbtn" onclick="closeSupp()">✕</button></div>'+
    body+(footer||'');
  document.getElementById('suppModal').classList.add('show');
}
function kwColor(s){s=(''+s).toLowerCase();
  if(/hoch|erhöht|deutlich|negativ|kritisch|stoppen/.test(s))return 'var(--danger)';
  if(/moderat|leicht|neutral|stabil|easy/.test(s))return 'var(--accent)';
  if(/gering|keine|niedrig|positiv|sinkt|möglich/.test(s))return 'var(--success)';
  return 'var(--text-muted)';}

/* P1A: Quick-Actions-Legacy-Karte entfernt — der zentrale Plus-Button (Track B,
   js/quick-actions.js) ist der einzige Schnellzugriff. openWhatIf/openCoach/openWhy
   bleiben als Funktionen erhalten (Abbau-Entscheidung: Produktreife-Audit #34, M12). */

/* ============ WHAT-IF SIMULATION ============ */
function openWhatIf(){
  var risk=(typeof riskCard==='function')?riskCard():{score:0,rec:''};
  var b=risk.score;
  var opts=[
    {label:'Laufen wie geplant',load:'moderat–hoch',issue:b>=40?'erhöht':'gering',week:'positiv',tom:b>=40?'negativ':'neutral'},
    {label:'Bike Z2 statt Lauf',load:'moderat',issue:'stabil',week:'neutral',tom:'leicht positiv'},
    {label:'Einheit verkürzen',load:'niedrig–moderat',issue:'gering',week:'leicht positiv',tom:'neutral'},
    {label:'Pausieren / Regeneration',load:'keine',issue:'sinkt',week:'leicht negativ',tom:'positiv'},
    {label:'Trotzdem Intensität',load:'hoch',issue:b>=20?'deutlich erhöht':'erhöht',week:'positiv',tom:'negativ'}
  ];
  var best=b>=40?'Bike Z2 oder 5 km Easy':b>=20?'Easy Z2 — Intensität nur nach gutem Warm-up':'Plan möglich';
  var rows=opts.map(function(o){
    return '<div class="wif"><div class="wiflabel">'+escH(o.label)+'</div>'+
      '<div class="wifgrid">'+
        '<span>Belastung<b style="color:'+kwColor(o.load)+'">'+escH(o.load)+'</b></span>'+
        '<span>Beschwerderisiko<b style="color:'+kwColor(o.issue)+'">'+escH(o.issue)+'</b></span>'+
        '<span>Wochenziel<b style="color:'+kwColor(o.week)+'">'+escH(o.week)+'</b></span>'+
        '<span>Erholung morgen<b style="color:'+kwColor(o.tom)+'">'+escH(o.tom)+'</b></span>'+
      '</div></div>';}).join('');
  var conf=(typeof confidenceLevel==='function')?confidenceLevel():{l:'niedrig'};
  oModal('Was-wäre-wenn',
    '<p class="muted" style="margin:2px 0 14px">Simulierte Auswirkungen auf Basis deiner aktuellen Werte. Keine Garantie.</p>'+
    rows+
    '<div class="wifrec"><b>Empfehlung:</b> '+escH(best)+'. '+escH(risk.rec||'')+'</div>'+
    '<div style="margin-top:6px">'+confChip(conf)+'</div>',
    '<div class="row2" style="margin-top:14px"><button class="btn sec" onclick="closeSupp()">Schließen</button>'+
      '<button class="btn sec" onclick="closeSupp()">Alternative wählen</button></div>');
}

/* ============ COACH MODE (regelbasiert, datenbezogen) ============ */
var COACH_Q=[
  ['Warum heute (nicht) trainieren?','train'],
  ['Was ist die beste Alternative?','alt'],
  ['Was bedeutet meine HRV heute?','hrv'],
  ['Wie wirkt sich das auf mein Ziel aus?','goal'],
  ['Warum ist mein Risiko so?','risk']
];
function coachAnswer(key){
  var c=intelCtx(),risk=riskCard(),rd=recoveryDebt(),conf=confidenceLevel();
  var a='';
  if(key==='train'){a=risk.score>=40?'Erhöhtes Risiko ('+risk.state.l+'). '+risk.rec:risk.score>=20?'Training möglich, aber angepasst. '+risk.rec:'Werte tragen die geplante Einheit. '+risk.rec;}
  else if(key==='alt'){a=risk.score>=40?'Bike Z2, Schwimmen oder Mobility — gleiche Aktivierung, geringe Gelenk-/Erholungskosten.':'Easy Z2 oder verkürzte Einheit, falls du Reserve sparen willst.';}
  else if(key==='hrv'){a=c.hrvDevPct==null?'Noch keine stabile HRV-Baseline. Mehr Daten sammeln.':(c.hrvDevPct<=-8?'HRV '+c.hrvDevPct.toFixed(0)+'% unter Schnitt — Hinweis auf unvollständige Erholung/Belastung. Intensität zurückstellen.':c.hrvDevPct<0?'HRV leicht unter Schnitt ('+c.hrvDevPct.toFixed(0)+'%). Normale Steuerung, Intensität nach Warm-up.':'HRV im/über Normalbereich — gute Erholung.');}
  else if(key==='goal'){a='Wochen-km '+c.weekKm.toFixed(0)+(c.targetKm?' / '+c.targetKm+' Soll. ':'. ')+(rd.score>=45?'Regenerationsdefizit hoch — zusätzliche Last bringt heute wenig Zielnutzen.':'Konsistenz zahlt aufs Ziel ein; Erholung mitnehmen.');}
  else if(key==='risk'){a='Risiko '+risk.state.l+(risk.why.length?' — Treiber: '+risk.why.join(', ')+'.':'.')+' '+risk.rec;}
  return a+'  ['+conf.l+']';
}
function openCoach(){
  var qs=COACH_Q.map(function(q,i){return '<button class="coachq" onclick="coachShow('+i+')">'+escH(q[0])+'</button>';}).join('');
  oModal('Coach',
    '<p class="muted" style="margin:2px 0 14px">Kurze, datenbezogene Antworten. Keine medizinische Diagnose.</p>'+
    '<div class="coachqs">'+qs+'</div><div id="coachA" class="coachA"></div>');
}
function coachShow(i){
  var ans=coachAnswer(COACH_Q[i][1]);
  document.getElementById('coachA').innerHTML='<div class="coachbubble"><div class="coachqlabel">'+escH(COACH_Q[i][0])+'</div>'+escH(ans)+'</div>';
}
function openWhy(){var ans=coachAnswer('train');oModal('Warum heute?', '<div class="coachbubble">'+escH(ans)+'</div>');}

/* ============ PATTERN DETECTION ============ */
function detectPatterns(){
  var pats=[];var days=[];for(var i=0;i<60;i++){var k=dkey(-i);if(DB[k])days.push(DB[k]);}
  if(dataDays()<10)return null;
  // 1) Beschwerde nach langen Läufen
  var afterLong=[],afterShort=[];
  for(var i=1;i<60;i++){var prev=DB[dkey(-i)],curd=DB[dkey(-i+1)];if(!prev||!curd)continue;
    var run=prev.sessions&&prev.sessions.Laufen;var nk=(curd.morning&&curd.morning.knee!=null)?curd.morning.knee:null;
    if(run&&run.dist!=null&&nk!=null){(run.dist>=7?afterLong:afterShort).push(nk);}}
  if(afterLong.length>=3&&afterShort.length>=3){var dl=Calc.avg(afterLong)-Calc.avg(afterShort);
    if(dl>=0.8)pats.push('Beschwerden steigen meist nach Läufen ab ~7 km (Ø +'+dl.toFixed(1)+'/10 am Folgetag).');}
  // 2) Schlaf < 6:20 senkt Readiness am Folgetag
  var lowR=[],hiR=[];
  for(var i=1;i<60;i++){var prev=DB[dkey(-i)],curd=DB[dkey(-i+1)];if(!prev||!curd)continue;
    var sm=prev.morning&&prev.morning.sleepMin;var r=(typeof readinessOf==='function')?readinessOf(dkey(-i+1)):null;
    if(sm!=null&&r!=null){(sm<380?lowR:hiR).push(r);}}
  if(lowR.length>=3&&hiR.length>=3){var dr=Calc.avg(hiR)-Calc.avg(lowR);
    if(dr>=6)pats.push('Schlaf unter ~6:20 h senkt deine Readiness am Folgetag deutlich (Ø −'+dr.toFixed(0)+'%).');}
  // 3) schwächster Wochentag
  var wd=[[],[],[],[],[],[],[]];
  for(var i=0;i<60;i++){var k=dkey(-i);var e=DB[k];if(!e)continue;var r=(typeof readinessOf==='function')?readinessOf(k):null;
    if(r!=null){var d=(new Date(k+'T12:00').getDay()+6)%7;wd[d].push(r);}}
  var names=['Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag','Sonntag'],worst=null,worstV=999;
  for(var d=0;d<7;d++){if(wd[d].length>=3){var av=Calc.avg(wd[d]);if(av<worstV){worstV=av;worst=d;}}}
  if(worst!=null&&worstV<70)pats.push(names[worst]+'e sind im Schnitt deine schwächeren Erholungstage (Ø '+worstV.toFixed(0)+'% Readiness).');
  return pats;
}
function renderPatterns(){
  var el=document.getElementById('patternBox');if(!el)return;
  var p=detectPatterns();
  if(p==null){el.innerHTML='<p class="muted">Noch keine stabilen Muster. ORVIA benötigt mehr Verlauf (~10+ Tage).</p>';return;}
  if(!p.length){el.innerHTML='<p class="muted">Keine auffälligen Muster im aktuellen Zeitfenster.</p>';return;}
  el.innerHTML=p.map(function(x){return '<div class="insight">'+escH(x)+'</div>';}).join('');
}

/* ============ WEEKLY REVIEW ============ */
/* Phase 3 · Block 2 (2026-08-05): Inhalt als Funktion extrahiert — derselbe
   kanonische Wochen-Review speist jetzt AUCH das GM-Sheet auf dem Plan-Tab
   (gmOpenWeekReviewSheet). EINE Berechnung, zwei Darstellungen, kein Doppelweg. */
function weeklyReviewHTML(){
  if(dataDays()<3)return '<p class="muted">Wochen-Review erscheint nach einigen Check-ins.</p>';
  // DT1: Trainings-Istwerte aus dem EINEN kanonischen Wochen-Vertrag (Store+Legacy dedupliziert),
  // nicht mehr aus dem reinen DB-Blob. Readiness/Schlaf laufen über dieselben Mo–So-Wochentage.
  var _acts=(window.ORVIA&&ORVIA.activityStore)?ORVIA.activityStore.listActivities():[];
  var _ts=(window.ORVIA&&ORVIA.activityStore&&ORVIA.activityStore.isTombstoned)?ORVIA.activityStore.isTombstoned:null;
  // DT1b: effektive Nutzerzeitzone (profileStore.effectiveTimezone) statt fester Konstante; weekRef = heutiges LOKALES Datum in DIESER tz.
  var _tz=(window.ORVIA&&ORVIA.profileStore&&ORVIA.profileStore.effectiveTimezone)?ORVIA.profileStore.effectiveTimezone():'UTC';
  var _ref=(window.ORVIA&&ORVIA.activityConfig&&ORVIA.activityConfig.dayOfActLocal)?ORVIA.activityConfig.dayOfActLocal({startedAt:new Date().toISOString()},_tz):todayStr();
  var _wk=(window.ORVIA&&ORVIA.activityConfig&&ORVIA.activityConfig.weeklyActivityTotals)?ORVIA.activityConfig.weeklyActivityTotals(_acts,DB,{weekRef:_ref,timezone:_tz,isTombstoned:_ts}):null;
  var _runB=_wk&&_wk.bySport&&_wk.bySport.running;
  var runs=(_runB&&_runB.sessionCount)||0;
  var _kmComplete=!!(_runB&&_runB.completeness&&_runB.completeness.distance);
  var kmW=_runB?(_kmComplete?(_runB.distanceKm||0):(_runB.knownDistanceKm||0)):0;   // numerisch für Empfehlung (Teilsumme wenn unvollständig)
  var kmLabel; if(!runs)kmLabel='0'; else if(_kmComplete)kmLabel=(_runB.distanceKm||0).toFixed(0); else if(_runB.knownDistanceKm>0)kmLabel='mind. '+_runB.knownDistanceKm.toFixed(0); else kmLabel='–';
  var gym=(_wk&&_wk.bySport.gym&&_wk.bySport.gym.sessionCount)||0;
  var ready=[],sleeps=[],issues=[],best=null,worst=null,bV=-1,wV=999;
  var _wkDays=(_wk&&_wk.days)?_wk.days:(function(){var a=[];for(var i=0;i<7;i++)a.push(dkey(-i));return a;})();
  _wkDays.forEach(function(k){var e=DB[k];if(!e)return;
    var r=(typeof readinessOf==='function')?readinessOf(k):null;if(r!=null){ready.push(r);if(r>bV){bV=r;best=k;}if(r<wV){wV=r;worst=k;}}
    if(e.morning){if(e.morning.sleepMin)sleeps.push(e.morning.sleepMin/60);if(e.morning.knee!=null)issues.push(e.morning.knee);}});
  var target=(typeof Calc!=='undefined'&&typeof daysTo==='function')?Calc.weekKmTarget(daysTo(RACE.date),0):0;
  var rd=(typeof recoveryDebt==='function')?recoveryDebt():{state:{l:'–'}};
  function fmtD(k){return k?new Date(k+'T12:00').toLocaleDateString('de-DE',{weekday:'short'}):'–';}
  var rec=(wV<60?'Achte auf die schwächeren Tage. ':'')+(target&&kmW>target?'Volumen nächste Woche maximal +5–10 % steigern; keine zweite harte Einheit, wenn HRV fällt.':'Konstanz halten, eine Qualitätseinheit einplanen, wenn Readiness es zulässt.');
  var rows=[
    ['Läufe / Wochen-km',runs+' · '+kmLabel+(target?' / '+target+' km Soll':'')],
    ['Krafttraining',gym+''],
    ['Ø Readiness',ready.length?Math.round(Calc.avg(ready))+'%':'–'],
    ['Ø Schlaf',sleeps.length?Calc.avg(sleeps).toFixed(1)+' h':'–'],
    ['Ø Beschwerde',issues.length?Calc.avg(issues).toFixed(1)+'/10':'–'],
    ['Stärkster / schwächster Tag',fmtD(best)+' / '+fmtD(worst)],
    ['Regenerationsdefizit',rd.state.l]
  ];
  return rows.map(function(r){return '<div class="blrow"><span class="blk">'+escH(r[0])+'</span><span class="blv">'+escH(r[1])+'</span></div>';}).join('')+
    '<p class="modtext" style="margin-top:12px"><b>Empfehlung:</b> '+escH(rec)+'</p>';
}
function renderWeekly(){
  var el=document.getElementById('weeklyBox');if(!el)return;
  el.innerHTML=weeklyReviewHTML();
}

/* ============ DATA HUB ============ */
function trainingDays(){var n=0;for(var i=0;i<400;i++){var e=DB[dkey(-i)];if(e&&e.sessions&&Object.keys(e.sessions).filter(function(x){return x!=='_ts';}).length)n++;}return n;}
function hasMetric(field){for(var i=0;i<60;i++){var e=DB[dkey(-i)];if(e&&e.morning&&e.morning[field]!=null)return true;}return false;}
function renderDataHub(){
  var el=document.getElementById('dataHub');if(!el)return;
  var n=dataDays(),dq=dataQualityLabel(n),src=(PROFILE&&PROFILE.dataSources)||[];
  var miss=[];if(!hasMetric('hrvMs'))miss.push('HRV');if(trainingDays()<3)miss.push('Trainingsdaten');if(!hasMetric('knee'))miss.push('Beschwerdedaten');
  var srcChips=['Apple Health','Garmin','Strava','CSV','Manuell'].map(function(s){
    var on=src.indexOf(s)>=0;return '<span class="srcchip'+(on?' on':'')+'">'+escH(s)+(on?'':' · vorbereitet')+'</span>';}).join('');
  el.innerHTML=
    '<div class="dhrow"><span class="blk">Datenqualität</span><span class="dq dq-'+dq.c+'">'+n+' Tage · '+dq.l+'</span></div>'+
    '<div class="dhrow"><span class="blk">Check-ins gespeichert</span><span class="blv">'+n+'</span></div>'+
    '<div class="dhrow"><span class="blk">Trainings gespeichert</span><span class="blv">'+trainingDays()+'</span></div>'+
    '<div class="dhrow"><span class="blk">Fehlende Daten</span><span class="blv">'+(miss.length?escH(miss.join(', ')):'–')+'</span></div>'+
    '<div class="modlbl">Quellen</div><div class="srcchips">'+srcChips+'</div>'+
    '<p class="note" style="text-align:left;margin-top:10px">API-Anbindung (Apple Health/Garmin/Strava) ist vorbereitet — aktuell manueller Import & Paste. 0–3 Tage: Prognose unsicher · 4–7: erste Muster · 8–21: Trends · 21+: stabile Empfehlungen.</p>';
}

/* ============ CONSENT / LEGAL / MEDICAL ============ */
var CONSENT_KEY='orvia_consent';
function loadConsent(){try{return JSON.parse(localStorage.getItem(CONSENT_KEY))||{};}catch(e){return {};}}
function saveConsent(c){try{localStorage.setItem(CONSENT_KEY,JSON.stringify(c));}catch(e){}}
var CONSENT_ITEMS=[
  ['health','Gesundheits- & Fitnessdaten verarbeiten'],
  ['import','Import aus Apple Health / Garmin / Strava'],
  ['local','Lokale Speicherung auf diesem Gerät'],
  ['analyse','Analyse & Insights aus meinen Daten'],
  ['notif','Optionale Erinnerungen / Notifications'],
  ['improve','Anonymisierte Produktverbesserung']
];
function openConsent(){
  var c=loadConsent();
  var rows=CONSENT_ITEMS.map(function(it){var on=!!c[it[0]];
    return '<label class="cslabel"><span>'+escH(it[1])+'</span>'+
      '<button class="cstoggle'+(on?' on':'')+'" onclick="toggleConsent(\''+it[0]+'\',this)" aria-pressed="'+on+'"></button></label>';}).join('');
  oModal('Einwilligungen',
    '<p class="muted" style="margin:2px 0 14px">Du entscheidest, was ORVIA verarbeiten darf. Sensible Einwilligungen sind nicht vorausgewählt und jederzeit widerrufbar.</p>'+
    rows+
    '<div class="modwarn" style="margin-top:16px">Sensible Gesundheitsdaten. Verarbeitung nur mit deiner Einwilligung. Datenexport & Löschung jederzeit möglich.</div>');
}
function toggleConsent(key,btn){var c=loadConsent();c[key]=!c[key];saveConsent(c);btn.classList.toggle('on',c[key]);btn.setAttribute('aria-pressed',c[key]);}
function openLegal(){
  oModal('Rechtliches & Daten',
    '<div class="legalgrid">'+
    ['Impressum','Datenschutzerklärung','Nutzungsbedingungen','Cookie-/Tracking-Einstellungen'].map(function(t){
      return '<button class="legalitem" onclick="openLegalDoc(\''+escH(t)+'\')">'+escH(t)+'</button>';}).join('')+
    '<button class="legalitem" onclick="openConsent()">Einwilligungen verwalten</button>'+
    '<button class="legalitem" onclick="openMedical()">Medizinischer Hinweis</button>'+
    '<button class="legalitem" onclick="exportData()">Datenexport</button>'+
    '<button class="legalitem danger" onclick="confirmDelete()">Alle Daten löschen</button>'+
    '</div>'+
    '<p class="note" style="text-align:left;margin-top:12px">Sprache: Deutsch · Region: EU. Datenmodell v4. Die Rechtstexte sind inhaltlich zutreffende Entwürfe und müssen vor Veröffentlichung juristisch geprüft werden (Anschrift im Impressum offen).</p>');
}
/* ---- Versteckter Diagnosezugang: 7 Taps auf die sichtbare Versionszeile (index.html .obrandfoot,
   data-orvia-version-trigger) innerhalb von 5 s. EVENT-DELEGATION auf document → überlebt jedes
   Re-Render; reagiert auf click UND touchend (mit Dedup gegen Doppelauslösung). NICHT persistent
   (nach App-Neustart wieder inaktiv). Keine sichtbare Dev-Funktion in der normalen Oberfläche. ---- */
(function(){
  if(typeof document==='undefined')return;
  var versionTapCount=0, versionTapStartedAt=0, lastHandledAt=0;
  function handleVersionTap(ev){
    var t=ev&&ev.target; if(!t||!t.closest)return;
    if(!t.closest('[data-orvia-version-trigger="true"]'))return;
    var now=Date.now();
    if(now-lastHandledAt<250)return;      // Dedup: touchend+click bzw. Doppeltap
    lastHandledAt=now;
    if(!versionTapStartedAt||now-versionTapStartedAt>5000){versionTapStartedAt=now;versionTapCount=1;}
    else versionTapCount+=1;
    if(versionTapCount===5&&typeof toast==='function')toast('Noch 2 Taps');
    else if(versionTapCount===6&&typeof toast==='function')toast('Noch 1 Tap');
    if(versionTapCount>=7){versionTapCount=0;versionTapStartedAt=0;activateDeveloperDiagnostics();}
  }
  document.addEventListener('click',handleVersionTap);
  document.addEventListener('touchend',handleVersionTap,{passive:true});
})();
function activateDeveloperDiagnostics(){
  var d=document.getElementById('ov-diag');
  if(!d){ // Fallback: direkt nach der Versionszeile erzeugen
    var trg=document.querySelector('[data-orvia-version-trigger="true"]');
    if(trg&&trg.parentNode){d=document.createElement('div');d.id='ov-diag';trg.parentNode.appendChild(d);}
  }
  if(!d)return;
  if(!d.innerHTML){
    d.innerHTML='<div class="card" style="margin-top:10px"><h2><svg class="ic"><use href="#i-pulse"/></svg>Entwicklerdiagnose</h2>'+
      '<p class="note" style="text-align:left">Nur Diagnose. Verändert keine Daten, kein Netzwerkzugriff.</p>'+
      '<button class="btn sec" onclick="orviaOpenShadow()">Gym-Shadow-Report erstellen</button></div>';
  }
  try{d.scrollIntoView({behavior:'smooth',block:'nearest'});}catch(e){}
  if(typeof toast==='function')toast('Entwicklerdiagnose aktiviert');
}
function orviaOpenShadow(){
  try{
    if(window.ORVIA&&ORVIA.gymVolume&&ORVIA.gymVolume.showShadowReport){ORVIA.gymVolume.showShadowReport({days:28,goal:'hypertrophy',experience:'intermediate'});}
    else if(typeof toast==='function'){toast('Shadow-Engine nicht verfügbar');}
  }catch(e){try{console.error('[ORVIA diag]',e);}catch(_){}}
}
/* KF-012: Vorher teilten sich Impressum, Datenschutzerklaerung, Nutzungs-
   bedingungen und Cookie-Einstellungen EINEN Platzhaltertext. Jetzt hat jedes
   Dokument einen eigenen, inhaltlich zutreffenden Entwurf, der die TATSAECHLICHE
   Datenverarbeitung beschreibt (lokal zuerst, Supabase-Konto/-Sync, Garmin ueber
   den eigenen Worker, keine Werbe-Tracker). Adresse und juristische Endpruefung
   sind ausdruecklich als offen markiert — hier wird nichts erfunden. */
var ORVIA_LEGAL={
  'Impressum':
    '<p class="modtext"><b>Angaben gemäß § 5 DDG (Entwurf)</b><br>ORVIA — Trainings- und Performance-App<br>'+
    'Betreiber: Gian Thaysen<br>Kontakt: gthaysen@thaysen.com<br>'+
    '<i>[Ladungsfähige Anschrift wird vor Veröffentlichung ergänzt — ohne sie darf die App nicht öffentlich betrieben werden.]</i></p>'+
    '<p class="modtext">ORVIA befindet sich in einer geschlossenen Beta (Research-Preview). Kein Medizinprodukt, keine Heilkunde.</p>',
  'Datenschutzerklärung':
    '<p class="modtext"><b>Was ORVIA tatsächlich verarbeitet (Entwurf)</b></p>'+
    '<p class="modtext">1. <b>Lokal zuerst:</b> Check-ins, Trainingsdaten und Einstellungen liegen primär auf deinem Gerät (Browser-Speicher). Ohne Konto verlässt nichts dein Gerät.</p>'+
    '<p class="modtext">2. <b>Konto &amp; Sync (Supabase):</b> Mit Konto werden Profil, Aktivitäten, Kennzahlen und Pläne in deiner privaten Datenbankzeile gespeichert (Row-Level-Security: nur dein Konto liest deine Daten). Rechtsgrundlage: Vertragserfüllung, Art. 6 Abs. 1 lit. b DSGVO.</p>'+
    '<p class="modtext">3. <b>Garmin:</b> Auf Wunsch synchronisiert ein eigener Worker deine Garmin-Daten (Aktivitäten, Schlaf, HF-Kennzahlen). Die Anmeldung erfolgt ausschließlich auf deinem eigenen Rechner; ORVIA speichert dein Garmin-Passwort nicht. Rechtsgrundlage: Einwilligung, Art. 6 Abs. 1 lit. a DSGVO — jederzeit widerrufbar durch Trennen der Verbindung.</p>'+
    '<p class="modtext">4. <b>Keine Werbung, kein Tracking:</b> keine Werbe-Tracker, kein Verkauf von Daten, keine Analyse-Cookies Dritter.</p>'+
    '<p class="modtext">5. <b>Deine Rechte:</b> Auskunft, Berichtigung, Löschung, Datenübertragbarkeit (JSON-Export in der App), Widerruf. Löschen entfernt Konto und Daten.</p>'+
    '<p class="modtext"><i>Entwurf — vor Veröffentlichung juristisch zu prüfen (u. a. Auftragsverarbeiter-Liste, Speicherorte, Fristen).</i></p>',
  'Nutzungsbedingungen':
    '<p class="modtext"><b>Nutzungsbedingungen (Entwurf)</b></p>'+
    '<p class="modtext">1. ORVIA ist eine Beta-Software zur Trainingsunterstützung. Verfügbarkeit und Funktionsumfang können sich ändern.</p>'+
    '<p class="modtext">2. ORVIA ist <b>kein Medizinprodukt</b> und ersetzt keine ärztliche oder physiotherapeutische Beratung. Trainingsentscheidungen triffst du eigenverantwortlich; bei Warnzeichen empfiehlt ORVIA ärztliche Abklärung.</p>'+
    '<p class="modtext">3. Kennzahlen (z. B. Prognosen, Belastungswerte) sind Modellwerte auf Basis deiner Daten — ORVIA kennzeichnet Messung und Schätzung, garantiert aber keine Richtigkeit.</p>'+
    '<p class="modtext">4. Ein Konto ist persönlich; Zugangsdaten sind geheim zu halten. Missbrauch führt zur Sperrung.</p>'+
    '<p class="modtext">5. Haftung: unbeschränkt bei Vorsatz und grober Fahrlässigkeit; im Übrigen nur für die Verletzung wesentlicher Vertragspflichten, begrenzt auf den vorhersehbaren Schaden.</p>'+
    '<p class="modtext"><i>Entwurf — vor Veröffentlichung juristisch zu prüfen.</i></p>',
  'Cookie-/Tracking-Einstellungen':
    '<p class="modtext"><b>Cookies &amp; lokale Speicherung (Entwurf)</b></p>'+
    '<p class="modtext">ORVIA setzt <b>keine Tracking- oder Werbe-Cookies</b>. Verwendet werden ausschließlich technisch notwendige lokale Speicher: App-Daten und Einstellungen (Browser-Speicher), die Anmeldesitzung deines Kontos sowie der Offline-Cache der App (Service Worker). Diese sind für den Betrieb erforderlich und nicht einwilligungspflichtig; es gibt daher nichts abzuwählen.</p>'+
    '<p class="modtext">Einwilligungen zu inhaltlichen Funktionen (z. B. Garmin-Sync) verwaltest du unter „Einwilligungen verwalten".</p>'
};
function openLegalDoc(t){
  var body=ORVIA_LEGAL[t]||('<p class="modtext">'+escH(t)+' — Dokument nicht gefunden.</p>');
  oModal(t,body);
}
function openMedical(){oModal('Medizinischer Hinweis','<p class="modtext">'+escH(ORVIA_DISCLAIMER)+'</p><p class="modtext" style="margin-top:10px">Bei Warnsignalen (starke/zunehmende Schmerzen, Schmerz in Ruhe, Schwellung, Taubheit, Ausstrahlung, Fieber, Atemnot, Brustschmerz, Schwindel) gibt ORVIA keine Trainingsentscheidung, sondern empfiehlt ärztliche Abklärung.</p>');}
function confirmDelete(){
  oModal('Alle Daten löschen','<p class="modtext">Das löscht alle Check-ins, dein Profil und Einwilligungen unwiderruflich von diesem Gerät. Vorher Backup ziehen?</p>',
    '<div class="row2" style="margin-top:14px"><button class="btn sec" onclick="exportData()">Backup</button>'+
    '<button class="btn" style="background:var(--danger);color:#fff;border:none" onclick="doDeleteAll()">Endgültig löschen</button></div>');
}
function doDeleteAll(){try{var ks=Object.keys(DB).filter(isDay);ks.forEach(function(k){delete DB[k];});save&&save();
  localStorage.removeItem('orvia_profile_v1');localStorage.removeItem(CONSENT_KEY);}catch(e){}
  closeSupp();if(typeof toast==='function')toast('Daten gelöscht');setTimeout(function(){location.reload();},600);}
function renderLegalCard(){var el=document.getElementById('legalCard');if(!el)return;
  el.innerHTML='<button class="btn sec" onclick="openLegal()">'+ic('info')+' Rechtliches & Daten</button>'+
    '<button class="btn sec" onclick="openConsent()" style="margin-top:10px">'+ic('gear')+' Einwilligungen</button>'+
    '<p class="note" style="text-align:left;margin-top:10px">'+escH(ORVIA_DISCLAIMER)+'</p>';}

/* ============ SPLASH + OFFLINE ============ */
function hideSplash(){var s=document.getElementById('splash');if(!s)return;s.classList.add('hide');setTimeout(function(){s.style.display='none';},600);}
function initOffline(){
  function upd(){var b=document.getElementById('offline');if(!b)return;b.style.display=navigator.onLine?'none':'block';}
  window.addEventListener('online',upd);window.addEventListener('offline',upd);upd();
}
window.addEventListener('load',function(){setTimeout(hideSplash,850);initOffline();});

/* Sammelaufrufe */
function renderProExtras(){if(typeof renderPatterns==='function')renderPatterns();if(typeof renderWeekly==='function')renderWeekly();}
