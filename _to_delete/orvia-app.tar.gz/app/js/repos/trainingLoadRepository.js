/* ORVIA · trainingLoadRepository — training_load_daily (Dedupe via external_id / Natur-Key) */
(function () {
  const O = window.ORVIA, B = O.repoBase;

  // sRPE-Last = Dauer * RPE (Mobilität fix RPE 2), konsistent mit calc.sessionLoad.
  function computeLoad(sport, durationMin, rpe) {
    const r = sport === 'Mobilität' ? 2 : (rpe || 5);
    return (durationMin || 0) * r;
  }

  function toRow(date, sport, s) {
    const dur = s.dur != null ? s.dur : null;
    const rpe = s.rpe != null ? s.rpe : null;
    return {
      local_date: date,
      sport: sport,
      source: s.source || (s.note && /strava|garmin/i.test(s.note) ? 'strava' : 'manual'),
      // Stabile Client-ID: erlaubt mehrere Einheiten/Tag/Sportart, dedupliziert aber Re-Syncs.
      client_session_id: s.client_session_id || s.clientSessionId || null,
      duration_min: dur,
      distance_km: s.dist != null ? s.dist : null,
      intensity: s.hr != null ? s.hr : null,
      session_rpe: rpe,
      computed_load: computeLoad(sport, dur, rpe),
      external_id: s.external_id || s.externalId || null
    };
  }
  // Konflikt-Key je Zeile bestimmen (external_id > client_session_id > kein Dedupe).
  function conflictKey(row) {
    if (row.external_id) return 'user_id,source,external_id';
    if (row.client_session_id) return 'user_id,client_session_id';
    return null;
  }

  O.repos.trainingLoad = {
    toRow, computeLoad,
    async listRange(fromDate, toDate) {
      const g = B.requireAuth(); if (g) return g;
      if (!B.online()) return B.fail('offline', 'Offline.', { offline: true });
      try {
        let q = B.sb().from('training_load_daily').select('*')
          .eq('user_id', B.currentUserId()).order('local_date', { ascending: true });
        if (fromDate) q = q.gte('local_date', fromDate);
        if (toDate) q = q.lte('local_date', toDate);
        const { data, error } = await q;
        if (error) return B.fail('query_failed', error.message);
        return B.ok(data || []);
      } catch (e) { return B.fail('exception', String(e && e.message || e)); }
    },
    conflictKey,
    // Externe Aktivität: dedupe über external_id. Sonst über client_session_id.
    // Ohne beides: reiner Insert (mehrere Einheiten/Tag/Sportart möglich).
    async save(date, sport, session) {
      const row = toRow(date, sport, session);
      const conflict = conflictKey(row);
      return conflict ? B.upsert('training_load_daily', row, conflict)
                      : B.upsert('training_load_daily', row);
    },
    async saveMany(rows) {
      // getrennt nach Konflikt-Key upserten (Postgres erlaubt nur einen onConflict je Aufruf)
      const ext = rows.filter(r => r.external_id);
      const cli = rows.filter(r => !r.external_id && r.client_session_id);
      const none = rows.filter(r => !r.external_id && !r.client_session_id);
      const r1 = ext.length  ? await B.upsertMany('training_load_daily', ext, 'user_id,source,external_id') : B.ok([]);
      const r2 = cli.length  ? await B.upsertMany('training_load_daily', cli, 'user_id,client_session_id')  : B.ok([]);
      const r3 = none.length ? await B.upsertMany('training_load_daily', none)                               : B.ok([]);
      for (const r of [r1, r2, r3]) if (!r.success) return r;
      return B.ok([].concat(r1.data || [], r2.data || [], r3.data || []));
    },
    // Roh-Aggregation: Σ computed_load NUR für Tage mit Einträgen (fehlende Tage NICHT enthalten).
    async getDailyLoad(fromDate, toDate) {
      const r = await this.listRange(fromDate, toDate);
      if (!r.success) return r;
      const byDay = {};
      (r.data || []).forEach(x => { const d = x.local_date; if (d) byDay[d] = (byDay[d] || 0) + (+x.computed_load || 0); });
      const out = Object.keys(byDay).sort().map(d => ({ local_date: d, load: Math.round(byDay[d]) }));
      return B.ok(out, { source: out.length ? 'supabase' : 'empty' });
    },
    // Vollständige Tagesreihe für Trends/Lastsprung. fillMissing → jeder Kalendertag im Bereich,
    // fehlende Tage load:0 (=„keine erfasste Aktivität"; Datenqualität separat über dataDays).
    async getDailyLoadSeries(fromDate, toDate, opts) {
      const r = await this.getDailyLoad(fromDate, toDate);
      if (!r.success) return r;
      const fill = !(opts && opts.fillMissing === false);
      if (!fill || !fromDate || !toDate) return r;
      const byDay = {}; (r.data || []).forEach(x => { byDay[x.local_date] = x.load; });
      const out = []; let dataDays = 0;
      const m1 = /^(\d{4})-(\d{2})-(\d{2})$/.exec(fromDate), m2 = /^(\d{4})-(\d{2})-(\d{2})$/.exec(toDate);
      if (!m1 || !m2) return r;
      let d = new Date(+m1[1], +m1[2] - 1, +m1[3]); const end = new Date(+m2[1], +m2[2] - 1, +m2[3]);
      while (d <= end) {
        const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
        const has = Object.prototype.hasOwnProperty.call(byDay, key);
        if (has) dataDays++;
        out.push({ local_date: key, load: has ? byDay[key] : 0, hasData: has });
        d.setDate(d.getDate() + 1);
      }
      return B.ok(out, { source: 'supabase' });
    },
    // Lösch-Sync NUR für MANUELLE Tages-Sessions (source='manual'). Externe Quellen
    // (strava/garmin) werden NIE gelöscht — auch nicht, wenn sie eine client_session_id tragen.
    // Strukturierte Rückgabe: { deleted, failed, errors }. Kein Scheinerfolg bei Teilfehlern.
    async pruneManualDay(date, keepClientIds) {
      const g = B.requireAuth(); if (g) return g;
      if (!B.online()) return B.fail('offline', 'Offline.', { offline: true, source: 'indexeddb', sync_status: 'pending' });
      try {
        const { data, error } = await B.sb().from('training_load_daily')
          .select('id,client_session_id,source').eq('user_id', B.currentUserId())
          .eq('local_date', date).eq('source', 'manual').not('client_session_id', 'is', null);
        if (error) return B.fail('query_failed', error.message);
        const keep = keepClientIds || [];
        const del = (data || []).filter(x => keep.indexOf(x.client_session_id) < 0);
        let deleted = 0, failed = 0; const errors = [];
        for (const x of del) {
          const dr = await B.sb().from('training_load_daily').delete().eq('id', x.id).eq('user_id', B.currentUserId()).eq('source', 'manual');
          if (dr && dr.error) { failed++; errors.push(dr.error.message); } else deleted++;
        }
        if (failed) return B.fail('partial_delete', 'Lösch-Sync teilweise fehlgeschlagen', { source: 'supabase', sync_status: 'failed', deleted: deleted, failed: failed, errors: errors });
        return B.ok({ deleted: deleted, failed: 0, errors: [] });
      } catch (e) { return B.fail('exception', String(e && e.message || e)); }
    },

    /* ============================================================
       Phase 5B (2026-08-05) · KANONISCHES LOAD-READ-MODELL
       ------------------------------------------------------------
       Ableitungsvertrag Intensität (E-11, Dimension A — subjektive
       Session-Intensität aus RPE; die HF-basierte easyShare bleibt als
       getrennte Dimension B in calc.js, KEINE dritte Definition):
         RPE 1–4  ⇒ easy · RPE 5–6 ⇒ moderate · RPE 7–10 ⇒ hard
         RPE fehlt ⇒ unknown (Entscheidung ③: markieren, NIE raten/löschen)
       ACHTUNG Altlast: die Spalte `intensity` enthält die Ø-HERZFREQUENZ
       (Zahl), keine Kategorie — sie fließt hier bewusst NICHT ein.
       bySport: kanonische Sport-IDs (running/cycling/gym/…); unbekannte
       Sportarten laufen als 'other' mit, verschwinden nicht.
       completeness: Anteil der Sessions des Tages mit belastbarer Last
       (duration_min vorhanden UND computed_load > 0).
       deriveCanonicalDays ist PUR (Node-testbar); readCanonicalRange ist
       die I/O-Huelle. Konsumenten werden erst NACH dem 5A-Audit umgestellt.
       ============================================================ */
    intensityBandOf(rpe) {
      if (rpe == null || isNaN(+rpe)) return 'unknown';
      const r = +rpe;
      if (r <= 4) return 'easy';
      if (r <= 6) return 'moderate';
      return 'hard';
    },
    canonicalSportOf(sport) {
      const raw = String(sport == null ? '' : sport).trim();
      try { if (O.trainingDomain && O.trainingDomain.normSport) { const n = O.trainingDomain.normSport(raw); if (n) return n; } } catch (e) {}
      const MAP = { laufen: 'running', running: 'running', rad: 'cycling', cycling: 'cycling', bike: 'cycling',
        gym: 'gym', kraft: 'gym', krafttraining: 'gym', strength: 'gym',
        schwimmen: 'swimming', swimming: 'swimming', 'mobilität': 'mobility', 'mobilitaet': 'mobility', mobility: 'mobility' };
      return MAP[raw.toLowerCase()] || (raw ? 'other' : 'unknown');
    },
    deriveCanonicalDays(rows) {
      const byDay = {};
      (rows || []).forEach(x => {
        if (!x || !x.local_date) return;
        const d = byDay[x.local_date] || (byDay[x.local_date] = {
          date: x.local_date, totalLoad: 0, bySport: {}, byIntensity: { easy: 0, moderate: 0, hard: 0, unknown: 0 },
          sessionCount: 0, usableSessions: 0
        });
        const load = (x.computed_load != null && isFinite(+x.computed_load)) ? +x.computed_load : null;
        const sport = this.canonicalSportOf(x.sport);
        const band = this.intensityBandOf(x.session_rpe);
        d.sessionCount++;
        if (load != null && load > 0 && x.duration_min != null) d.usableSessions++;
        if (load != null && load > 0) {
          d.totalLoad += load;
          d.bySport[sport] = (d.bySport[sport] || 0) + load;
          d.byIntensity[band] += load;
        } else {
          /* Session ohne belastbare Last: zaehlt fuer completeness, traegt aber
             keine erfundenen Load-Punkte bei (kein 0-als-Wert-Etikett). */
          if (d.bySport[sport] == null) d.bySport[sport] = 0;
        }
      });
      return Object.keys(byDay).sort().map(k => {
        const d = byDay[k];
        d.totalLoad = Math.round(d.totalLoad);
        Object.keys(d.bySport).forEach(s => { d.bySport[s] = Math.round(d.bySport[s]); });
        Object.keys(d.byIntensity).forEach(b => { d.byIntensity[b] = Math.round(d.byIntensity[b]); });
        d.completeness = d.sessionCount ? Math.round(d.usableSessions / d.sessionCount * 100) / 100 : 0;
        return d;
      });
    },
    async readCanonicalRange(fromDate, toDate) {
      const r = await this.listRange(fromDate, toDate);
      if (!r.success) return r;
      return B.ok(this.deriveCanonicalDays(r.data || []), { source: 'supabase' });
    }
  };
})();
