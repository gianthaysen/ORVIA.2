/* ============================================================
   ORVIA — User Profile + Onboarding  (Phase 2)
   Individualisierbares Datenmodell, entkoppelt von einer Person.
   Speicher: localStorage 'orvia_profile_v1'. Liefert window.PROFILE.
   ============================================================ */
/* B-13: nutzersichtbare Texte ueber t() (locales/de.js, laedt vor dieser Datei). Global, weil profile.js Global-Scope ist;
   der Name T kollidiert mit keinem bestehenden Symbol (geprueft 11.09.). */
function T(k,p){try{var I=window.ORVIA&&ORVIA.i18n;if(I&&typeof I.t==='function')return I.t(k,p);}catch(e){}return String(k);}
var PROFILE_KEY='orvia_profile_v1';
/* Defaults = lauffähiger Startzustand (für Bestandsnutzer), voll editierbar */
/* Neutrale Vorgaben für NEUE Accounts. Bestandsnutzer laden ihr echtes Profil aus der Cloud. */
var PROFILE_DEFAULTS={
  v:1, onboarded:false,
  name:'', location:'', handle:null, bio:null, age:null, birthDate:'', ageEstimate:null, sex:'', timezone:null,
  /* D7 (M7/M5c, 2026-07-03): KEINE plausiblen Körper-Defaults mehr — fehlend = null.
     Bestandswerte werden NICHT rückwirkend genullt (Migrationsregel D7); nur Neuanlage ändert sich. */
  weightKg:null, heightCm:null, hfMax:null, rhrBaseline:null, hfMaxMeasured:null, restingHrMeasured:null, sleepGoalH:null,
  primaryGoal:'health', primaryGoalLabel:'' + T('pf.allgemeine_gesundheit') + '',
  raceName:'', raceDate:'', hmTargetMin:null,
  secondaryGoals:[], avatar:'', goal:null, nutrition:null, gear:[], customExercises:[], weekPlan:null, pauses:[], hideAnkle:false, trainingDays:null, adaptationMode:'assisted', riskTolerance:'balanced', checkinMode:'full', cycle:null, gymDays:null,
  sports:[], level:'fortgeschritten',
  weeklyKm:null, longestRunKm:null,
  typicalRunKm:null, recentRunsPerWeek:null, sessionMinutes:null, fixedEvents:[], planAdjustments:[],
  recoveryFocus:'', nutritionFocus:'',
  issues:[], equipment:[],
  dataSources:['Manuell'], coachingIntensity:'ausgewogen'
};
var PROFILE=null;
function loadProfile(){try{var p=JSON.parse(localStorage.getItem(PROFILE_KEY));if(p&&p.v)return Object.assign({},PROFILE_DEFAULTS,p);}catch(e){}return null;}
function saveProfile(){try{localStorage.setItem(PROFILE_KEY,JSON.stringify(PROFILE));}catch(e){}try{if(window.ORVIA_onSave)window.ORVIA_onSave();}catch(_){/* Cloud-Sync optional */}}
function ensureProfile(){
  var existed=!!localStorage.getItem(PROFILE_KEY);
  PROFILE=loadProfile()||Object.assign({},PROFILE_DEFAULTS);
  if(!existed)saveProfile();
  return existed;
}
function escH(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function countDays(){try{return Object.keys(DB).filter(isDay).length;}catch(e){return 0;}}
function dataQualityLabel(n){return n>=21?{l:'stabil',c:'g'}:n>=8?{l:'' + T('pf.brauchbare_trends') + '',c:'g'}:n>=4?{l:'' + T('pf.erste_muster') + '',c:'y'}:{l:'unsicher',c:'r'};}

/* ---- Labels ---- */
var GOAL_LABELS={halfmarathon:'' + T('pf.halbmarathon') + '',marathon:'' + T('pf.marathon') + '',fast5k:'5 km schneller',fast10k:'10 km schneller',half_marathon:'' + T('pf.halbmarathon') + '',run_5k:'5 km schneller',run_10k:'10 km schneller',
  triathlon:'' + T('pf.triathlon') + '',ironman:'Ironman',muscle:'Muskelaufbau',fatloss:'' + T('pf.koerperfett_reduzieren') + '',health:'' + T('pf.allgemeine_gesundheit') + '',
  recovery:'' + T('pf.bessere_regeneration') + '',back:'' + T('pf.ruecken_stabilisieren') + '',painfree:'' + T('pf.schmerzfrei_trainieren') + '',comeback:'' + T('pf.wiedereinstieg') + '',
  stress:'Stressmanagement',sleep:'' + T('pf.schlaf_verbessern') + ''};
var ISSUE_LABELS={knee:'Knie',back:'Rücken',shoulder:'Schulter',hip:'Hüfte',ankle:'Sprunggelenk',shin:'Schienbein',
  foot:'Fuß',neck:'Nacken',elbow:'Ellenbogen',wrist:'Handgelenk',fatigue:'Müdigkeit',stress:'Stress',sleep:'Schlafprobleme'};
var COACH_LABELS={sanft:'Sanft',ausgewogen:'Ausgewogen',praezise:'' + T('pf.praezise_direkt') + '',daten:'' + T('pf.maximal_datengetrieben') + ''};
var LEVEL_LABELS={anfaenger:'' + T('pf.anfaenger') + '',wiedereinstieg:'' + T('pf.wiedereinstieg') + '',fortgeschritten:'' + T('pf.fortgeschritten') + '',leistung:'Leistungsorientiert',profi:'Profi'};

/* ============ PROFILSEITE RENDERN ============ */
/* ===== Equipment: km-Tracking, Aktivitäts-Zuordnung, Inspektions-Warnung =====
   P6: EIN kanonisches Modell — devices.equipment (mit wear{limitKm,startKm,since}).
   Legacy PROFILE.gear wird beim ersten Zugriff idempotent dorthin migriert
   (IDs bleiben — die km-Zuordnung sessions[..].gearId funktioniert unverändert);
   gear selbst bleibt als Altbestand liegen (Datenerhalt), wird aber nicht mehr gelesen. */
function _eqIsBike(t){return ['bike','road_bike','gravel_bike','mtb'].indexOf(t)>=0;}
function _eqEnsureMigrated(){try{var M=pmModel();
  if(M&&typeof M.migrateGearToEquipment==='function'&&M.migrateGearToEquipment(PROFILE)){_profileSave(['devices']);}}catch(e){}}
function _wearItems(){try{var d=PROFILE&&PROFILE.devices;var eq=(d&&Array.isArray(d.equipment))?d.equipment:[];
  return eq.filter(function(e){return e&&e.wear;});}catch(e){return [];}}
function gearKm(g){
  var wear=g.wear||{limitKm:g.limitKm,startKm:g.startKm,since:g.since};
  var key=_eqIsBike(g.type)?'' + T('pf.rad') + '':'Laufen';
  var sameType=_wearItems().filter(function(x){return _eqIsBike(x.type)===_eqIsBike(g.type);});
  var sole=sameType.length<=1;
  var sum=wear.startKm||0;
  try{Object.keys(DB).filter(isDay).forEach(function(k){var s=DB[k].sessions;if(!s||!s[key]||!s[key].dist)return;
    var gid=s[key].gearId;
    if(gid&&gid===g.id)sum+=s[key].dist;
    else if(!gid&&sole){if(!wear.since||k>=wear.since)sum+=s[key].dist;}
  });}catch(e){}
  return Math.round(sum);
}
/* Phase 3 · Block 2 (2026-08-05): Inhalt als Funktion extrahiert — dieselbe
   Verschleiss-Darstellung speist jetzt AUCH das GM-Sheet (gmOpenEquipmentSheet,
   Einstieg: Profil → Geräte & Daten). EINE Quelle, kein Doppelweg. */
function equipmentHTML(){
  _eqEnsureMigrated();
  var items=_wearItems();
  var rows=items.map(function(g){
    var km=gearKm(g),icn=_eqIsBike(g.type)?'bike':'run';var limit=g.wear&&g.wear.limitKm;
    var head='<div class="eq-top"><span class="eq-n"><svg class="ic"><use href="#i-'+icn+'"/></svg>'+escH(g.label||g.type)+'</span><button class="eq-x" onclick="delGear(\''+escH(g.id)+'\')" aria-label="' + T('pf.entfernen') + '">✕</button></div>';
    if(limit){
      var pct=Math.min(100,Math.round(km/limit*100));var c=pct>=90?'r':pct>=75?'y':'g';
      var warn=pct>=100?'<div class="eq-warn eq-warn-r">' + T('pf.wechsel_ueberfaellig_sep') + ''+km+' / '+limit+' km</div>':(pct>=90?'<div class="eq-warn eq-warn-y">' + T('pf.bald_wechsel_inspektion_faellig') + '</div>':'');
      return '<div class="eq">'+head+'<div class="eq-meta"><span class="eq-km">'+km+' / '+limit+' km</span><span class="eq-pct">'+pct+'%</span></div>'+
        '<div class="goalbar"><i class="eqbar eqbar-'+c+'" style="width:'+pct+'%"></i></div>'+warn+'</div>';
    }
    return '<div class="eq">'+head+'<div class="eq-meta"><span class="eq-km eq-counter">'+km+' km</span><span class="eq-pct">' + T('pf.zaehler') + '</span></div></div>';
  }).join('');
  return (rows||'<p class="muted" style="margin:0 0 8px">' + T('pf.noch_kein_equipment_lege_schuhe') + '</p>')+
    '<button class="btn sec" style="margin-top:10px" onclick="addGearPrompt()">' + T('pf.equipment_hinzufuegen') + '</button>';
}
function renderEquipment(){
  var el=document.getElementById('equipmentBox');if(el)el.innerHTML=equipmentHTML();
  /* Sheet-Ansicht (falls offen) mitziehen — gleiche Quelle. */
  try{if(typeof gmRefreshEquipmentSheet==='function')gmRefreshEquipmentSheet();}catch(e){}
}
function addGearPrompt(){
  var wrap=document.createElement('div');wrap.className='orvia-modal-bg';
  wrap.innerHTML='<div class="orvia-modal goal-modal"><h3>' + T('pf.equipment_hinzufuegen_') + '</h3>'+
    '<div class="gm-field"><label>' + T('pf.name') + '</label><input id="gear_n" type="text" placeholder="' + T('pf.z_b_nike_vomero_18') + '"></div>'+
    '<div class="gm-field"><label>' + T('pf.typ') + '</label><div class="gm-chips" id="gear_t"><button type="button" class="gm-chip on" data-v="shoe" onclick="gearTypePick(this)">' + T('pf.schuhe') + '</button><button type="button" class="gm-chip" data-v="bike" onclick="gearTypePick(this)">' + T('pf.rad') + '</button></div></div>'+
    '<div class="gm-field"><label>' + T('pf.bereits_gelaufen_gefahren_km_optional') + '</label><input id="gear_s" type="number" inputmode="numeric" placeholder="0"></div>'+
    '<div class="gm-field"><label>' + T('pf.wechsel_limit_km_leer_nur') + '</label><input id="gear_l" type="number" inputmode="numeric" placeholder="' + T('pf.800') + '"></div>'+
    '<button class="btn" onclick="saveGear()">' + T('pf.hinzufuegen') + '</button>'+
    '<button class="btn sec" style="margin-top:10px" onclick="closeGear()">' + T('pf.abbrechen') + '</button></div>';
  document.body.appendChild(wrap);window._gearModal=wrap;wrap.addEventListener('click',function(ev){if(ev.target===wrap)closeGear();});
}
function gearTypePick(btn){gmPick(btn,'gear_t');var l=document.getElementById('gear_l');if(l&&!l.value)l.placeholder=(btn.dataset.v==='bike'?'' + T('pf.leer_zaehler') + '':'' + T('pf.800') + '');}
function closeGear(){if(window._gearModal){try{window._gearModal.remove();}catch(e){}window._gearModal=null;}}
function saveGear(){
  if(!PROFILE&&typeof ensureProfile==='function')ensureProfile();
  var nEl=document.getElementById('gear_n');var n=(nEl?nEl.value:'').trim();if(!n){if(typeof toast==='function')toast('' + T('pf.name_fehlt') + '');return;}
  var td=(document.querySelector('#gear_t .on')||{}).dataset;var t=td?td.v:'shoe';
  var sk=parseFloat(((document.getElementById('gear_s')||{}).value||'').replace(',','.'));if(isNaN(sk)||sk<0)sk=0;
  var l=parseInt(((document.getElementById('gear_l')||{}).value),10);if(isNaN(l)||l<=0)l=null;
  // P6: direkt kanonisch anlegen (devices.equipment mit wear) — kein neues gear[] mehr.
  var M=pmModel();PROFILE.devices=(PROFILE.devices&&typeof PROFILE.devices==='object')?PROFILE.devices:{};
  if(!Array.isArray(PROFILE.devices.equipment))PROFILE.devices.equipment=[];
  PROFILE.devices.equipment.push(M.normalizeEquipment({type:t==='bike'?'road_bike':'running_shoes',label:n,available:true,
    wear:{limitKm:l,startKm:sk,since:(typeof todayStr==='function'?todayStr():'')}}));
  _profileSave(['devices']);closeGear();renderEquipment();if(typeof toast==='function')toast('' + T('pf.equipment_hinzugefuegt') + '');
}
function delGear(id){if(!PROFILE)return;var d=PROFILE.devices;
  if(d&&Array.isArray(d.equipment))d.equipment=d.equipment.filter(function(e){return e.id!==id;});
  if(Array.isArray(PROFILE.gear))PROFILE.gear=PROFILE.gear.filter(function(g){return g.id!==id;});   // Altbestand konsistent halten
  _profileSave(['devices']);renderEquipment();}
function gearName(id){if(!id||!PROFILE)return null;
  var d=PROFILE.devices;var e=(d&&Array.isArray(d.equipment))?d.equipment.filter(function(x){return x.id===id;})[0]:null;
  if(e)return e.label||e.type;
  var g=Array.isArray(PROFILE.gear)?PROFILE.gear.filter(function(x){return x.id===id;})[0]:null;return g?g.name:null;}
function changeProfilePhoto(){
  if(!PROFILE&&typeof ensureProfile==='function')ensureProfile();
  var inp=document.createElement('input');inp.type='file';inp.accept='image/*';
  inp.onchange=function(){var f=inp.files&&inp.files[0];if(!f)return;
    var r=new FileReader();r.onload=function(e){var img=new Image();img.onload=function(){
      var src=Math.min(img.width,img.height),side=Math.min(src,240),sx=(img.width-src)/2,sy=(img.height-src)/2;
      var cv=document.createElement('canvas');cv.width=side;cv.height=side;cv.getContext('2d').drawImage(img,sx,sy,src,src,0,0,side,side);
      try{PROFILE.avatar=cv.toDataURL('image/jpeg',0.82);}catch(_){if(typeof toast==='function')toast('' + T('pf.foto_konnte_nicht_verarbeitet_werden') + '');return;}
      if(typeof saveProfile==='function')saveProfile();
      if(typeof renderProfileScreen==='function')renderProfileScreen();
      if(typeof renderTopAvatar==='function')renderTopAvatar();
      /* 0016: Server-SoT — Bild nach Supabase Storage hochladen (avatars/{userId}/profile.jpg);
         Base64 bleibt nur lokale Sofort-Vorschau. Erfolg/Fehler ehrlich melden. */
      if(window.ORVIA&&ORVIA.avatarStore&&ORVIA.user){
        ORVIA.avatarStore.upload(PROFILE.avatar).then(function(r){
          if(typeof toast!=='function')return;
          if(r.success)toast('' + T('pf.foto_aktualisiert_synchronisiert') + '');
          else if(r.sync_status==='pending')toast('' + T('pf.foto_lokal_aktualisiert_upload_folgt') + '');
          else toast('' + T('pf.foto_lokal_aktualisiert_cloud_upload') + '');
        });
      }else if(typeof toast==='function')toast('' + T('pf.foto_aktualisiert') + '');
    };img.src=e.target.result;};r.readAsDataURL(f);};
  inp.click();
}
function renderProfileScreen(){
  if(!PROFILE)ensureProfile();
  var p=PROFILE,el=document.getElementById('profileCard');if(!el)return;
  var initial=((p.name||'O').trim()[0]||'O').toUpperCase();
  var sub=[p.location,p.age?p.age+'' + T('pf.jahre') + '':'',p.weightKg?p.weightKg+' kg':'',p.hfMax?'' + T('pf.hfmax') + ''+p.hfMax:''].filter(Boolean).join(' · ');
  ensureProfileGoals();
  /* 0016: Server-SoT zuerst (signierte Storage-URL), Base64 nur lokale Vorschau/Offline. */
  var _avSrc=(window.ORVIA&&ORVIA.avatarStore&&ORVIA.avatarStore.currentSrc)?ORVIA.avatarStore.currentSrc():(p.avatar||null);
  var ava=_avSrc?'<img src="'+escH(_avSrc)+'" alt="">':escH(initial);
  el.innerHTML='<div class="profhead"><div class="avatar" onclick="changeProfilePhoto()" title="' + T('pf.foto_aendern') + '">'+ava+'</div>'+
    '<div class="profmeta"><div class="profname">'+escH(p.name||'Athlet')+'</div><div class="profsub">'+escH(sub)+'</div></div>'+
    '<button class="editbtn" onclick="ORVIA.openProfileEditor()" aria-label="' + T('pf.profil_bearbeiten') + '"><svg class="ic"><use href="#i-gear"/></svg></button></div>'+
    goalsSummaryHTML()+
    /* M10: Die neue Profilzentrale ist der primäre Einstieg (fail-soft: klassischer Manager,
       falls das Modul fehlt). Alte Editoren bleiben über die Zentrale erreichbar. */
    '<button class="btn" style="margin-top:10px" onclick="openProfileCenterEntry()">' + T('pf.profil_oeffnen') + '</button>'+
    '<button class="btn sec" style="margin-top:8px" onclick="openGoalsManager()">' + T('pf.ziele_verwalten') + '</button>';
  var pi=document.getElementById('perfIdentity');if(pi)pi.innerHTML=identityRows(p);
  renderZones();
}
/* ============================================================
   Mehrziel-Adapter: PROFILE ↔ profile-model (goals[] authoritative, Legacy-Projektion kompatibel).
   ============================================================ */
function gmToggle(btn){btn.classList.toggle('on');}   // Multi-Select-Chip (Sportarten/Fokus)
/* ORVIA-Segment-Control: ersetzt native <select> (kein weißes Browser-Element).
   pairs=[[value,label],...]; Wert liegt auf dem Container (data-val). Einzelauswahl. */
function segHTML(id,pairs,cur,cb){var extra=cb?(';'+cb+'()'):'';return '<div class="seg-ctl" id="'+id+'" data-val="'+escH(cur!=null?cur:'')+'">'+
  pairs.map(function(p){return '<button type="button" class="seg-b'+(String(cur)===String(p[0])?' on':'')+'" data-v="'+escH(p[0])+'" onclick="segPick(this)'+extra+'">'+escH(p[1])+'</button>';}).join('')+'</div>';}
function segGroupedHTML(id,groups,cur){return '<div class="seg-ctl seg-grouped" id="'+id+'" data-val="'+escH(cur!=null?cur:'')+'">'+
  groups.map(function(g){return '<div class="seg-group">'+escH(g[0])+'</div>'+g[1].map(function(p){return '<button type="button" class="seg-b'+(String(cur)===String(p[0])?' on':'')+'" data-v="'+escH(p[0])+'" onclick="segPick(this)">'+escH(p[1])+'</button>';}).join('');}).join('')+'</div>';}
function segPick(btn){var box=btn.parentNode;while(box&&!(box.classList&&box.classList.contains('seg-ctl')))box=box.parentNode;if(!box)return;box.dataset.val=btn.dataset.v;Array.prototype.forEach.call(box.querySelectorAll('.seg-b'),function(b){if(b===btn)b.classList.add('on');else b.classList.remove('on');});}
function _segVal(id){var e=document.getElementById(id);return e?(e.dataset?e.dataset.val:e.getAttribute('data-val')):null;}
function pmModel(){return window.ORVIA&&ORVIA.profileModel;}
function ensureProfileGoals(){var M=pmModel();if(!M||!PROFILE)return;
  if(!Array.isArray(PROFILE.goals)){var mig=M.migrateProfile(PROFILE);PROFILE.goals=mig.goals;PROFILE.profileVersion=2;}
  else PROFILE.goals=M.normalizeGoals(PROFILE.goals);
  applyLegacyProjection();}
function applyLegacyProjection(){var M=pmModel();if(!M||!PROFILE)return;var pr=M.buildLegacyProjection(PROFILE);
  PROFILE.primaryGoal=pr.primaryGoal;PROFILE.primaryGoalLabel=pr.primaryGoalLabel;PROFILE.secondaryGoals=pr.secondaryGoals;
  if(pr.raceDate)PROFILE.raceDate=pr.raceDate;if(pr.hmTargetMin!=null)PROFILE.hmTargetMin=pr.hmTargetMin;}
function listGoals(){ensureProfileGoals();return PROFILE.goals||[];}
/* ZENTRALER Profil-Speichervorgang (Inkrement 4b): aktualisiert Legacy-Projektionen (Ziele→primaryGoal…
   und Beschwerden→issues[]) IMMER zentral, speichert atomar offline-first (bestehender Cloud-Hook via
   saveProfile→ORVIA_onSave bleibt erhalten) und löst genau EIN orvia:profile-updated-Event aus. */
function _profileSave(changedSections,source){var M=pmModel();
  if(M&&PROFILE){applyLegacyProjection();
    if(Array.isArray(PROFILE.constraintsList))PROFILE.issues=M.constraintIssueKeys(PROFILE);
    /* M1b (ADR D2/D6): Section-Metadaten zentral pflegen. Default-Quelle 'editor'
       (Onboarding-Quelle wird erst mit dem neuen Setup gesetzt — nicht vortäuschen).
       Phase 5 (Garmin, 2026-07-17): optionaler zweiter Parameter `source` — Aufrufer,
       die einen aufgelösten Provider-Wert schreiben (ProfileMetricResolver), reichen
       'provider_sync' explizit durch. ALLE bestehenden Aufrufer (1 Argument) bleiben
       unverändert und erhalten weiterhin 'editor' — rein additiv, keine Verhaltensänderung
       für bestehende Call-Sites. Setzt NUR updatedAt/source, markiert nichts als vollständig. */
    try{if(typeof M.touchSectionMeta==='function')M.touchSectionMeta(PROFILE,changedSections||[],source||'editor');}catch(e){}}
  /* P1: Alter bei personal-Änderungen sofort neu ableiten — vorher nur bei
     Onboarding-Abschluss und Cloud-Hydration berechnet (stale Profilkarte). */
  if((changedSections||[]).indexOf('personal')>=0){
    try{if(window.ORVIA&&ORVIA.profileStore&&typeof ORVIA.profileStore.computeAge==='function')PROFILE.age=ORVIA.profileStore.computeAge(PROFILE.birthDate,PROFILE.ageEstimate);}catch(e){}}
  PROFILE.updatedAt=new Date().toISOString();
  /* A0-Fix (2026-07-03): IMMER saveProfile() — das globale save() aus data.js persistiert NUR die
     Checkin-DB (gian_checkins_v2), nie PROFILE. Der alte Zweig `typeof save==='function'?save():…`
     ließ orvia_profile_v1 in der App (save immer definiert) STALE; Cloud-Snapshot las den alten Blob.
     Regression: supabase/tests/profile_save_wiring_a0_test.mjs. */
  saveProfile();
  try{if(typeof window!=='undefined'&&window.dispatchEvent)window.dispatchEvent(new CustomEvent('orvia:profile-updated',{detail:{changedSections:changedSections||[],updatedAt:PROFILE.updatedAt}}));}catch(e){}}
// Persistiert goals[] atomar + Legacy-Projektion + Event. Plan-Impact separat über maybePlanImpact.
function commitGoals(ng,_ereignis){PROFILE.goals=ng;_profileSave(['goals']);
  /* A-06 (2026-08-18): Zielereignis mitschreiben — BEOBACHTER, nie Beteiligter.
     Steht bewusst NACH _profileSave: das Ziel ist gespeichert, bevor der
     Beobachter ueberhaupt laeuft. logGoalEvent wirft nie; das try/catch ist die
     zweite Sicherung, keine Entschuldigung fuer die erste. */
  try{_goalShadowNote(_ereignis||'update');}catch(e){}
  try{renderProfileScreen();}catch(e){} try{if(window._goalsMgr)renderGoalsList();}catch(e){}}

/* ═══ A-06 · Ziel-Shadow-Log ═══════════════════════════════════════════════
   WOFUER: Band 1, A-06. Vor der Umstellung der Planlogik in B-01 soll ueber
   mindestens 14 Tage belegt sein, wie oft `mainGoalOf()` (kanonisches Hauptziel)
   und `goalOf()` (Bestand, filtert auf Laufdistanzziele) auseinanderlaufen.
   Gate A, Kriterium 4.

   KEINE VERHALTENSAENDERUNG: gelesen wird nur, was die App ohnehin liest;
   geschrieben wird ausschliesslich in eine Tabelle, die niemand liest. Faellt
   das Modul aus, fehlt ein Log-Eintrag — sonst nichts. */
function _goalShadowNote(ereignis){
  var O=window.ORVIA; if(!O||!O.goalShadow)return;
  _goalShadowEnsureSink();
  var haupt=null,bestand=null,aktiv=0;
  try{ if(typeof mainGoalOf==='function')haupt=mainGoalOf(); }catch(e){}
  try{ if(typeof goalOf==='function')bestand=goalOf(); }catch(e){}
  try{ aktiv=(listGoals()||[]).filter(function(g){return g&&g.status==='active';}).length; }catch(e){}
  var ver=null;
  try{ var m=document.querySelector('meta[name="orvia-build"]'); ver=m?m.content:null; }catch(e){}
  O.goalShadow.logGoalEvent({
    eventType:ereignis, eventId:_goalShadowId(), now:new Date().toISOString(),
    mainGoal:haupt, legacyGoal:bestand, activeGoalCount:aktiv, appVersion:ver,
    gcat:(typeof gcat==='function')?gcat:null
  });
}
/* A-06 Nachtrag (12.09.2026): Laufzeit-Beleg. Einmal je Geraet und Kalendertag nach
   orvia:auth-ready (Profil und Ziele sind dann hydriert) ein 'session'-Ereignis — abseits
   des kritischen Login-Pfads (setTimeout). Ohne Migration 0043 lehnt der CHECK die Zeile
   ab: das ist ein gezaehlter Schreibfehler, kein Verhalten. */
function _goalShadowSession(){
  try{
    var k='orvia_gs_session_day',today=new Date().toISOString().slice(0,10);
    if(localStorage.getItem(k)===today)return false;
    localStorage.setItem(k,today);
    _goalShadowNote('session');
    return true;
  }catch(e){return false;}
}
try{window.addEventListener('orvia:auth-ready',function(){setTimeout(_goalShadowSession,1500);});}catch(e){}
function _goalShadowId(){
  try{ if(window.crypto&&crypto.randomUUID)return 'gs_'+crypto.randomUUID(); }catch(e){}
  return 'gs_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,10);
}
/* Senke: schreibt in goal_shadow_log (Migration 0037). Liefert bewusst `null`,
   wenn es keine Sitzung gibt — das ist KEIN Schreibfehler, sondern kein
   Schreibversuch. Sonst waere die Fehlerzahl aus Gate A, Kriterium 4 wertlos. */
/* Wird beim ERSTEN Zielereignis gesetzt, nicht beim Laden: profile.js laedt in
   index.html vor js/engine/*, das Modul existiert zu diesem Zeitpunkt also noch
   nicht. Eine Ladereihenfolge als stille Voraussetzung waere genau die Art
   Abhaengigkeit, die beim naechsten Umsortieren unbemerkt bricht. */
var _goalShadowSinkGesetzt=false;
function _goalShadowEnsureSink(){
  var O=window.ORVIA;
  if(_goalShadowSinkGesetzt||!O||!O.goalShadow||!O.goalShadow.setSink)return;
  _goalShadowSinkGesetzt=true;
  O.goalShadow.setSink(function(rec){
    var sb=O.sb, uid=(O.user&&O.user.id)||null;
    if(!sb||!uid)return null;
    var row=O.goalShadow.toRow(rec,uid);
    if(!row)return null;
    return sb.from('goal_shadow_log').insert(row).then(function(r){
      if(r&&r.error)throw new Error(r.error.message||'insert_failed');
      return r;
    });
  });
}
/* Öffentlicher Profil-Adapter: einzige produktive API für neue Oberflächen (lesen/schreiben/abonnieren). */
(function(){var O=(typeof window!=='undefined'?window:globalThis).ORVIA=(typeof window!=='undefined'?window:globalThis).ORVIA||{};
  O.profile={
    load:function(){if(!PROFILE&&typeof ensureProfile==='function')ensureProfile();return PROFILE;},
    get:function(){return PROFILE;},
    save:function(sections,source){_profileSave(sections||[],source);},
    // Phase 5: optionaler 4. Parameter `source` (z.B. 'provider_sync') — Default bleibt 'editor'
    // (via _profileSave), bestehende 3-Argument-Aufrufer unverändert.
    updateSection:function(id,patch,sections,source){if(!PROFILE)return;if(patch&&typeof patch==='object')Object.keys(patch).forEach(function(k){PROFILE[k]=patch[k];});_profileSave(sections||[id],source);},
    subscribe:function(fn){try{window.addEventListener('orvia:profile-updated',fn);}catch(e){}return function(){try{window.removeEventListener('orvia:profile-updated',fn);}catch(e){}};},
    migrate:function(){var M=pmModel();if(M&&PROFILE){var c=M.consolidateProfile(PROFILE);Object.keys(c).forEach(function(k){PROFILE[k]=c[k];});}return PROFILE;},
    buildLegacyProjection:function(){return pmModel().buildLegacyProjection(PROFILE);},
    getFieldUsage:function(p){return pmModel().getFieldUsage(p);},
    buildSummary:function(){return pmModel().buildProfileSummary(PROFILE);},
    activeSports:function(){return pmModel().normalizeSports(PROFILE&&PROFILE.sports).filter(function(s){return s.activeInApp;});},
    planSports:function(){return pmModel().normalizeSports(PROFILE&&PROFILE.sports).filter(function(s){return s.includeInPlan;});},
    sportById:function(id){return pmModel().normalizeSports(PROFILE&&PROFILE.sports).filter(function(s){return s.sportId===id;})[0]||null;},
    // Sportarten für „Training starten"/Schnellaktionen: Hauptsportart zuerst, dann weitere aktive.
    trainingStartSports:function(){return O.profile.activeSports().slice().sort(function(a,b){return (a.role==='primary'?0:1)-(b.role==='primary'?0:1);});},
    manualActivitySports:function(){return O.profile.trainingStartSports();},
    activeConstraints:function(){return pmModel().activeConstraints(PROFILE||{});},
    // Bestandsnutzer (Daten/abgeschlossen) → kein Pflicht-Onboarding.
    needsOnboarding:function(){if(!PROFILE&&typeof ensureProfile==='function')ensureProfile();return !pmModel().isOnboardingComplete(PROFILE||{});},
    markOnboardingComplete:function(){if(!PROFILE)return;PROFILE.onboarding=pmModel().normalizeOnboarding(Object.assign({},PROFILE.onboarding,{status:'completed',completedAt:new Date().toISOString()}),PROFILE);_profileSave(['onboarding']);}
  };})();
function goalAdd(input,reason){commitGoals(pmModel().addGoal(listGoals(),input),'add');}
function goalUpdate(id,patch,reason){commitGoals(pmModel().updateGoal(listGoals(),id,patch),'update');}
function goalRemove(id){commitGoals(pmModel().removeGoal(listGoals(),id),'remove');}
function goalSetStatus(id,st){commitGoals(pmModel().setGoalStatus(listGoals(),id,st),'status');}
/* ---- Profil-Zusammenfassung (Rollen, keine IDs/Kategorien) ---- */
var GOAL_ROLE_DE={main:'Hauptziel',secondary:'' + T('pf.sekundaeres_ziel') + '',maintain:'Erhaltungsziel',longterm:'Langfristig'};
function goalsSummaryHTML(){var M=pmModel();if(!M)return '';var act=listGoals().filter(function(g){return g.status==='active';}).slice().sort(function(a,b){return a.priority-b.priority;});
  if(!act.length)return '<p class="note" style="text-align:left;margin-top:8px">' + T('pf.noch_keine_ziele_lege_dein') + '</p>';
  return '<div class="goalchips">'+act.slice(0,4).map(function(g){return '<span class="goalchip">'+escH((GOAL_ROLE_DE[M.roleOfGoal(g)]||'Ziel')+': '+g.title)+'</span>';}).join('')+'</div>';}
function goalChip(p){
  var lbl=p.primaryGoalLabel||GOAL_LABELS[p.primaryGoal]||'Ziel';
  if((p.primaryGoal==='halfmarathon'||p.primaryGoal==='half_marathon')&&p.hmTargetMin)lbl='HM <'+fmtH(p.hmTargetMin)+(p.raceDate?' · '+shortDate(p.raceDate):'');
  return lbl;
}
function fmtH(min){var h=Math.floor(min/60),m=min%60;return h+':'+String(m).padStart(2,'0');}
function shortDate(s){try{return new Date(s+'T12:00').toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',year:'2-digit'});}catch(e){return s;}}
function identityRows(p){
  var n=countDays(),dq=dataQualityLabel(n);
  var modules=(p.issues||[]).filter(function(k){return k!=='none';}).map(function(k){return ISSUE_LABELS[k]||k;});
  var rows=[
    ['' + T('pf.current_focus') + '',p.primaryGoalLabel||GOAL_LABELS[p.primaryGoal]||'—'],
    ['' + T('pf.long_term_direction') + '',(p.secondaryGoals&&p.secondaryGoals.length)?p.secondaryGoals[p.secondaryGoals.length-1]:'—'],
    ['' + T('pf.training_style') + '',COACH_LABELS[p.coachingIntensity]||'—'],
    ['Level',LEVEL_LABELS[p.level]||'—'],
    ['' + T('pf.active_modules') + '',modules.length?modules.join(', '):'keine'],
    ['' + T('pf.data_quality') + '','<span class="dq dq-'+dq.c+'">'+n+'' + T('pf.tage') + ''+dq.l+'</span>'],
    ['' + T('pf.connected_sources') + '',(p.dataSources||[]).join(', ')||'—']
  ];
  return rows.map(function(r){return '<div class="idrow"><span class="idk">'+escH(r[0])+'</span><span class="idv">'+r[1]+'</span></div>';}).join('');
}
function renderZones(){
  var el=document.getElementById('zoneList');if(!el)return;
  /* Phase 4 (E-02 · Quellenprioritätsvertrag): Auflösung + Kennzeichnung ZENTRAL über
     ORVIA.sourceContract — gemessene HFmax und Tanaka-Schätzwert erscheinen nie unter
     derselben Kennzeichnung. Fehlen beide → keine Zonen, neutraler Hinweis. KEIN 190/201. */
  var _res=null;
  try{if(window.ORVIA&&ORVIA.sourceContract)_res=ORVIA.sourceContract.hfMax(PROFILE);}catch(_){ }
  if(!_res){/* Fallback ohne Modul (alte Logik, unveraendert) */
    var _age=(PROFILE&&PROFILE.age)||null;
    var measured=(PROFILE&&PROFILE.hfMaxMeasured!=null)?PROFILE.hfMaxMeasured:null;
    var calculated=_age?Math.round(208-0.7*_age):null;
    var mv=measured||calculated;
    _res=mv?{value:mv,source:measured!=null?'profile_manual':'derived_estimate',confidence:measured!=null?'user_provided':'estimated'}:null;
  }
  if(!_res){
    el.innerHTML='<div class="zone-empty">' + T('pf.fuer_herzfrequenzzonen_fehlen_alter_oder') + '</div>';
    var he=document.getElementById('zoneTitle');if(he)he.textContent='' + T('pf.hr_zonen_noch_nicht_verfuegbar') + '';
    return;
  }
  var max=_res.value;
  var z=[['' + T('pf.z1_recovery') + '',.51,.61,'#e7cf9a','rgba(216,183,119,.35)'],['' + T('pf.z2_easy') + '',.61,.72,'#4ade80','rgba(52,211,153,.35)'],
    ['' + T('pf.z3_tempo') + '',.72,.82,'#fbbf24','rgba(251,191,36,.35)'],['' + T('pf.z4_threshold') + '',.82,.92,'#fb923c','rgba(251,146,60,.4)'],
    ['' + T('pf.z5_max') + '',.92,1,'#fb7185','rgba(251,77,109,.4)']];
  var srcLbl=(window.ORVIA&&ORVIA.sourceContract&&ORVIA.sourceContract.LABEL[_res.source])||_res.source;
  var srcNote=(_res.source==='derived_estimate')
    ?'' + T('pf.hfmax') + ''+max+'' + T('pf.quelle_berechnet_tanaka_208_0') + ''
    :'' + T('pf.hfmax') + ''+max+'' + T('pf.quelle') + ''+srcLbl+'.';
  el.innerHTML=z.map(function(x){return '<div class="zone" style="border-color:'+x[4]+';color:'+x[3]+'">'+x[0]+'<span>'+Math.round(x[1]*max)+'–'+Math.round(x[2]*max)+'</span></div>';}).join('')+
    '<p class="note" style="text-align:left;margin-top:8px">'+escH(srcNote)+'</p>';
  /* E-02: drei getrennte Kennzeichnungen — Messung (Geraet) ≠ Profilwert (manuell) ≠ Schaetzung. */
  var _tit=(_res.source==='derived_estimate')?' (berechnet)':(_res.source==='profile_manual')?'' + T('pf.profil') + '':' (gemessen)';
  var h=document.getElementById('zoneTitle');if(h)h.textContent='' + T('pf.hr_zonen_max') + ''+max+_tit;
}

/* ============ ONBOARDING ============ */
var OB_STEPS=[
  {t:'welcome'},
  {t:'choice',key:'primaryGoal',title:'' + T('pf.was_ist_dein_hauptziel') + '',sub:'' + T('pf.steuert_empfehlungen_forecast_und_plan') + '',
   opts:[['halfmarathon','' + T('pf.halbmarathon') + ''],['marathon','' + T('pf.marathon') + ''],['fast5k','5 km schneller'],['fast10k','10 km schneller'],
    ['triathlon','' + T('pf.triathlon') + ''],['ironman','Ironman'],['muscle','Muskelaufbau'],['fatloss','' + T('pf.koerperfett_reduzieren') + ''],
    ['health','' + T('pf.allgemeine_gesundheit') + ''],['recovery','' + T('pf.bessere_regeneration') + ''],['back','' + T('pf.ruecken_stabilisieren') + ''],
    ['painfree','' + T('pf.schmerzfrei_trainieren') + ''],['comeback','' + T('pf.wiedereinstieg') + ''],['stress','Stressmanagement'],['sleep','' + T('pf.schlaf_verbessern') + '']]},
  {t:'goals',title:'' + T('pf.weitere_ziele') + '',sub:'' + T('pf.optional_beliebig_viele_z_b') + ''},
  {t:'multi',key:'sports',title:'' + T('pf.welche_sportarten_machst_du') + '',
   opts:[['Laufen'],['' + T('pf.rad') + ''],['Schwimmen'],['Gym'],['Mobilität'],['Yoga'],['Wandern']]},
  {t:'choice',key:'level',title:'' + T('pf.dein_aktuelles_niveau') + '',
   opts:[['anfaenger','' + T('pf.anfaenger') + ''],['fortgeschritten','' + T('pf.fortgeschritten') + ''],['profi','Profi']]},
  {t:'choice',key:'trainingDays',title:'' + T('pf.wie_viele_tage_pro_woche') + '',sub:'' + T('pf.das_ist_die_gesamtzahl_der') + '',
   opts:[['2','' + T('pf.2_tage') + ''],['3','' + T('pf.3_tage') + ''],['4','' + T('pf.4_tage') + ''],['5','' + T('pf.5_tage') + ''],['6','' + T('pf.6_tage') + '']]},
  {t:'choice',key:'gymDays',title:'' + T('pf.wie_viele_davon_im_gym') + '',sub:'' + T('pf.teilmenge_deiner_trainingstage_keine_zusaetzlichen') + '',
   opts:[['0','0'],['1','1'],['2','2'],['3','3'],['4','4']]},
  {t:'choice',key:'sessionMinutes',title:'' + T('pf.wie_viel_zeit_hast_du') + '',
   opts:[['30','~30 min'],['45','~45 min'],['60','~60 min'],['90','90 min+']]},
  {t:'choice',key:'riskTolerance',title:'' + T('pf.wie_willst_du_starten') + '',sub:'' + T('pf.steuert_wie_schnell_orvia_umfang') + '',
   opts:[['konservativ','Konservativ'],['ausgewogen','Ausgewogen'],['ambitioniert','Ambitioniert']]},
  {t:'fields',title:'' + T('pf.lauf_erfahrung_optional') + '',sub:'' + T('pf.hilft_orvia_einen_realistischen_startumfang') + '',
   fields:[['typicalRunKm','' + T('pf.wie_weit_laeufst_du_aktuell') + '','number'],
    ['recentRunsPerWeek','' + T('pf.laeufe_pro_woche_in_den') + '','number'],
    ['longestRunKm','' + T('pf.laengster_lauf_bisher_km') + '','number']]},
  {t:'fields',title:'' + T('pf.koerper_basisdaten') + '',sub:'' + T('pf.basis_fuer_zonen_baselines_und') + '',
   fields:[['name','' + T('pf.name') + '','text'],['location','Ort','text'],['birthDate','' + T('pf.geburtsdatum') + '','date'],
    ['age','' + T('pf.alter_falls_kein_geburtsdatum') + '','number'],['weightKg','' + T('pf.gewicht_kg') + '','number'],
    ['heightCm','' + T('pf.groesse_cm') + '','number'],['hfMax','' + T('pf.hfmax_gemessen_optional') + '','number'],['rhrBaseline','' + T('pf.ruhepuls_gemessen_optional') + '','number'],
    ['sleepGoalH','' + T('pf.schlafziel_h') + '','number']]},
  {t:'choice',key:'sex',title:'' + T('pf.biologische_berechnungsgrundlage') + '',sub:'' + T('pf.nur_fuer_grundumsatz_energiebedarf_trainingsentscheidungen') + '',
   opts:[['m','' + T('pf.maennlich') + ''],['f','' + T('pf.weiblich') + ''],['d','' + T('pf.divers_keine_angabe') + '']]},
  {t:'photo',title:'Profilfoto',sub:'' + T('pf.optional_tippe_auf_den_kreis') + ''},
  {t:'multi',key:'issues',title:'' + T('pf.aktuelle_beschwerden_risikobereiche') + '',sub:'' + T('pf.aktiviert_passende_module_routinen_keine') + '',
   opts:[['knee','Knie'],['back','Rücken'],['shoulder','Schulter'],['hip','Hüfte'],['ankle','Sprunggelenk'],['shin','Schienbein'],
    ['foot','Fuß'],['neck','Nacken'],['fatigue','Müdigkeit'],['stress','Stress'],['sleep','Schlafprobleme'],['none','Keine']]},
  {t:'multi',key:'equipment',title:'' + T('pf.verfuegbare_geraete_hilfsmittel') + '',
   opts:[['Garmin/Wearable'],['' + T('pf.indoor_bike') + ''],['Laufband'],['Pulsgurt'],['Mini-Band'],['' + T('pf.foam_roller') + ''],['Massageball'],['Keine']]},
  {t:'multi',key:'dataSources',title:'' + T('pf.welche_datenquellen_nutzt_du') + '',
   opts:[['' + T('pf.apple_health') + ''],['Garmin'],['Strava'],['CSV'],['Manuell']]},
  {t:'choice',key:'coachingIntensity',title:'' + T('pf.gewuenschter_coaching_stil') + '',
   opts:[['sanft','Sanft'],['ausgewogen','Ausgewogen'],['praezise','' + T('pf.praezise_direkt') + ''],['daten','' + T('pf.maximal_datengetrieben') + '']]},
  {t:'done'}
];
var OB={},OB_I=0,OB_FRESH=false;
function norm(o){return o.length===1?[o[0],o[0]]:o;}
function openOnboarding(fresh){
  OB_FRESH=!!fresh;
  OB=fresh?{issues:[],sports:[],equipment:[],dataSources:[],secondaryGoals:[],avatar:''}:JSON.parse(JSON.stringify(PROFILE||PROFILE_DEFAULTS));
  OB_I=0;renderOB();
}
function closeOnboarding(){var el=document.getElementById('onboarding');if(el)el.classList.remove('show');}
function obNext(){if(OB_I<OB_STEPS.length-1){obSyncFields();OB_I++;renderOB();}}
function obBack(){if(OB_I>0){obSyncFields();OB_I--;renderOB();}}
function obPickChoice(key,val){OB[key]=val;renderOB();}
function obToggleMulti(key,val){
  var a=OB[key]||[];
  if(val==='none'||val==='Keine'){OB[key]=(a.indexOf(val)>=0)?[]:[val];renderOB();return;}
  a=a.filter(function(x){return x!=='none'&&x!=='Keine';});
  var i=a.indexOf(val);if(i>=0)a.splice(i,1);else a.push(val);OB[key]=a;renderOB();
}
function obSyncFields(){var s=OB_STEPS[OB_I];if(s.t!=='fields')return;
  s.fields.forEach(function(f){var inp=document.getElementById('ob_'+f[0]);if(!inp)return;
    OB[f[0]]=f[2]==='number'?(inp.value===''?null:+inp.value):inp.value;});}
function obPickPhoto(input){
  var f=input&&input.files&&input.files[0];if(!f)return;
  if(!/^image\//.test(f.type)){if(typeof toast==='function')toast('' + T('pf.bitte_ein_bild_waehlen') + '');return;}
  var r=new FileReader();
  r.onload=function(e){var img=new Image();img.onload=function(){
    var src=Math.min(img.width,img.height),side=Math.min(src,240),sx=(img.width-src)/2,sy=(img.height-src)/2;
    var cv=document.createElement('canvas');cv.width=side;cv.height=side;
    cv.getContext('2d').drawImage(img,sx,sy,src,src,0,0,side,side);
    try{OB.avatar=cv.toDataURL('image/jpeg',0.82);}catch(_){if(typeof toast==='function')toast('' + T('pf.foto_konnte_nicht_verarbeitet_werden') + '');return;}
    renderOB();
  };img.src=e.target.result;};
  r.readAsDataURL(f);
}
function obRemovePhoto(){OB.avatar='';renderOB();}
function obAddGoal(){var inp=document.getElementById('ob_goalinput');if(!inp)return;var v=(inp.value||'').trim();if(!v)return;OB.secondaryGoals=OB.secondaryGoals||[];OB.secondaryGoals.push(v);renderOB();}
function obRemoveGoal(i){if(OB.secondaryGoals)OB.secondaryGoals.splice(i,1);renderOB();}
function obFinish(){
  obSyncFields();
  if((OB.issues||[]).length===0)OB.issues=['none'];
  OB.issues=OB.issues.filter(function(x){return x!=='none'&&x!=='Keine';});
  OB.primaryGoalLabel=GOAL_LABELS[OB.primaryGoal]||OB.primaryGoalLabel||'Ziel';
  OB.raceName=OB.raceName||OB.primaryGoalLabel;
  // Numerische Choice-Werte von String → Zahl; gymDays als Teilmenge von trainingDays clampen.
  ['trainingDays','gymDays','sessionMinutes'].forEach(function(k){if(OB[k]!=null&&OB[k]!=='')OB[k]=+OB[k];});
  if(OB.trainingDays!=null&&OB.gymDays!=null)OB.gymDays=Math.min(OB.gymDays,OB.trainingDays);
  OB.onboarded=true;OB.v=1;
  var _base=OB_FRESH?Object.assign({},PROFILE_DEFAULTS):Object.assign({},PROFILE_DEFAULTS,PROFILE||{});
  PROFILE=Object.assign({},_base,OB);
  // Phase-1: HFmax/Ruhepuls aus dem Formular sind GEMESSENE Werte (sonst null — keine globale Annahme).
  PROFILE.hfMaxMeasured=(OB.hfMax!=null&&OB.hfMax!=='')?+OB.hfMax:null;
  PROFILE.restingHrMeasured=(OB.rhrBaseline!=null&&OB.rhrBaseline!=='')?+OB.rhrBaseline:null;
  PROFILE.hfMax=PROFILE.hfMaxMeasured;PROFILE.rhrBaseline=PROFILE.restingHrMeasured;
  // birth_date primär, manuelles Alter nur als Schätzung; Alter immer dynamisch.
  PROFILE.birthDate=OB.birthDate||'';
  PROFILE.ageEstimate=(OB.age!=null&&OB.age!=='')?+OB.age:null;
  PROFILE.age=(window.ORVIA&&window.ORVIA.profileStore)?window.ORVIA.profileStore.computeAge(PROFILE.birthDate,PROFILE.ageEstimate):PROFILE.ageEstimate;
  if(PROFILE.goal&&PROFILE.goal.type&&PROFILE.goal.type!==PROFILE.primaryGoal)PROFILE.goal=null;
  try{if(PROFILE.hmTargetMin&&typeof DB!=='undefined'&&DB){DB._hmTargetMin=PROFILE.hmTargetMin;if(typeof _goalCache!=='undefined')_goalCache=null;}}catch(e){}
  saveProfile();closeOnboarding();
  // Phase-1: Mapped-Felder zusätzlich in user_profiles persistieren (online → Repo, offline → Queue).
  try{
    if(window.ORVIA&&window.ORVIA.profileStore){
      window.ORVIA.profileStore.persist().then(function(r){
        if(typeof toast!=='function')return;
        if(r&&r.success)toast(r.sync_status==='pending'?'' + T('pf.profil_offline_gespeichert_wird_synchronisiert') + '':'' + T('pf.profil_gespeichert') + '');
        else toast('' + T('pf.profil_lokal_gespeichert_cloud_sync') + '');
      });
    }
  }catch(e){}
  if(typeof renderProfileScreen==='function')renderProfileScreen();
  if(typeof renderDay==='function')renderDay();
  if(typeof toast==='function')toast('' + T('pf.orvia_system_eingerichtet') + '');
}
function renderOB(){
  var el=document.getElementById('onboarding');if(!el)return;
  obSyncFields();
  var s=OB_STEPS[OB_I],total=OB_STEPS.length;
  var dots='';for(var i=0;i<total;i++)dots+='<span class="ob-dot'+(i<=OB_I?' on':'')+'"></span>';
  var body='';
  if(s.t==='welcome'){
    body='<div class="ob-hero"><svg class="ob-mark" viewBox="0 0 512 512" aria-hidden="true"><use href="#orvia-mark"/></svg>'+
      '<div class="ob-wm">ORVIA</div><div class="ob-claim">' + T('pf.know_your_state_move_with') + '</div>'+
      '<p class="ob-lead">' + T('pf.richte_dein_persoenliches_performance_system') + '</p></div>';
  }else if(s.t==='done'){
    var modules=(OB.issues||[]).map(function(k){return ISSUE_LABELS[k]||k;});
    body='<div class="ob-hero"><svg class="ob-mark" viewBox="0 0 512 512" aria-hidden="true"><use href="#orvia-mark"/></svg>'+
      '<div class="ob-title">' + T('pf.dein_orvia_system_ist_eingerichtet') + '</div>'+
      '<p class="ob-lead">' + T('pf.ziel__') + '<b>'+escH(GOAL_LABELS[OB.primaryGoal]||'—')+'</b><br>'+
      '' + T('pf.module') + ''+escH(modules.length?modules.join(', '):'keine')+'<br>'+
      '' + T('pf.coaching') + ''+escH(COACH_LABELS[OB.coachingIntensity]||'—')+'</p>'+
      '<p class="ob-disc">' + T('pf.orvia_ersetzt_keine_medizinische_diagnose') + '</p></div>';
  }else if(s.t==='choice'){
    body='<div class="ob-title">'+escH(s.title)+'</div>'+(s.sub?'<div class="ob-sub">'+escH(s.sub)+'</div>':'')+
      '<div class="ob-chips">'+s.opts.map(norm).map(function(o){var on=OB[s.key]===o[0];
        return '<button class="ob-chip'+(on?' on':'')+'" onclick="obPickChoice(\''+s.key+'\',\''+o[0]+'\')">'+escH(o[1])+'</button>';}).join('')+'</div>';
  }else if(s.t==='multi'){
    body='<div class="ob-title">'+escH(s.title)+'</div>'+(s.sub?'<div class="ob-sub">'+escH(s.sub)+'</div>':'')+
      '<div class="ob-chips">'+s.opts.map(norm).map(function(o){var on=(OB[s.key]||[]).indexOf(o[0])>=0;
        return '<button class="ob-chip'+(on?' on':'')+'" onclick="obToggleMulti(\''+s.key+'\',\''+o[0]+'\')">'+escH(o[1])+'</button>';}).join('')+'</div>';
  }else if(s.t==='fields'){
    body='<div class="ob-title">'+escH(s.title)+'</div>'+(s.sub?'<div class="ob-sub">'+escH(s.sub)+'</div>':'')+
      '<div class="ob-fields">'+s.fields.map(function(f){var v=OB[f[0]]==null?'':OB[f[0]];
        var _ty=f[2]==='number'?'number':f[2]==='date'?'date':'text';
        return '<label class="ob-f"><span>'+escH(f[1])+'</span><input id="ob_'+f[0]+'" type="'+_ty+'" inputmode="'+(f[2]==='number'?'decimal':'text')+'" value="'+escH(v)+'"></label>';}).join('')+'</div>';
  }else if(s.t==='photo'){
    var _av=OB.avatar,_ini=((OB.name||'O').trim()[0]||'O').toUpperCase();
    body='<div class="ob-title">'+escH(s.title)+'</div>'+(s.sub?'<div class="ob-sub">'+escH(s.sub)+'</div>':'')+
      '<div class="ob-photo"><label class="ob-avatar" for="ob_photo">'+(_av?'<img src="'+escH(_av)+'" alt="">':'<span>'+escH(_ini)+'</span>')+'<span class="ob-cam">+</span></label>'+
      '<input id="ob_photo" type="file" accept="image/*" style="display:none" onchange="obPickPhoto(this)">'+
      (_av?'<button class="ob-skip" type="button" onclick="obRemovePhoto()">' + T('pf.foto_entfernen') + '</button>':'')+'</div>';
  }else if(s.t==='goals'){
    var _gl=(OB.secondaryGoals||[]).map(function(g,i){return '<div class="ob-goal"><span>'+escH(g)+'</span><button type="button" onclick="obRemoveGoal('+i+')" aria-label="' + T('pf.entfernen') + '">✕</button></div>';}).join('');
    body='<div class="ob-title">'+escH(s.title)+'</div>'+(s.sub?'<div class="ob-sub">'+escH(s.sub)+'</div>':'')+
      '<div class="ob-goallist">'+(_gl||'<div class="ob-empty">' + T('pf.noch_keine_weiteren_ziele') + '</div>')+'</div>'+
      '<div class="ob-goaladd"><input id="ob_goalinput" type="text" placeholder="' + T('pf.z_b_marathon_herbst_26') + '" onkeydown="if(event.key===&quot;Enter&quot;){event.preventDefault();obAddGoal();}"><button class="ob-add" type="button" onclick="obAddGoal()">+</button></div>';
  }
  var primaryLabel=s.t==='done'?'' + T('pf.fertig') + '':s.t==='welcome'?'Start':'' + T('pf.weiter') + '';
  var primaryAct=s.t==='done'?'obFinish()':'obNext()';
  var canSkip=OB_FRESH&&s.t==='welcome';
  el.innerHTML='<div class="ob-card">'+
    '<div class="ob-top"><span class="ob-step">Schritt '+(OB_I+1)+' / '+total+'</span>'+
      (s.t!=='welcome'&&s.t!=='done'?'<button class="ob-x" onclick="closeOnboarding()" aria-label="' + T('pf.schliessen') + '">✕</button>':'')+'</div>'+
    '<div class="ob-dots">'+dots+'</div>'+
    '<div class="ob-body">'+body+'</div>'+
    '<div class="ob-nav">'+
      (OB_I>0&&s.t!=='done'?'<button class="ob-btn sec" onclick="obBack()">' + T('pf.zurueck') + '</button>':'<span></span>')+
      '<button class="ob-btn pri" onclick="'+primaryAct+'">'+primaryLabel+'</button>'+
    '</div>'+
    (canSkip?'<button class="ob-skip" onclick="closeOnboarding()">' + T('pf.spaeter_einrichten') + '</button>':'')+
    '</div>';
  el.classList.add('show');
}

/* ============================================================
   ZIELE-VERWALTUNG (Inkrement 2): Übersicht, Anlegen, Bearbeiten, Priorität/Rolle,
   Pausieren/Fortsetzen/Erreicht/Archivieren/Löschen, Zielkonflikte, Plan-Auswirkung.
   Nutzt ORVIA.profileModel. Keine technischen IDs/Kategorien in der UI.
   ============================================================ */
var GOAL_CAT_DE={
  fat_loss:'' + T('pf.koerperfett_reduzieren') + '',shredded:'' + T('pf.sehr_definiert_werden') + '',weight_loss:'' + T('pf.gewicht_reduzieren') + '',weight_gain:'' + T('pf.gewicht_zunehmen') + '',
  muscle_gain:'' + T('pf.muskeln_aufbauen') + '',muscle_maintain:'' + T('pf.muskulatur_erhalten') + '',recomposition:'Recomposition',target_bodyfat:'' + T('pf.koerperfettanteil_erreichen') + '',
  run_5k:'5 km',run_10k:'10 km',half_marathon:'' + T('pf.halbmarathon') + '',marathon:'' + T('pf.marathon') + '',triathlon:'' + T('pf.triathlon') + '',ironman:'Ironman',cycling_race:'Radrennen',swim_goal:'Schwimmziel',base_endurance:'Grundlagenausdauer',vo2max:'' + T('pf.vo_max_verbessern') + '',
  get_stronger:'' + T('pf.staerker_werden') + '',hypertrophy:'Hypertrophie',lift_pr:'' + T('pf.uebung_verbessern') + '',strength_endurance:'Kraftausdauer',functional_strength:'' + T('pf.funktionelle_kraft') + '',explosive_strength:'Explosivkraft',
  football:'Fußball',handball:'Handball',basketball:'Basketball',volleyball:'Volleyball',tennis:'Tennis',padel:'Padel',hockey:'Hockey',rugby:'Rugby',other_team:'Mannschaftssport',
  sprint_speed:'Sprintgeschwindigkeit',change_of_direction:'Richtungswechsel',jump:'Sprungkraft',game_endurance:'Spielausdauer',repeated_sprints:'' + T('pf.wiederholte_sprints') + '',duel_strength:'Zweikampfstärke',mobility_perf:'Beweglichkeit',technique:'Technik',robustness:'Belastbarkeit',injury_prevention:'Verletzungsprävention',
  reduce_complaints:'' + T('pf.beschwerden_reduzieren') + '',stabilize_knee:'' + T('pf.knie_stabilisieren') + '',strengthen_back:'' + T('pf.ruecken_staerken') + '',improve_mobility:'' + T('pf.beweglichkeit_verbessern') + '',pain_free:'' + T('pf.schmerzfrei_trainieren') + '',increase_robustness:'' + T('pf.belastbarkeit_erhoehen') + '',return_after_break:'' + T('pf.wiedereinstieg') + '',improve_recovery:'' + T('pf.regeneration_verbessern') + '',improve_sleep:'' + T('pf.schlaf_verbessern') + '',reduce_stress:'' + T('pf.stress_reduzieren') + '',
  train_regularly:'' + T('pf.regelmaessiger_trainieren') + '',keep_fit:'' + T('pf.fitness_erhalten') + '',active_daily:'' + T('pf.alltag_aktiver') + '',long_term_health:'' + T('pf.langfristig_gesund') + '',wellbeing:'Wohlbefinden',custom:'' + T('pf.eigenes_ziel') + ''};
var GOAL_GROUP_DE={body_composition:'Körper',endurance:'' + T('pf.ausdauer') + '',strength:'Kraft',team_sport:'Mannschaftssport',sport_performance:'Sportleistung',health:'Gesundheit',general:'Allgemein'};
function goalCatLabel(c){return GOAL_CAT_DE[c]||c;}
/* ============================================================
   ORVIA · Sheet-/Modal-Infrastruktur (Phase 4j.1)
   - genau EIN Scrollcontainer pro Sheet (.orvia-sheet-scroll)
   - Header und Action-Bar liegen AUSSERHALB des Scrollbereichs
   - Sheet-Stack: nur ein sichtbares scrollbares Sheet
   - Scroll-Lock des Hintergrunds, Fokus-Verwaltung, Escape (Desktop)
   - jüngstes Overlay liegt oben (gemeinsamer z-index-Zähler für Modal + Sheet)
   Keine Fachlogik – reine Infrastruktur.
   ============================================================ */
var _sheetStack=[];          // [{id, trigger}] – aktueller Sheet-Stapel
var _modalStack=[];          // [{id, trigger}] – aktueller Modal-Stapel (kurze Dialoge über Sheets)
var _sheetLockCount=0;       // Referenzzähler für Hintergrund-Scroll-Lock
var _zTop=650;               // Basis über .orvia-modal-bg; jüngstes Overlay oben
function _nextZ(){_zTop+=1;return _zTop;}
function _sheetLock(on){
  try{
    if(on){_sheetLockCount++;if(_sheetLockCount===1&&typeof document!=='undefined'&&document.body&&document.body.classList)document.body.classList.add('sheet-open');}
    else{if(_sheetLockCount>0)_sheetLockCount--;if(_sheetLockCount===0&&typeof document!=='undefined'&&document.body&&document.body.classList)document.body.classList.remove('sheet-open');}
  }catch(e){}
}
function _sheetEntry(id){for(var i=0;i<_sheetStack.length;i++){if(_sheetStack[i].id===id)return _sheetStack[i];}return null;}
function _sheetTop(){return _sheetStack.length?_sheetStack[_sheetStack.length-1]:null;}
function _modalEntry(id){for(var i=0;i<_modalStack.length;i++){if(_modalStack[i].id===id)return _modalStack[i];}return null;}
function _modalTop(){return _modalStack.length?_modalStack[_modalStack.length-1]:null;}
function _showSheetEl(id,show){var w=window[id];if(!w)return;try{if(w.style)w.style.display=show?'':'none';if(show){if(w.removeAttribute)w.removeAttribute('aria-hidden');}else if(w.setAttribute)w.setAttribute('aria-hidden','true');}catch(e){}}
function _focusSheet(id){var w=window[id];if(!w||!w.querySelector)return;try{var x=w.querySelector('.orvia-sheet-x');if(x&&typeof x.focus==='function')x.focus();}catch(e){}}
function _closeM(id){
  var w=window[id];var entry=_sheetEntry(id);var mEntry=_modalEntry(id);
  if(w){try{w.remove();}catch(e){}window[id]=null;}
  if(mEntry){
    _modalStack=_modalStack.filter(function(s){return s.id!==id;});
    // Fokus zurück zum Auslöser (z. B. Button im darunterliegenden Sheet).
    if(mEntry.trigger&&typeof mEntry.trigger.focus==='function'){try{mEntry.trigger.focus();}catch(e){}}
  }
  if(entry){
    _sheetStack=_sheetStack.filter(function(s){return s.id!==id;});
    _sheetLock(false);
    var top=_sheetTop();
    if(top){_showSheetEl(top.id,true);_focusSheet(top.id);}
    else if(entry.trigger&&typeof entry.trigger.focus==='function'){try{entry.trigger.focus();}catch(e){}}
  }
}
/* Kurze Bestätigungs-/Info-Dialoge: zentriertes Modal (bewusst NICHT als Sheet).
   Härtung (Profil-Paket 2026-07): role=dialog + aria-modal, initialer Fokus auf den Dialog,
   Fokus-Restore zum Auslöser beim Schließen (_closeM), Escape schließt das oberste Modal
   (s. _sheetKeydown). Scroll-Owner ist AUSSCHLIESSLICH .orvia-modal (styles.css). */
function _modal(id,inner){
  _closeM(id);
  var trigger=null;try{trigger=(typeof document!=='undefined'&&document.activeElement)||null;}catch(e){}
  var w=document.createElement('div');w.className='orvia-modal-bg';
  try{if(w.style)w.style.zIndex=_nextZ();}catch(e){}
  w.innerHTML='<div class="orvia-modal goal-modal" role="dialog" aria-modal="true" tabindex="-1">'+inner+'</div>';
  document.body.appendChild(w);window[id]=w;
  w.addEventListener('click',function(ev){if(ev.target===w)_closeM(id);});
  _modalStack.push({id:id,trigger:trigger});
  try{var box=w.querySelector&&w.querySelector('.orvia-modal');if(box&&typeof box.focus==='function')box.focus();}catch(e){}
  return w;
}
/* Lange Editoren als produktreife mobile Sheets.
   opts: {id, title, body, actions, size('full'|'large'), onClose} */
function openSheet(opts){
  opts=opts||{};var id=opts.id;
  var trigger=null;try{trigger=(typeof document!=='undefined'&&document.activeElement)||null;}catch(e){}
  _closeM(id);
  var size=opts.size||'full';var titleId=id+'__t';
  var w=document.createElement('div');w.className='orvia-sheet-backdrop';
  try{if(w.style)w.style.zIndex=_nextZ();}catch(e){}
  w.innerHTML=
    '<section class="orvia-sheet orvia-sheet--'+size+'" role="dialog" aria-modal="true" aria-labelledby="'+titleId+'">'+
      '<header class="orvia-sheet-header">'+
        '<h2 class="orvia-sheet-title" id="'+titleId+'">'+(opts.title||'')+'</h2>'+
        '<button type="button" class="orvia-sheet-x" data-sheet-close="'+id+'" aria-label="' + T('pf.schliessen') + '">'+
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>'+
        '</button>'+
      '</header>'+
      '<div class="orvia-sheet-scroll">'+(opts.body||'')+'</div>'+
      (opts.actions!=null?'<footer class="orvia-sheet-actions">'+opts.actions+'</footer>':'')+
    '</section>';
  document.body.appendChild(w);window[id]=w;
  var onClose=opts.onClose||function(){_closeM(id);};w._orviaClose=onClose;
  w.addEventListener('click',function(ev){
    var t=ev.target;var btn=t&&t.closest?t.closest('[data-sheet-close]'):null;
    if(btn){onClose();return;}
  });
  var prev=_sheetTop();if(prev)_showSheetEl(prev.id,false);
  _sheetStack.push({id:id,trigger:trigger});
  _sheetLock(true);_focusSheet(id);
  return w;
}
/* Escape schließt das oberste Overlay: zuerst eigene Modals (_modalStack, oberstes zuerst),
   dann Sheets. FREMDE .orvia-modal-bg (z. B. System-/Migrations-Dialoge aus ui.js/activity.js,
   nicht über _modal() erzeugt) werden bewusst NICHT geschlossen. */
function _sheetKeydown(ev){
  if(!ev||(ev.key!=='Escape'&&ev.keyCode!==27))return;
  var m=_modalTop();
  if(m){_closeM(m.id);return;}
  try{if(document.querySelector&&document.querySelector('.orvia-modal-bg'))return;}catch(e){}
  var top=_sheetTop();if(!top)return;var w=window[top.id];if(!w)return;
  if(typeof w._orviaClose==='function')w._orviaClose();
}
try{if(typeof document!=='undefined'&&document.addEventListener)document.addEventListener('keydown',_sheetKeydown);}catch(e){}

function openGoalsManager(){window._goalsMgr=_modal('_goalsMgr','<h3>' + T('pf.ziele_verwalten') + '</h3><div id="goalsMgrBody"></div>');renderGoalsList();}
function closeGoalsManager(){_closeM('_goalsMgr');window._goalsMgr=null;}
/* Zielwert lesbar: metricType 'time' ⇒ Sekunden als h:mm:ss, 'pace' ⇒ min/km; sonst Wert + Einheit.
   Befund 12.09.: „Ziel: 6600 s" in der Zielliste. */
function _goalValueLabel(g,v){try{var M=pmModel();
  if(g&&g.metricType==='time')return M.formatDuration(v)+' h';
  if(g&&g.metricType==='pace')return M.formatPace(v)+' /km';
}catch(e){}return escH(''+v)+(g&&g.unit?' '+escH(g.unit):'');}
/* Mehrere aktive Ziele mit Prioritaet 1: der kanonische Selektor mainGoalOf() nimmt das
   zuerst angelegte — fuer den Nutzer unsichtbar. Die Liste benennt deshalb nur das
   tatsaechliche Hauptziel so und bietet fuer die anderen „Zum Hauptziel machen" an
   (explizite Entscheidung statt stiller Umsortierung). */
function _mainGoalId(){try{var m=(typeof mainGoalOf==='function')?mainGoalOf():null;return m?m.id:null;}catch(e){return null;}}
function goalMakeMain(id){var gs=listGoals();var patched=false;
  gs.forEach(function(g){if(!g||g.status!=='active')return;
    if(g.id===id){if(g.priority!==1){goalUpdate(g.id,{priority:1});patched=true;}}
    else if(g.priority===1){goalUpdate(g.id,{priority:2});patched=true;}});
  if(patched&&typeof toast==='function')toast(T('pf.hauptziel_festgelegt'));renderGoalsList();
  try{if(typeof renderRaceHeader==='function')renderRaceHeader();}catch(e){}}
function renderGoalsList(){var box=document.getElementById('goalsMgrBody');if(!box)return;var M=pmModel();var gs=listGoals();
  var byStatus={active:[],paused:[],achieved:[],archived:[],abandoned:[]};gs.forEach(function(g){(byStatus[g.status]||byStatus.active).push(g);});
  byStatus.active.sort(function(a,b){return a.priority-b.priority;});
  var mainId=_mainGoalId();var prio1=byStatus.active.filter(function(g){return g.priority===1;});
  var todayKey=(function(){try{return new Date().toISOString().slice(0,10);}catch(e){return '';}})();
  var titleOf=function(id){var g=gs.filter(function(x){return x&&x.id===id;})[0];return g?(g.title||goalCatLabel(g.category)):id;};
  function card(g){var roleKey=M.roleOfGoal(g);var role=GOAL_ROLE_DE[roleKey]||'Ziel';
    var notMain=(roleKey==='main'&&g.status==='active'&&mainId&&g.id!==mainId);
    if(notMain)role=T('pf.prioritaet_1_nicht_hauptziel');
    var when=g.targetDate?(' · '+(typeof shortDate==='function'?shortDate(g.targetDate):g.targetDate)):(g.timeHorizon==='long'?' · langfristig':'');
    var past=(g.status==='active'&&g.targetDate&&todayKey&&String(g.targetDate).slice(0,10)<todayKey);
    var prog=(g.currentValue!=null||g.targetValue!=null)?('<div class="gmc-prog">'+(g.currentValue!=null?T('pf.aktuell')+_goalValueLabel(g,g.currentValue):'')+(g.targetValue!=null?T('pf.ziel')+_goalValueLabel(g,g.targetValue):'')+'</div>'):'';
    var hint=past?'<div class="gmc-meta gmc-warn">'+T('pf.zieldatum_ueberschritten')+'</div>':'';
    var acts='<div class="gmc-acts">'+
      '<button class="gmc-b" onclick="openGoalDetail(\''+g.id+'\')">Details</button>'+
      '<button class="gmc-b" onclick="openGoalEditor(\''+g.id+'\')">' + T('pf.bearbeiten') + '</button>'+
      (notMain?'<button class="gmc-b" onclick="goalMakeMain(\''+g.id+'\')">'+T('pf.zum_hauptziel_machen')+'</button>':'')+
      (g.status==='active'?'<button class="gmc-b" onclick="goalSetStatus(\''+g.id+'\',\'paused\')">Pausieren</button>':'')+
      (g.status==='paused'?'<button class="gmc-b" onclick="goalSetStatus(\''+g.id+'\',\'active\')">Fortsetzen</button>':'')+
      (g.status!=='achieved'?'<button class="gmc-b" onclick="goalSetStatus(\''+g.id+'\',\'achieved\')">Erreicht</button>':'')+
      (g.status!=='archived'?'<button class="gmc-b" onclick="goalSetStatus(\''+g.id+'\',\'archived\')">Archivieren</button>':'')+
      '<button class="gmc-b danger-btn" onclick="confirmDeleteGoal(\''+g.id+'\')">Löschen</button></div>';
    return '<div class="gmcard'+(notMain?' gmcard-notmain':'')+'"><div class="gmc-h">'+escH(g.title||'Ziel')+'</div><div class="gmc-meta">'+escH(role+' · '+goalCatLabel(g.category)+when)+'</div>'+hint+prog+acts+'</div>';}
  function section(title,arr){return arr.length?('<div class="gm-sec">'+escH(title)+'</div>'+arr.map(card).join('')):'';}
  var prioHint=prio1.length>1?'<div class="gm-conflict gm-prio"><b>'+T('pf.mehrere_hauptziele')+'</b><p>'+escH(T('pf.mehrere_hauptziele_text',{n:prio1.length,title:titleOf(mainId)}))+'</p></div>':'';
  var conflicts=M.detectGoalConflicts(gs).filter(function(c){return !_conflictDecided(c);});
  var conflictHTML=conflicts.map(function(c){return '<div class="gm-conflict"><b>' + T('pf.zielkonflikt_erkannt') + '</b><p>'+escH(c.explanation)+'</p>'+
    '<div class="gmc-meta">'+escH(T('pf.betroffen')+' '+c.goalIds.map(titleOf).join(' ↔ '))+'</div>'+
    '<div class="gm-cacts">'+[T('pf.ausdauer_priorisieren_kraft_erhalten'),T('pf.muskelaufbau_priorisieren_ausdauer_erhalten'),T('pf.ziele_zeitlich_staffeln'),T('pf.eigene_entscheidung')].map(function(opt,i){return '<button class="gmc-b" onclick="decideConflict(\''+escH(c.conflictType)+'\',\''+escH(c.goalIds.join(','))+'\','+i+')">'+escH(opt)+'</button>';}).join('')+'</div></div>';}).join('');
  box.innerHTML='<button class="btn" onclick="openGoalEditor()">' + T('pf.ziel_hinzufuegen') + '</button>'+prioHint+conflictHTML+
    section(T('pf.aktive_ziele'),byStatus.active)+section('Pausiert',byStatus.paused)+section('Erreicht',byStatus.achieved)+section('Archiviert',byStatus.archived)+
    '<button class="btn sec" style="margin-top:12px" onclick="closeGoalsManager()">' + T('pf.schliessen') + '</button>';}

function _conflictDecided(c){try{var dec=(PROFILE.goalConflictDecisions||[]);return dec.some(function(d){return d.conflictType===c.conflictType&&d.goalIds.slice().sort().join(',')===c.goalIds.slice().sort().join(',');});}catch(e){return false;}}
function decideConflict(type,ids,optionIdx){var strat=['endurance_first','strength_first','stagger','custom'][optionIdx]||'custom';
  PROFILE.goalConflictDecisions=PROFILE.goalConflictDecisions||[];PROFILE.goalConflictDecisions.push({conflictType:type,goalIds:ids.split(','),userDecision:strat,createdAt:new Date().toISOString()});
  saveProfile();/* A0-Fix: save() (data.js) persistiert PROFILE nicht */renderGoalsList();if(typeof toast==='function')toast('' + T('pf.entscheidung_gespeichert') + '');}

/* ============================================================
   ZIEL-WIZARD (Inkrement 3): 7 Schritte, Fortschritt, Zurück ohne Datenverlust,
   Entwurf bleibt erhalten, Vorausfüllen, kein Zwischenspeichern, Unsaved-Schutz via diffState.
   ============================================================ */
var GW_STEPS=[
  {key:'type',label:'Zielart'},
  {key:'details',label:'Konkretisieren'},
  {key:'sports',label:'' + T('pf.sportarten') + ''},
  {key:'metrics',label:'' + T('pf.zeitraum_messwerte') + ''},
  {key:'role',label:'' + T('pf.rolle_prioritaet') + ''},
  {key:'milestones',label:'' + T('pf.meilensteine') + ''},
  {key:'summary',label:'' + T('pf.zusammenfassung') + ''}];
function _gwDraftFromGoal(g){var M=pmModel();
  if(!g)return {title:'',category:'custom',description:'',role:'secondary',timeHorizon:'open',targetDate:null,sports:[],currentValue:null,targetValue:null,unit:null,categoryData:{},milestones:[]};
  return {title:g.title||'',category:g.category||'custom',description:g.description||'',role:M.roleOfGoal(g),timeHorizon:g.timeHorizon||'open',targetDate:g.targetDate||null,
    sports:(g.sports||[]).slice(),currentValue:g.currentValue,targetValue:g.targetValue,unit:g.unit||null,
    categoryData:JSON.parse(JSON.stringify(g.categoryData||{})),milestones:JSON.parse(JSON.stringify(g.milestones||[]))};}
function openGoalEditor(id){var g=id?listGoals().filter(function(x){return x.id===id;})[0]:null;
  var draft=_gwDraftFromGoal(g);
  window._gw={id:id||null,step:0,draft:draft,orig:pmModel().diffState?JSON.stringify(draft):JSON.stringify(draft)};
  openSheet({id:'_goalEd',title:(id?'' + T('pf.ziel_bearbeiten') + '':'' + T('pf.ziel_hinzufuegen') + ''),onClose:gwCancel,body:'<div id="gwBody"></div>',actions:'<div id="gwNav" class="gw-nav"></div>'});gwRender();}
function gwRender(){var box=document.getElementById('gwBody');if(!box)return;var W=window._gw;var st=GW_STEPS[W.step];
  var prog='<div class="gw-prog">'+GW_STEPS.map(function(s,i){return '<span class="gw-dot'+(i===W.step?' on':'')+(i<W.step?' done':'')+'"></span>';}).join('')+'</div>'+
    '<div class="gw-steplabel">Schritt '+(W.step+1)+' von '+GW_STEPS.length+' · '+escH(st.label)+'</div>';
  box.innerHTML=prog+'<div id="gwStep">'+_gwStepHTML(st.key)+'</div>';
  var nav=document.getElementById('gwNav');
  if(nav)nav.innerHTML=
    (W.step>0?'<button class="btn sec" onclick="gwBack()">' + T('pf.zurueck') + '</button>':'<button class="btn sec" onclick="gwCancel()">' + T('pf.abbrechen') + '</button>')+
    (W.step<GW_STEPS.length-1?'<button class="btn" onclick="gwNext()">' + T('pf.weiter') + '</button>':'<button class="btn" onclick="gwSave()">'+(W.id?'' + T('pf.speichern') + '':'' + T('pf.ziel_anlegen') + '')+'</button>');}
function _gwField(f,cd){var id='gwf_'+f.key;var v=cd[f.key];var lab='<label>'+escH(f.label)+(f.unit?' ('+escH(f.unit)+')':'')+'</label>';
  if(f.type==='bool')return '<div class="gm-field gm-inline"><input type="checkbox" id="'+id+'"'+(v?' checked':'')+'>'+lab+'</div>';
  if(f.type==='select'){var pairs=f.optionPairs?f.optionPairs:(f.options||[]).map(function(o){return [o,o];});return '<div class="gm-field">'+lab+segHTML(id,pairs,v)+'</div>';}
  if(f.type==='longtext')return '<div class="gm-field">'+lab+'<textarea id="'+id+'" rows="2">'+escH(v!=null?v:'')+'</textarea></div>';
  var t=f.type==='number'?'number':(f.type==='date'?'date':'text');
  return '<div class="gm-field">'+lab+'<input type="'+t+'" id="'+id+'" value="'+escH(v!=null?v:'')+'"></div>';}
function _gwStepHTML(key){var M=pmModel();var d=window._gw.draft;
  if(key==='type'){var groups=[];for(var grp in M.GOAL_CATEGORIES){groups.push([GOAL_GROUP_DE[grp]||grp,M.GOAL_CATEGORIES[grp].map(function(c){return [c,goalCatLabel(c)];})]);}
    return '<div class="gm-field"><label>' + T('pf.worum_geht_es') + '</label>'+segGroupedHTML('gw_cat',groups,d.category)+'</div>'+
      '<div class="gm-field"><label>' + T('pf.titel') + '</label><input id="gw_title" value="'+escH(d.title)+'" placeholder="' + T('pf.z_b_halbmarathon_unter_1') + '"><span class="ob2-err" id="gw_err" role="alert"></span></div>'+
      (d.category==='custom'?'<div class="gm-field"><label>' + T('pf.eigene_kategorie_optional') + '</label><input id="gw_customcat" value="'+escH(d.customCategory||'')+'" placeholder="' + T('pf.z_b_hyrox_wandern') + '"></div>':'')+
      '<div class="gm-field"><label>' + T('pf.beschreibung_optional') + '</label><input id="gw_desc" value="'+escH(d.description)+'"></div>'+
      '<div class="gm-field"><label>' + T('pf.warum_ist_dir_das_wichtig') + '</label><input id="gw_motiv" value="'+escH(d.motivation||'')+'"></div>';}
  if(key==='details'){var fields=M.categoryFieldsFor(d.category);var html='';
    if(d.category==='shredded')html+='<p class="note" style="text-align:left">' + T('pf.sehr_definiert_werden_koerperfett_reduzieren') + '</p>';
    if(d.category==='ironman'||d.category==='triathlon')html+='<p class="note" style="text-align:left">' + T('pf.langfristiges_ziel_ohne_festes_datum') + '</p>';
    if(d.category==='football'){var fo=M.sportFollowupSchema('football').focusOptions;var sel=d.categoryData.focus||[];
      html+='<div class="gm-field"><label>' + T('pf.leistungsbereiche_mehrere_moeglich') + '</label><div class="gm-chips" id="gw_focus">'+fo.map(function(x){return '<button type="button" class="gm-chip'+(sel.indexOf(x)>=0?' on':'')+'" data-v="'+x+'" onclick="gmToggle(this)">'+escH(goalCatLabel(x))+'</button>';}).join('')+'</div></div>';}
    html+=fields.length?fields.map(function(f){return _gwField(f,d.categoryData);}).join(''):(d.category==='football'?'':'<p class="note" style="text-align:left">' + T('pf.fuer_diese_zielart_sind_keine') + '</p>');
    return html;}
  if(key==='sports'){var sportsAll=(PROFILE.sports||[]).map(function(s){return typeof s==='string'?s:(s.sportId||s.customName);}).filter(Boolean);
    if(!sportsAll.length)return '<p class="note" style="text-align:left">' + T('pf.noch_keine_sportarten_im_profil') + '</p>';
    return '<div class="gm-field"><label>' + T('pf.welche_sportarten_betrifft_das_ziel') + '</label><div class="gm-chips" id="gw_sports">'+sportsAll.map(function(s){return '<button type="button" class="gm-chip'+(d.sports.indexOf(s)>=0?' on':'')+'" data-v="'+escH(s)+'" onclick="gmToggle(this)">'+escH(s)+'</button>';}).join('')+'</div></div>';}
  if(key==='metrics'){var horizons=[['short','kurzfristig'],['mid','mittelfristig'],['long','langfristig'],['open','' + T('pf.ohne_festes_datum') + '']];
    // P5: zeitbasierte Kategorien (HM, Marathon, Ironman …) bekommen ein ECHTES
    // Zeitfeld — „Sub 10" ist damit strukturiert (Sekunden) statt Freitext speicherbar.
    var isTime=(M.goalMetricTypeFor&&M.goalMetricTypeFor(d.category)==='time')||d.metricType==='time';
    var valueFields=isTime
      ?('<div class="row2"><div class="gm-field"><label>' + T('pf.aktuelle_zeit_optional') + '</label><input id="gw_cur_time" value="'+escH(d.currentValue!=null?M.formatDuration(d.currentValue):'')+'" placeholder="' + T('pf.z_b_1_58_30') + '"></div>'+
        '<div class="gm-field"><label>' + T('pf.zielzeit_') + '</label><input id="gw_tgt_time" value="'+escH(d.targetValue!=null?M.formatDuration(d.targetValue):'')+'" placeholder="' + T('pf.z_b_1_50_00') + '"></div></div>'+
        '<span class="ob2-err" id="gw_time_err" role="alert"></span>')
      :('<div class="row2"><div class="gm-field"><label>' + T('pf.aktuell_optional') + '</label><input id="gw_cur" value="'+escH(d.currentValue!=null?d.currentValue:'')+'"></div>'+
        '<div class="gm-field"><label>' + T('pf.ziel_optional') + '</label><input id="gw_tgt" value="'+escH(d.targetValue!=null?d.targetValue:'')+'"></div></div>'+
        '<div class="gm-field"><label>' + T('pf.einheit_optional') + '</label><input id="gw_unit" value="'+escH(d.unit||'')+'" placeholder="' + T('pf.z_b_min_kg_m') + '"></div>');
    return '<div class="gm-field"><label>' + T('pf.zeitraum') + '</label>'+segHTML('gw_hz',horizons,d.timeHorizon||'open')+'</div>'+
      '<div class="gm-field"><label>' + T('pf.zieldatum_optional') + '</label><input type="date" id="gw_date" value="'+escH(d.targetDate||'')+'"><span class="ob2-err" id="gw_err" role="alert"></span></div>'+
      valueFields;}
  if(key==='role'){var roles=[['main','Hauptziel'],['secondary','' + T('pf.sekundaeres_entwicklungsziel') + ''],['maintain','Erhaltungsziel'],['longterm','' + T('pf.langfristiges_hintergrundziel') + '']];
    return '<div class="gm-field"><label>' + T('pf.welche_rolle_hat_dieses_ziel') + '</label>'+segHTML('gw_role',roles,d.role||'secondary')+'</div>'+
      '<p class="note" style="text-align:left">' + T('pf.pro_planungsphase_gibt_es_standardmaessig') + '</p>';}
  if(key==='milestones'){return '<div id="gwMs">'+_gwMsHTML()+'</div>'+
      '<div class="gm-field"><label>' + T('pf.neuer_meilenstein') + '</label><input id="gw_ms_title" placeholder="' + T('pf.z_b_1_500_m') + '"></div>'+
      '<button class="gmc-b" onclick="gwAddMs()">' + T('pf.meilenstein_hinzufuegen') + '</button>';}
  if(key==='summary'){var role=GOAL_ROLE_DE[d.role]||'Ziel';var cdKeys=Object.keys(d.categoryData||{}).filter(function(k){return d.categoryData[k]!==''&&d.categoryData[k]!=null&&!(Array.isArray(d.categoryData[k])&&!d.categoryData[k].length);});
    return '<div class="gm-sum">'+
      '<div><b>'+escH(d.title||'' + T('pf.ohne_titel') + '')+'</b></div>'+
      '<div class="gmc-meta">'+escH(role+' · '+goalCatLabel(d.category))+'</div>'+
      (d.description?'<p>'+escH(d.description)+'</p>':'')+
      '<div class="gmc-meta">' + T('pf.zeitraum') + ': '+escH(d.timeHorizon||'offen')+(d.targetDate?' · '+escH(d.targetDate):'' + T('pf.ohne_datum') + '')+'</div>'+
      (d.sports.length?'<div class="gmc-meta">' + T('pf.sportarten') + ': '+escH(d.sports.join(', '))+'</div>':'')+
      ((d.currentValue!=null||d.targetValue!=null)?'<div class="gmc-meta">'+(d.currentValue!=null?'' + T('pf.aktuell_') + ''+escH(''+d.currentValue):'')+(d.targetValue!=null?'' + T('pf.ziel_') + ''+escH(''+d.targetValue):'')+(d.unit?' '+escH(d.unit):'')+'</div>':'')+
      (cdKeys.length?'<div class="gmc-meta">' + T('pf.spezialdaten') + ': '+escH(cdKeys.length+'' + T('pf.felder_ausgefuellt') + '')+'</div>':'')+
      (d.milestones.length?'<div class="gmc-meta">' + T('pf.meilensteine') + ': '+d.milestones.length+'</div>':'')+
      '</div>';}
  return '';}
function _gwMsHTML(){var d=window._gw.draft;if(!d.milestones.length)return '<p class="note" style="text-align:left">' + T('pf.noch_keine_meilensteine_optional') + '</p>';
  return d.milestones.map(function(m,i){return '<div class="gw-ms"><span>'+escH(m.title||'Meilenstein')+'</span>'+
    '<button class="gmc-b" onclick="gwMoveMs('+i+',-1)">↑</button><button class="gmc-b" onclick="gwMoveMs('+i+',1)">↓</button>'+
    '<button class="gmc-b danger-btn" onclick="gwDelMs('+i+')">✕</button></div>';}).join('');}
function gwAddMs(){var el=document.getElementById('gw_ms_title');var t=(el&&el.value||'').trim();if(!t)return;window._gw.draft.milestones.push({id:'ms:'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),title:t,status:'planned',order:window._gw.draft.milestones.length});if(el)el.value='';document.getElementById('gwMs').innerHTML=_gwMsHTML();}
function gwMoveMs(i,delta){var ms=window._gw.draft.milestones;var j=i+delta;if(j<0||j>=ms.length)return;var t=ms[i];ms[i]=ms[j];ms[j]=t;document.getElementById('gwMs').innerHTML=_gwMsHTML();}
function gwDelMs(i){window._gw.draft.milestones.splice(i,1);document.getElementById('gwMs').innerHTML=_gwMsHTML();}
// Aktuelle Schritt-Eingaben in den Entwurf übernehmen (Zurück/Weiter verlieren nichts).
function _gwCollect(){var d=window._gw.draft;var st=GW_STEPS[window._gw.step].key;
  function val(id){var e=document.getElementById(id);return e?e.value:undefined;}
  if(st==='type'){var c=_segVal('gw_cat');if(c!=null&&c!=='')d.category=c;var t=val('gw_title');if(t!=null)d.title=t.trim();var ds=val('gw_desc');if(ds!=null)d.description=ds;
    var cc=val('gw_customcat');if(cc!=null)d.customCategory=cc.trim()||null;var mv=val('gw_motiv');if(mv!=null)d.motivation=mv;}
  else if(st==='details'){var M=pmModel();M.categoryFieldsFor(d.category).forEach(function(f){if(f.type==='select'){var sv=_segVal('gwf_'+f.key);if(sv!=null)d.categoryData[f.key]=sv;return;}var e=document.getElementById('gwf_'+f.key);if(!e)return;if(f.type==='bool')d.categoryData[f.key]=e.checked;else if(f.type==='number'){d.categoryData[f.key]=e.value===''?null:(isNaN(parseFloat(e.value.replace(',','.')))?e.value:parseFloat(e.value.replace(',','.')));}else d.categoryData[f.key]=e.value;});
    var fc=document.getElementById('gw_focus');if(fc)d.categoryData.focus=Array.prototype.slice.call(fc.querySelectorAll('.on')).map(function(b){return b.dataset.v;});}
  else if(st==='sports'){var sc=document.getElementById('gw_sports');if(sc)d.sports=Array.prototype.slice.call(sc.querySelectorAll('.on')).map(function(b){return b.dataset.v;});}
  else if(st==='metrics'){var hz=_segVal('gw_hz');if(hz!=null&&hz!=='')d.timeHorizon=hz;var dt=val('gw_date');d.targetDate=dt||null;
    // P5: Zeitfeld (Sekunden) hat Vorrang, sonst Freiwert+Einheit wie bisher.
    var M2=pmModel();var tt=document.getElementById('gw_tgt_time');
    if(tt){var tSec=M2.parseDuration(tt.value);var cEl=document.getElementById('gw_cur_time');var cSec=cEl?M2.parseDuration(cEl.value):null;
      if(tt.value&&tSec==null){var te=document.getElementById('gw_time_err');if(te)te.textContent='' + T('pf.bitte_eine_gueltige_zeit_eingeben') + '';}
      d.targetValue=tSec;d.currentValue=cSec;d.unit='s';d.metricType='time';}
    else{d.currentValue=_gwNum('gw_cur');d.targetValue=_gwNum('gw_tgt');var u=val('gw_unit');d.unit=(u||'').trim()||null;}}
  else if(st==='role'){var r=_segVal('gw_role');if(r!=null&&r!=='')d.role=r;}}
function _gwNum(id){var el=document.getElementById(id);if(!el||el.value==='')return null;var n=parseFloat(String(el.value).replace(',','.'));return isNaN(n)?el.value.trim()||null:n;}
function gwNext(){_gwCollect();var d=window._gw.draft;var st=GW_STEPS[window._gw.step].key;
  if(st==='type'&&!d.title.trim()){var e=document.getElementById('gw_err');if(e)e.textContent='' + T('pf.bitte_gib_deinem_ziel_einen') + '';return;}
  if(st==='metrics'&&d.targetDate){var vr=pmModel().validateGoal({title:d.title,targetDate:d.targetDate});var er=document.getElementById('gw_err');if(er)er.textContent=vr.errors.targetDate||'';}
  window._gw.step++;gwRender();}
function gwBack(){_gwCollect();window._gw.step--;gwRender();}
function gwCancel(){_gwCollect();var W=window._gw;
  if(!pmModel().diffState(JSON.parse(W.orig),W.draft)){_closeM('_goalEd');return;}
  _modal('_gwDiscard','<h3>' + T('pf.aenderungen_verwerfen') + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.deine_letzten_anpassungen_wurden_noch') + '</p>'+
    '<button class="btn sec" onclick="_closeM(\'_gwDiscard\')">' + T('pf.weiter') + ' bearbeiten</button>'+
    '<button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_gwDiscard\');_closeM(\'_goalEd\')">' + T('pf.aenderungen_verwerfen_btn') + '</button>');}
function gwSave(){_gwCollect();var M=pmModel();var d=window._gw.draft;var id=window._gw.id;
  if(!d.title.trim()){window._gw.step=0;gwRender();var e=document.getElementById('gw_err');if(e)e.textContent='' + T('pf.bitte_gib_deinem_ziel_einen') + '';return;}
  var patch={category:d.category,title:d.title.trim(),description:d.description||'',priority:M.priorityOfRole(d.role),
    timeHorizon:d.timeHorizon,targetDate:d.targetDate||null,sports:d.sports,currentValue:d.currentValue,targetValue:d.targetValue,
    unit:d.unit,categoryData:d.categoryData,milestones:d.milestones,
    metricType:d.metricType||null,customCategory:d.customCategory||null,motivation:d.motivation||''};   // P5
  var wasMain=id&&(listGoals().filter(function(x){return x.id===id;})[0]||{}).priority===1;
  var becomesMain=patch.priority===1;
  var reason=(becomesMain||wasMain)?'' + T('pf.hauptziel_geaendert') + '':(d.targetDate?'' + T('pf.zieldatum_geaendert') + '':null);
  // G0: ehrlicher Speicherstatus. Erfolgstoast NUR bei erfolgreichem kanonischem
  // lokalem Save; ein geworfener Save darf keinen Erfolg vortäuschen.
  var _saved=false;
  try{ if(id)goalUpdate(id,patch,reason);else goalAdd(patch,reason); _saved=true; }
  catch(e){ try{console.warn('[ORVIA] Ziel-' + T('pf.speichern') + ' fehlgeschlagen:',e&&e.message);}catch(_){}}
  if(!_saved){ if(typeof toast==='function')toast('' + T('pf.speichern_fehlgeschlagen_bitte_erneut_versuchen') + ''); return; }
  window._gw=null;_closeM('_goalEd');renderGoalsList();
  if(reason)maybePlanImpact(reason);
  if(typeof toast==='function')toast(_goalSaveToast());}
/* Ehrliche Toast-Formulierung: lokaler Save ist abgeschlossen; ist das Gerät
   offline, läuft die Cloud-Synchronisierung noch (bestehende offlineQueue/Retry). */
function _goalSaveToast(){
  try{ if(typeof navigator!=='undefined'&&navigator&&('onLine'in navigator)&&navigator.onLine===false)return '' + T('pf.gespeichert_synchronisierung_laeuft') + ''; }catch(e){}
  return '' + T('pf.ziel_gespeichert') + '';}

/* Ziel-Detailansicht: alle Felder inkl. Spezialdaten, Meilensteine, Konflikte, Plan-Auswirkung. */
function openGoalDetail(id){var M=pmModel();var g=listGoals().filter(function(x){return x.id===id;})[0];if(!g)return;
  var role=GOAL_ROLE_DE[M.roleOfGoal(g)]||'Ziel';
  var fields=M.categoryFieldsFor(g.category);var cd=g.categoryData||{};
  var special=fields.filter(function(f){return cd[f.key]!=null&&cd[f.key]!=='';}).map(function(f){var v=cd[f.key];return '<div class="gmc-meta">'+escH(f.label)+': '+escH(v===true?'ja':(v===false?'nein':''+v))+(f.unit&&v!==true&&v!==false?' '+escH(f.unit):'')+'</div>';}).join('');
  if(cd.focus&&cd.focus.length)special+='<div class="gmc-meta">Leistungsbereiche: '+escH(cd.focus.map(goalCatLabel).join(', '))+'</div>';
  var ms=(g.milestones||[]).map(function(m){var done=m.status==='achieved';return '<div class="gw-ms"><span'+(done?' style="text-decoration:line-through;opacity:.6"':'')+'>'+escH(m.title)+'</span>'+
    '<button class="gmc-b" onclick="gdMs(\''+g.id+'\',\''+m.id+'\',\''+(done?'planned':'achieved')+'\')">'+(done?'↺':'✓')+'</button>'+
    '<button class="gmc-b danger-btn" onclick="gdMsDel(\''+g.id+'\',\''+m.id+'\')">✕</button></div>';}).join('')||'<p class="note" style="text-align:left">' + T('pf.keine_meilensteine') + '</p>';
  var conflicts=M.detectGoalConflicts(listGoals()).filter(function(c){return c.goalIds.indexOf(g.id)>=0&&!_conflictDecided(c);});
  var conf=conflicts.length?'<div class="gm-conflict"><b>' + T('pf.zielkonflikt') + '</b><p>'+escH(conflicts[0].explanation)+'</p></div>':'';
  var pi=(PROFILE.planImpact&&PROFILE.planImpact.pending)?'<div class="gmc-meta">' + T('pf.plan_auswirkung') + ' offen: '+escH(PROFILE.planImpact.reason||'')+'</div>':'';
  _modal('_goalDet','<h3>'+escH(g.title)+'</h3>'+
    '<div class="gmc-meta">'+escH(role+' · '+goalCatLabel(g.category)+'' + T('pf.status') + ''+g.status)+'</div>'+
    (g.description?'<p>'+escH(g.description)+'</p>':'')+
    (g.sports&&g.sports.length?'<div class="gmc-meta">' + T('pf.sportarten') + ': '+escH(g.sports.join(', '))+'</div>':'')+
    '<div class="gmc-meta">' + T('pf.zeitraum') + ': '+escH(g.timeHorizon||'offen')+(g.targetDate?' · '+escH(g.targetDate):'' + T('pf.ohne_datum') + '')+'</div>'+
    ((g.currentValue!=null||g.targetValue!=null)?'<div class="gmc-meta">'+(g.currentValue!=null?'' + T('pf.aktuell_') + ''+escH(''+g.currentValue):'')+(g.targetValue!=null?'' + T('pf.ziel_') + ''+escH(''+g.targetValue):'')+(g.unit?' '+escH(g.unit):'')+'</div>':'')+
    (special?'<div class="gm-sec">' + T('pf.spezialdaten') + '</div>'+special:'')+
    '<div class="gm-sec">' + T('pf.meilensteine') + '</div>'+ms+
    conf+pi+
    '<div class="gmc-acts" style="margin-top:12px"><button class="gmc-b" onclick="_closeM(\'_goalDet\');openGoalEditor(\''+g.id+'\')">' + T('pf.bearbeiten') + '</button>'+
    '<button class="gmc-b danger-btn" onclick="_closeM(\'_goalDet\');confirmDeleteGoal(\''+g.id+'\')">Löschen</button></div>'+
    '<div class="gmc-meta" style="margin-top:6px">Zuletzt aktualisiert: '+escH((g.updatedAt||'').slice(0,10))+'</div>'+
    '<button class="btn sec" style="margin-top:10px" onclick="_closeM(\'_goalDet\')">' + T('pf.schliessen') + '</button>');}
function gdMs(gid,mid,st){var g=listGoals().filter(function(x){return x.id===gid;})[0];if(!g)return;var ng=pmModel().updateMilestone(g,mid,{status:st});goalUpdate(gid,{milestones:ng.milestones});openGoalDetail(gid);}
function gdMsDel(gid,mid){var g=listGoals().filter(function(x){return x.id===gid;})[0];if(!g)return;var ng=pmModel().removeMilestone(g,mid);goalUpdate(gid,{milestones:ng.milestones});openGoalDetail(gid);}
function confirmDeleteGoal(id){var g=listGoals().filter(function(x){return x.id===id;})[0];
  _modal('_goalDel','<h3>' + T('pf.ziel_wirklich_loeschen') + '</h3><p class="modtext" style="margin:0 0 14px">Das Ziel'+(g?' „'+escH(g.title)+'"':'')+'' + T('pf.und_seine_gespeicherten') + '' + T('pf.meilensteine') + '' + T('pf.werden_dauerhaft_entfernt') + '</p>'+
    '<button class="btn sec" onclick="_closeM(\'_goalDel\')">' + T('pf.abbrechen') + '</button>'+
    '<button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_goalDel\');goalRemove(\''+id+'\');renderGoalsList()">' + T('pf.endgueltig_loeschen') + '</button>');}
/* Plan-Auswirkung: mehrere Änderungen einer Sitzung werden zu EINEM planImpact-Eintrag gebündelt
   (model.bundlePlanImpact). Dialog nur bei bestehendem Plan; KEINE automatische Neuberechnung. */
function maybePlanImpact(reason,fields){
  PROFILE.planImpact=pmModel().bundlePlanImpact(PROFILE.planImpact,reason,fields||[]);
  saveProfile();/* A0-Fix: save() (data.js) persistiert PROFILE nicht */
  if(!(PROFILE.weekPlan))return; // kein bestehender Plan → nur Flag setzen, kein Dialog
  _modal('_planImp','<h3>' + T('pf.plan_auswirkung') + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.diese_aenderung_kann_deinen_bestehenden') + '</p>'+
    '<button class="btn sec" onclick="_planDecide(\'keep\')">Bestehenden Plan beibehalten</button>'+
    '<button class="btn sec" style="margin-top:10px" onclick="_planDecide(\'later\')">' + T('pf.spaeter_neu_berechnen') + '</button>'+
    '<button class="btn" style="margin-top:10px" onclick="_planDecide(\'now\')">Plan jetzt neu aufbauen</button>'+
    '<p class="note" style="margin-top:8px;text-align:left">' + T('pf.neu_aufbauen_erzeugt_den_plan') + '</p>');}
/* E1 (2026-07-11, Live-Fail): „Plan jetzt anpassen" war ein NO-OP (setzte nur ein
   Flag „Vorgemerkt") — Zieländerungen erreichten den Plan nie. Jetzt baut 'now'
   den Plan real neu: gespeicherter weekPlan wird verworfen, activeWeekPlan()
   generiert aus der aktuellen Konfiguration (goalOf/effectiveTrainingConfig). */
function _planDecide(dec){
  if(dec==='now'){
    try{PROFILE.weekPlan=null;PROFILE._planUndo=null;}catch(e){}
    PROFILE.planImpact=Object.assign({},PROFILE.planImpact,{pending:false,userDecision:'rebuilt',updatedAt:new Date().toISOString()});
    saveProfile();_closeM('_planImp');
    try{if(typeof renderPlan==='function')renderPlan();else if(typeof renderWeekPlan==='function')renderWeekPlan();}catch(e){}
    if(typeof toast==='function')toast('' + T('pf.plan_neu_aufgebaut') + '');
    return;
  }
  PROFILE.planImpact=Object.assign({},PROFILE.planImpact,{pending:dec!=='keep',userDecision:dec,updatedAt:new Date().toISOString()});
  saveProfile();/* A0-Fix: save() (data.js) persistiert PROFILE nicht */_closeM('_planImp');if(typeof toast==='function')toast(dec==='keep'?'' + T('pf.plan_bleibt_unveraendert') + '':'' + T('pf.vorgemerkt_hinweis_erscheint_im_plan') + '');}

/* ============================================================
   EDITIERBARE PROFILBEREICHE (Inkrement 3): eigenständige Karten je mit „Bearbeiten",
   schema-getriebene Editoren, Unsaved-Schutz (diffState), Plan-Impact-Bündelung pro Sitzung.
   Speichert offline-first ins produktive PROFILE; unbekannte Felder bleiben erhalten.
   ============================================================ */
function _secVal(o,k){return o&&o[k]!=null?o[k]:'';}
// Generische Feldschemas (für einfache Abschnitte). Typen wie im Ziel-Wizard.
var SECTION_DEFS={
  personal:{label:'' + T('pf.persoenliche_grunddaten') + '',planImpact:false,fields:[
    {key:'name',label:'' + T('pf.name') + '',type:'text'},{key:'location',label:'Ort',type:'text'},
    /* 0029 (Phase 4 / P2-5): Handle + Bio — vorher hart '—'/Platzhalter im Profilkopf. */
    {key:'handle',label:'' + T('pf.handle_anzeigename_optional') + '',type:'text'},
    {key:'bio',label:'' + T('pf.bio_max_160_zeichen_optional') + '',type:'longtext'},
    {key:'birthDate',label:'' + T('pf.geburtsdatum') + '',type:'date'},{key:'sex',label:'Geschlecht',type:'select',optionPairs:[['m','' + T('pf.maennlich') + ''],['w','' + T('pf.weiblich') + ''],['d','' + T('pf.divers') + ''],['','' + T('pf.keine_angabe') + '']]}],
    read:function(p){return {name:p.name||'',location:p.location||'',handle:p.handle||'',bio:p.bio||'',birthDate:p.birthDate||'',sex:p.sex||''};},
    write:function(p,d){p.name=d.name;p.location=d.location;
      /* Handle-Normalisierung (Anzeige-Pseudonym, KEIN Eindeutigkeitssystem — 0029):
         fuehrendes @ ab, lowercase, nur [a-z0-9._], max. 30. Leer = bewusst kein Handle. */
      var _h=String(d.handle||'').trim().replace(/^@+/,'').toLowerCase().replace(/[^a-z0-9._]/g,'').slice(0,30);
      p.handle=_h||null;
      var _b=String(d.bio||'').trim().slice(0,160);
      p.bio=_b||null;
      p.birthDate=d.birthDate||'';p.sex=d.sex||'';}},
  /* P10: SECTION_DEFS.body ENTFERNT — dritte Feldwelt (body.restingHR); kanonisch sind flache Felder + performance (P2). */
  recovery:{label:'' + T('pf.regeneration_und_alltag') + '',planImpact:false,fields:[
    {key:'sleepHours',label:'' + T('pf.durchschnittliche_schlafdauer') + '',type:'number',unit:'h'},{key:'sleepQuality',label:'' + T('pf.schlafqualitaet') + '',type:'select',options:['schlecht','okay','gut']},
    {key:'stress',label:'Stress',type:'select',options:['niedrig','mittel','hoch']},{key:'workload',label:'' + T('pf.arbeits_schulbelastung') + '',type:'select',options:['gering','mittel','hoch']},
    {key:'shiftWork',label:'Schichtarbeit',type:'bool'},{key:'energy',label:'' + T('pf.durchschnittliches_energieniveau') + '',type:'select',options:['niedrig','mittel','hoch']},
    {key:'recoveryPrefs',label:'Regenerationspräferenzen',type:'text'},{key:'restDayPref',label:'Ruhetagpräferenz',type:'text'},{key:'nutrition',label:'' + T('pf.ernaehrungssituation_grob') + '',type:'text'}],
    read:function(p){return Object.assign({},p.recovery);},write:function(p,d){p.recovery=Object.assign({},p.recovery,d,{updatedAt:new Date().toISOString()});}},
  preferences:{label:'Trainingspräferenzen',planImpact:false,fields:[
    {key:'preferredSports',label:'' + T('pf.bevorzugte_sportarten') + '',type:'text'},{key:'dislikedForms',label:'' + T('pf.unbeliebte_trainingsformen') + '',type:'text'},
    {key:'sessionDuration',label:'' + T('pf.bevorzugte_einheitsdauer') + '',type:'select',options:['30 min','45 min','60 min','75+ min']},{key:'indoorOutdoor',label:'Indoor/Outdoor',type:'select',options:['Indoor','Outdoor','egal']},
    {key:'trainingTimes',label:'' + T('pf.trainingszeiten') + '',type:'select',options:['morgens','mittags','abends','flexibel']},{key:'intensity',label:'' + T('pf.bevorzugte_intensitaet') + '',type:'select',options:['locker','gemischt','intensiv']},
    {key:'soloGroup',label:'Solo/Gruppe',type:'select',options:['Solo','Gruppe','beides']},{key:'avoidExercises',label:'' + T('pf.zu_vermeidende_uebungen') + '',type:'text'},{key:'equipmentPlaces',label:'' + T('pf.geraete_und_trainingsorte') + '',type:'text'}],
    read:function(p){return Object.assign({},p.trainingPrefs);},write:function(p,d){p.trainingPrefs=Object.assign({},p.trainingPrefs,d,{updatedAt:new Date().toISOString()});}},
  devices:{label:'' + T('pf.geraete_und_datenquellen') + '',planImpact:false,fields:[{key:'dataSources',label:'' + T('pf.datenquellen_komma_getrennt') + '',type:'text'}],
    read:function(p){return {dataSources:(p.dataSources||[]).join(', ')};},write:function(p,d){p.dataSources=String(d.dataSources||'').split(',').map(function(s){return s.trim();}).filter(Boolean);}}
};
/* M10: Einstieg in die neue Profilzentrale — fail-soft auf den klassischen Manager. */
function openProfileCenterEntry(){
  try{
    if(window.ORVIA&&ORVIA.profileCenter&&typeof ORVIA.profileCenter.open==='function'){ORVIA.profileCenter.open();return;}
  }catch(e){}
  openProfileManager();
}
/* P1A · orviaConfirm — markenkonformer Ersatz für native confirm()-Popups.
   Nutzt das BESTEHENDE _modal-System (kein neues Overlay). opts:
   { title, text, okLabel='Bestätigen', cancelLabel='' + T('pf.abbrechen') + ''|null (null = reine Info),
     danger=false, onOk() }. Callback wird genau einmal ausgeführt. */
function orviaConfirm(opts){
  opts=opts||{};
  var fired=false;
  window._orviaConfirmOk=function(){if(fired)return;fired=true;_closeM('_ovConfirm');try{if(typeof opts.onOk==='function')opts.onOk();}catch(e){}};
  var okCls=opts.danger?'btn danger-btn':'btn';
  _modal('_ovConfirm','<h3>'+escH(opts.title||'Bestätigen')+'</h3>'+
    '<p class="modtext" style="margin:0 0 14px">'+escH(opts.text||'')+'</p>'+
    (opts.cancelLabel===null?'':'<button class="btn sec" id="ovc-cancel" onclick="_closeM(\'_ovConfirm\')">'+escH(opts.cancelLabel||'' + T('pf.abbrechen') + '')+'</button>')+
    '<button class="'+okCls+'" id="ovc-ok" style="margin-top:10px" onclick="_orviaConfirmOk()">'+escH(opts.okLabel||'Bestätigen')+'</button>');
  /* Buttons zusätzlich direkt verdrahten (robust auch ohne Inline-Handler-Auswertung). */
  try{
    var okB=document.getElementById('ovc-ok');if(okB)okB.onclick=window._orviaConfirmOk;
    var cB=document.getElementById('ovc-cancel');if(cB)cB.onclick=function(){_closeM('_ovConfirm');};
  }catch(e){}
}
function openProfileManager(){var M=pmModel();
  var cards=M.PROFILE_SECTIONS.map(function(s){return '<div class="gmcard"><div class="gmc-h">'+escH(s.label)+'</div>'+
    '<div class="gmc-acts"><button class="gmc-b" onclick="openProfileSection(\''+s.id+'\')">' + T('pf.bearbeiten') + '</button></div></div>';}).join('');
  _modal('_profMgr','<h3>' + T('pf.profil_verwalten') + '</h3>'+cards+'<button class="btn sec" style="margin-top:12px" onclick="_closeM(\'_profMgr\')">' + T('pf.schliessen') + '</button>');}
function openProfileSection(id){
  if(id==='goals'){_closeM('_profMgr');openGoalsManager();return;}
  if(id==='sports'){openSportsManager();return;}
  if(id==='availability'){openAvailabilityEditor();return;}
  if(id==='constraints'){openConstraintsEditor();return;}
  if(id==='body'){openPerformanceManager();return;}
  if(id==='recovery'){openRecoveryEditor();return;}
  if(id==='preferences'){openPreferencesEditor();return;}
  if(id==='devices'){openDevicesManager();return;}
  var def=SECTION_DEFS[id];if(!def)return;
  var data=def.read(PROFILE)||{};
  window._secEd={id:id,orig:JSON.stringify(data),data:JSON.parse(JSON.stringify(data))};
  var fieldsHTML=def.fields.map(function(f){return _gwField(f,window._secEd.data);}).join('');
  _modal('_secEdM','<h3>'+escH(def.label)+'</h3>'+fieldsHTML+
    '<button class="btn" onclick="saveProfileSection()">' + T('pf.speichern') + '</button>'+
    '<button class="btn sec" style="margin-top:10px" onclick="cancelProfileSection()">' + T('pf.abbrechen') + '</button>');}
function _secCollect(){var def=SECTION_DEFS[window._secEd.id];var d=window._secEd.data;
  def.fields.forEach(function(f){if(f.type==='select'){var sv=_segVal('gwf_'+f.key);if(sv!=null)d[f.key]=sv;return;}var e=document.getElementById('gwf_'+f.key);if(!e)return;
    if(f.type==='bool')d[f.key]=e.checked;else if(f.type==='number')d[f.key]=e.value===''?null:(isNaN(parseFloat(e.value.replace(',','.')))?e.value:parseFloat(e.value.replace(',','.')));else d[f.key]=e.value;});}
function cancelProfileSection(){_secCollect();var S=window._secEd;
  if(pmModel().diffState(JSON.parse(S.orig),S.data)){
    _modal('_secDiscard','<h3>' + T('pf.aenderungen_verwerfen') + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.deine_letzten_anpassungen_wurden_noch') + '</p>'+
      '<button class="btn sec" onclick="_closeM(\'_secDiscard\')">' + T('pf.weiter') + ' bearbeiten</button>'+
      '<button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_secDiscard\');_closeM(\'_secEd\')">' + T('pf.aenderungen_verwerfen_btn') + '</button>');
  }else _closeM('_secEdM');}
function saveProfileSection(){_secCollect();var def=SECTION_DEFS[window._secEd.id];def.write(PROFILE,window._secEd.data);
  _profileSave([window._secEd.id]);
  if(def.planImpact)maybePlanImpact(window._secEd.id,[window._secEd.id]);
  _closeM('_secEdM');try{renderProfileScreen();}catch(e){}if(typeof toast==='function')toast('Gespeichert');}

/* ============================================================
   Profil-Completion-Fixpaket (2026-07-09): Fehlt-Hinweis + kanonischer Merge.
   ============================================================ */
/* Fehlt-Hinweis für Essential-Editoren: nennt fehlende Angaben KONKRET.
   Benennung ausschließlich aus profileModel.ESSENTIAL_FIELD_LABELS (eine Quelle). */
function _missingHintHTML(sectionId){try{var M=pmModel();var c=M.computeSectionCompleteness(PROFILE,sectionId);
  if(!c||c.complete||!c.missing.length)return '';
  var L=M.ESSENTIAL_FIELD_LABELS||{};
  return '<p class="ob2-err gm-missing-hint" role="alert">Fehlende Angaben: '+c.missing.map(function(k){return escH(L[k]||k);}).join(' · ')+'</p>';}catch(e){return '';}}
/* Pur: Sportprofil-Save schreibt zusätzlich die KANONISCHEN Trainingsstand-Felder
   (level/sessionsPerWeek/typicalDuration am Sport-Eintrag — dieselben Felder, die
   ESSENTIAL_REQUIREMENTS.sports prüft und 2B-① nach user_sports synct). Leere
   Eingaben degradieren Bestandswerte nie; das Eingabeobjekt wird nicht mutiert. */
function _sppMergeSport(s,role,sp,canon){var M=pmModel();canon=canon||{};
  var out=Object.assign({},s,{role:role,sportProfile:M.normalizeSportProfile(s.sportId,sp||{})});
  if(canon.level!=null&&canon.level!=='')out.level=canon.level;
  if(canon.sessionsPerWeek!=null&&canon.sessionsPerWeek!=='')out.sessionsPerWeek=canon.sessionsPerWeek;
  if(canon.typicalDuration!=null&&canon.typicalDuration!=='')out.typicalDuration=canon.typicalDuration;
  return out;}
/* Kit-Level-Codes kanonisch (onboarding-sports-logic.TRAINING_LEVELS); Labels sind UI-Adapter. */
var SPP_LEVEL_DE={beginner:'' + T('pf.anfaenger') + '',intermediate:'' + T('pf.fortgeschritten') + '',advanced:'' + T('pf.erfahren') + '',competitive:'' + T('pf.wettkampforientiert') + ''};
function _sppLevels(){var codes=['beginner','intermediate','advanced','competitive'];
  try{if(window.ORVIA&&ORVIA.onboardingSportsLogic&&Array.isArray(ORVIA.onboardingSportsLogic.TRAINING_LEVELS))codes=ORVIA.onboardingSportsLogic.TRAINING_LEVELS;}catch(e){}
  return codes.map(function(c){return [c,SPP_LEVEL_DE[c]||c];});}

/* Sportarten bearbeiten (Mehrfachauswahl aus Trainings-Katalog, vorhandene vorausgefüllt). */
function _sportCatalog(){try{if(window.ORVIA&&ORVIA.trainingDomain&&ORVIA.trainingDomain.listSports)return ORVIA.trainingDomain.listSports().map(function(s){return {id:s.id,label:s.label||s.id};});}catch(e){}
  return ['running','cycling','swimming','gym','football','triathlon','handball','tennis','padel','athletics'].map(function(s){return {id:s,label:s};});}
function openSportsEditor(){var cat=_sportCatalog();var cur=(PROFILE.sports||[]).map(function(s){return typeof s==='string'?s:(s.sportId||s.customName);});
  window._secEd={id:'sports',orig:JSON.stringify(cur.slice().sort()),data:cur.slice()};
  _modal('_secEdM','<h3>' + T('pf.sportarten') + '</h3><div class="gm-chips" id="sp_chips">'+cat.map(function(s){return '<button type="button" class="gm-chip'+(cur.indexOf(s.id)>=0?' on':'')+'" data-v="'+escH(s.id)+'" onclick="gmToggle(this)">'+escH(s.label)+'</button>';}).join('')+'</div>'+
    '<button class="btn" onclick="saveSportsEditor()">' + T('pf.speichern') + '</button><button class="btn sec" style="margin-top:10px" onclick="cancelSportsEditor()">' + T('pf.abbrechen') + '</button>');}
function _spCollect(){var c=document.getElementById('sp_chips');return c?Array.prototype.slice.call(c.querySelectorAll('.on')).map(function(b){return b.dataset.v;}):[];}
function cancelSportsEditor(){var sel=_spCollect();if(pmModel().diffState(JSON.parse(window._secEd.orig),sel.slice().sort())){
    _modal('_secDiscard','<h3>' + T('pf.aenderungen_verwerfen') + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.deine_letzten_anpassungen_wurden_noch') + '</p>'+
      '<button class="btn sec" onclick="_closeM(\'_secDiscard\')">' + T('pf.weiter') + ' bearbeiten</button>'+
      '<button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_secDiscard\');_closeM(\'_secEd\')">' + T('pf.aenderungen_verwerfen_btn') + '</button>');
  }else _closeM('_secEdM');}
function saveSportsEditor(){var M=pmModel();var sel=_spCollect();
  // Bestehende Sport-Flags (activeInApp/includeInPlan/role…) erhalten, fehlende neu anlegen, dann normalisieren.
  var existing={};(M.normalizeSports(PROFILE.sports)||[]).forEach(function(s){existing[String(s.sportId).toLowerCase()]=s;});
  PROFILE.sports=M.normalizeSports(sel.map(function(id){return existing[String(id).toLowerCase()]||{sportId:id};}));
  _profileSave(['sports']);maybePlanImpact('sports',['sports']);
  _closeM('_secEdM');try{renderProfileScreen();}catch(e){}if(typeof toast==='function')toast('' + T('pf.sportarten_gespeichert') + '');}

/* ============================================================
   SPORTARTEN-MANAGER + sportartspezifischer Profil-Editor (Inkrement 4c).
   Schema-getrieben aus ORVIA.profileModel.SPORT_PROFILE_SCHEMAS. ORVIA-Komponenten, keine Selects.
   ============================================================ */
var SPORT_ROLE_DE={primary:'Hauptsportart',secondary:'Nebensportart',supplemental:'Ergänzend',occasional:'' + T('pf.gelegentlich') + ''};
function _sportLabel(s){var M=pmModel();var sc=M.sportProfileSchema(s.sportId);return s.customName||(sc&&sc.label)||s.sportId;}
function _sportCardSummary(s){var M=pmModel();var sp=s.sportProfile;if(!sp)return '';var bits=[];
  var sc=M.sportProfileSchema(s.sportId);
  if(sp.primaryPosition&&sc){var pos=(sc.positions||[]).filter(function(p){return p[0]===sp.primaryPosition;})[0];if(pos)bits.push(pos[1]);
    var role=M.rolesForPosition(s.sportId,sp.primaryPosition).filter(function(r){return r[0]===sp.playingRole;})[0];if(role)bits.push(role[1]);else if(sp.customRole)bits.push(sp.customRole);}
  if(sp.teamSessionsPerWeek)bits.push(sp.teamSessionsPerWeek+'' + T('pf.teamtrainings') + '');
  if(sp.matchDay){var md={monday:'' + T('pf.mo') + '',tuesday:'' + T('pf.di') + '',wednesday:'' + T('pf.mi') + '',thursday:'' + T('pf.do') + '',friday:'' + T('pf.fr') + '',saturday:'' + T('pf.sa') + '',sunday:'' + T('pf.so') + '',varies:'wechselnd'}[sp.matchDay]||sp.matchDay;bits.push('' + T('pf.spiel') + ''+md);}
  var fl=sp.fields||{};
  if(fl.variant)bits.unshift(fl.variant);
  if(s.sportId==='gym'){if(fl.goal)bits.push(fl.goal);if(fl.split)bits.push(fl.split);
    if(Array.isArray(fl.linkedSports)&&fl.linkedSports.length){var ls=fl.linkedSports.map(function(id){var sc2=pmModel().sportProfileSchema(id);return (sc2&&sc2.label)||id;});bits.push('' + T('pf.fuer') + ''+ls.join(T('pf.und_sep')));}}
  if(s.sportId==='hyrox'){if(fl.category)bits.push(fl.category);if(fl.level)bits.push(fl.level);if(fl.targetTime)bits.push('' + T('pf.zielzeit') + ''+fl.targetTime);
    if(fl.weakestStation)bits.push('' + T('pf.schwaechste_station') + ''+fl.weakestStation);}
  return bits.length?'<div class="gmc-meta">'+escH(bits.join(' · '))+'</div>':'';}
function openSportsManager(){var M=pmModel();var sports=M.normalizeSports(PROFILE.sports);
  var cards=sports.length?sports.map(function(s){return '<div class="gmcard"><div class="gmc-h">'+escH(_sportLabel(s))+'</div>'+
    '<div class="gmc-meta">'+escH(SPORT_ROLE_DE[s.role]||'Ergänzend')+(s.activeInApp?'' + T('pf.in_app_sichtbar') + '':'')+(s.includeInPlan?'' + T('pf.in_planung') + '':'')+'</div>'+
    _sportCardSummary(s)+
    '<div class="gmc-acts">'+(M.sportProfileSchema(s.sportId)?'<button class="gmc-b" onclick="openSportProfileEditor(\''+escH(s.sportId)+'\')">' + T('pf.profil_bearbeiten') + '</button>':'<span class="gmc-meta">' + T('pf.kein_spezialprofil_fuer_diese_sportart') + '</span>')+'</div></div>';}).join(''):'<p class="note" style="text-align:left">' + T('pf.noch_keine_sportarten_gewaehlt') + '</p>';
  _modal('_sportMgr','<h3>' + T('pf.sportarten') + '</h3>'+cards+
    '<button class="btn sec" style="margin-top:12px" onclick="openSportsEditor()">' + T('pf.sportarten_auswaehlen') + '</button>'+
    '<button class="btn sec" style="margin-top:8px" onclick="_closeM(\'_sportMgr\')">' + T('pf.schliessen') + '</button>');}

function _sppField(f,vals){var id='spp_'+f[0];var v=vals[f[0]];var type=f[2];var lab='<label>'+escH(f[1])+(f[3]&&typeof f[3]==='string'?' ('+escH(f[3])+')':'')+'</label>';
  if(f[0]==='linkedSports'){ // Mehrfachauswahl aus aktiven Profilsportarten (ohne gym selbst). Kein Freitext.
    var act=(window.ORVIA&&ORVIA.profile&&ORVIA.profile.activeSports)?ORVIA.profile.activeSports().filter(function(s){return s.sportId!=='gym';}):[];
    var sel=Array.isArray(v)?v:[];
    if(!act.length)return '<div class="gm-field">'+lab+'<p class="note" style="text-align:left">' + T('pf.keine_weiteren_aktiven_sportarten_vorhanden') + '</p></div>';
    return '<div class="gm-field">'+lab+'<div class="gm-chips" id="'+id+'">'+act.map(function(s){var name=s.customName||_sportLabel(s);return '<button type="button" class="gm-chip'+(sel.indexOf(s.sportId)>=0?' on':'')+'" data-v="'+escH(s.sportId)+'" onclick="gmToggle(this)">'+escH(name)+'</button>';}).join('')+'</div></div>';}
  if(type==='bool')return '<div class="gm-field gm-inline"><input type="checkbox" id="'+id+'"'+(v?' checked':'')+'>'+lab+'</div>';
  if(type==='select')return '<div class="gm-field">'+lab+segHTML(id,(f[3]||[]).map(function(o){return [o,o];}),v)+'</div>';
  var t=type==='number'?'number':'text';
  return '<div class="gm-field">'+lab+'<input type="'+t+'" id="'+id+'" value="'+escH(v!=null?v:'')+'"></div>';}
function openSportProfileEditor(sportId){var M=pmModel();var sc=M.sportProfileSchema(sportId);if(!sc)return;
  var sports=M.normalizeSports(PROFILE.sports);var s=sports.filter(function(x){return x.sportId===sportId;})[0];if(!s)return;
  var sp=s.sportProfile||M.normalizeSportProfile(sportId,{});
  window._sppEd={sportId:sportId,role:s.role,orig:JSON.stringify({role:s.role,sp:sp,canon:{level:s.level||null,sessionsPerWeek:s.sessionsPerWeek!=null?s.sessionsPerWeek:null,typicalDuration:s.typicalDuration!=null?s.typicalDuration:null}}),sp:JSON.parse(JSON.stringify(sp)),
    canon:{level:s.level||null,sessionsPerWeek:s.sessionsPerWeek!=null?s.sessionsPerWeek:null,typicalDuration:s.typicalDuration!=null?s.typicalDuration:null}};
  openSheet({id:'_sppEdM',title:escH(sc.label+'' + T('pf.profil_') + ''),onClose:cancelSportProfileEditor,body:'<div id="sppBody"></div>',
    actions:'<button class="btn" onclick="saveSportProfileEditor()">' + T('pf.speichern') + '</button><button class="btn sec" onclick="cancelSportProfileEditor()">' + T('pf.abbrechen') + '</button>'});renderSportProfileEditor();}
function renderSportProfileEditor(){var M=pmModel();var E=window._sppEd;var sc=M.sportProfileSchema(E.sportId);var sp=E.sp;var box=document.getElementById('sppBody');if(!box)return;
  var html='';
  // Fehlt-Führung (Completion-Fixpaket): fehlende Essential-Angaben konkret benennen + markieren.
  var _miss={};if(E.role==='primary'){try{M.computeSectionCompleteness(PROFILE,'sports').missing.forEach(function(k){_miss[k]=1;});}catch(e){}}
  html+=_missingHintHTML('sports');
  // Rolle & Trainingsstand (kanonisch — dieselben Felder wie Onboarding/Completion/Cloud-Sync)
  html+='<div class="gm-field"><label>' + T('pf.rolle_dieser_sportart') + '</label>'+segHTML('spp_sportrole',[['primary','Hauptsportart'],['secondary','Nebensportart'],['supplemental','Ergänzend'],['occasional','' + T('pf.gelegentlich') + '']],E.role)+'</div>';
  html+='<div class="gm-field'+(_miss.primary_level?' gm-miss':'')+'"><label>Trainingsniveau</label>'+segHTML('spp_canlevel',_sppLevels(),E.canon.level)+'</div>';
  html+='<div class="row2"><div class="gm-field'+(_miss.primary_sessions_per_week?' gm-miss':'')+'"><label>' + T('pf.einheiten_pro_woche') + '</label><input type="number" id="spp_spw" min="0" max="14" value="'+(E.canon.sessionsPerWeek!=null?E.canon.sessionsPerWeek:'')+'"></div>'+
    '<div class="gm-field'+(_miss.primary_typical_duration?' gm-miss':'')+'"><label>' + T('pf.typische_dauer_min') + '</label><input type="number" id="spp_dur" min="0" max="600" value="'+(E.canon.typicalDuration!=null?E.canon.typicalDuration:'')+'"></div></div>';
  html+='<div class="gm-field"><label>' + T('pf.wettkampfeinstufung_optional') + '</label>'+segHTML('spp_level',M.LEVELS,sp.competitionLevel)+'</div>';
  if(sc.type==='team'){
    html+='<p class="note" style="text-align:left">' + T('pf.wie_nutzt_orvia_das_position') + '</p>';
    if(sc.variants){html+='<div class="gm-field"><label>' + T('pf.variante') + '</label>'+segHTML('spp_variant',sc.variants.map(function(v){return [v,v];}),sp.fields&&sp.fields.variant||sc.variants[0],'sppVariantChange')+'</div>';}
    var posList=sc.variants?M.positionsForVariant(E.sportId,(sp.fields&&sp.fields.variant)||sc.variants[0]):sc.positions;
    html+='<div id="spp_posWrap"><div class="gm-field"><label>' + T('pf.hauptposition') + '</label>'+segHTML('spp_pos',posList,sp.primaryPosition,'sppPosChange')+'</div>'+
      (sp._variantHint?'<p class="ob2-err" role="alert">' + T('pf.bitte_position_fuer_die_neue') + '</p>':'')+'<div id="spp_roleWrap">'+_sppRoleHTML()+'</div></div>';
    var others=posList.filter(function(p){return ['multi_position','custom'].indexOf(p[0])<0;});
    html+='<div class="gm-field"><label>' + T('pf.weitere_positionen_optional') + '</label><div class="gm-chips" id="spp_secpos">'+others.map(function(p){return '<button type="button" class="gm-chip'+(sp.secondaryPositions.indexOf(p[0])>=0?' on':'')+'" data-v="'+p[0]+'" onclick="gmToggle(this)">'+escH(p[1])+'</button>';}).join('')+'</div></div>';
    html+='<div class="row2"><div class="gm-field"><label>' + T('pf.teamtrainings_woche') + '</label><input type="number" id="spp_team" value="'+(sp.teamSessionsPerWeek!=null?sp.teamSessionsPerWeek:'')+'"></div>'+
      '<div class="gm-field"><label>' + T('pf.einsatzminuten') + '</label><input type="number" id="spp_min" value="'+(sp.typicalMatchMinutes!=null?sp.typicalMatchMinutes:'')+'"></div></div>';
    html+='<div class="gm-field"><label>' + T('pf.spieltag') + '</label>'+segHTML('spp_matchday',[['monday','' + T('pf.mo') + ''],['tuesday','' + T('pf.di') + ''],['wednesday','' + T('pf.mi') + ''],['thursday','' + T('pf.do') + ''],['friday','' + T('pf.fr') + ''],['saturday','' + T('pf.sa') + ''],['sunday','' + T('pf.so') + ''],['varies','wechselnd']],sp.matchDay)+'</div>';
    html+='<div class="gm-field"><label>' + T('pf.einsatz') + '</label>'+segHTML('spp_lineup',[['starter','Startelf'],['sub','Einwechselspieler'],['varies','wechselnd']],sp.lineupStatus)+'</div>';
    html+='<div class="gm-field"><label>' + T('pf.saisonphase') + '</label>'+segHTML('spp_season',M.SEASON_PHASES,sp.seasonPhase)+'</div>';
    html+='<div class="gm-field"><label>' + T('pf.zusaetzliche_eigene_einheiten_woche') + '</label><input type="number" id="spp_extra" value="'+(sp.extraSessions!=null?sp.extraSessions:'')+'"></div>';
  } else {
    html+=(sc.fields||[]).map(function(f){return _sppField(f,sp.fields);}).join('');
  }
  // Leistungsziele (Mehrfachauswahl)
  var areas=M.performanceAreasFor(E.sportId);
  if(areas.length){var selKeys=sp.performancePriorities.map(function(p){return p.key;});
    html+='<p class="note" style="text-align:left">' + T('pf.leistungsziele_beeinflussen_spaeter_die_trainingsgewichtung') + '</p>';
    html+='<div class="gm-field"><label>' + T('pf.leistungsziele') + '</label><div class="gm-chips" id="spp_perf">'+areas.map(function(a){return '<button type="button" class="gm-chip'+(selKeys.indexOf(a[0])>=0?' on':'')+'" data-v="'+a[0]+'" onclick="gmToggle(this)">'+escH(a[1])+'</button>';}).join('')+'</div></div>';}
  // Beschwerden-Verknüpfung (aus zentralen aktiven Beschwerden)
  var ac=(window.ORVIA&&ORVIA.profile&&ORVIA.profile.activeConstraints)?ORVIA.profile.activeConstraints():[];
  if(ac.length){html+='<div class="gm-field"><label>' + T('pf.relevante_beschwerden') + '</label><div class="gm-chips" id="spp_constr">'+ac.map(function(c){var k=c.bodyRegion||c.title;return '<button type="button" class="gm-chip'+(sp.constraints.indexOf(k)>=0?' on':'')+'" data-v="'+escH(k)+'" onclick="gmToggle(this)">'+escH(c.title||c.bodyRegion)+'</button>';}).join('')+'</div></div>';}
  box.innerHTML=html;
  // Führung: erstes fehlendes Feld sichtbar machen (Completion-Fixpaket).
  try{var _m1=box.querySelector('.gm-miss');if(_m1&&_m1.scrollIntoView)_m1.scrollIntoView({block:'center'});}catch(e){}}
function _sppRoleHTML(){var M=pmModel();var E=window._sppEd;var pos=E.sp.primaryPosition;var roles=pos?M.rolesForPosition(E.sportId,pos):[];
  if(!roles.length)return '';
  if(pos==='custom'||pos==='multi_position')return '<div class="gm-field"><label>' + T('pf.eigene_rolle') + '</label><input id="spp_customrole" value="'+escH(E.sp.customRole||'')+'"></div>';
  return '<div class="gm-field"><label>' + T('pf.spielrolle') + '</label>'+segHTML('spp_role',roles,E.sp.playingRole)+'</div>';}
function sppPosChange(){_sppCollectInto(window._sppEd.sp);window._sppEd.sp._variantHint=false;var w=document.getElementById('spp_roleWrap');if(w)w.innerHTML=_sppRoleHTML();}
// Variantenwechsel (Volleyball/Hockey): kompatible Werte erhalten, inkompatible Position neu wählen lassen.
function sppVariantChange(){var M=pmModel();var E=window._sppEd;_sppCollectInto(E.sp);
  var variant=_segVal('spp_variant');E.sp.fields=E.sp.fields||{};E.sp.fields.variant=variant;
  var valid=M.positionsForVariant(E.sportId,variant).map(function(p){return p[0];});
  if(E.sp.primaryPosition&&valid.indexOf(E.sp.primaryPosition)<0){E.sp.primaryPosition=null;E.sp.playingRole=null;E.sp._variantHint=true;}else E.sp._variantHint=false;
  renderSportProfileEditor();}
function _sppCollectInto(sp){var M=pmModel();var sc=M.sportProfileSchema(window._sppEd.sportId);
  function v(id){var e=document.getElementById(id);return e?e.value:undefined;}
  function n(id){var x=v(id);return x===undefined||x===''?null:(isNaN(parseFloat(x))?x:parseFloat(x));}
  function chips(id){var c=document.getElementById(id);return c?Array.prototype.slice.call(c.querySelectorAll('.on')).map(function(b){return b.dataset.v;}):null;}
  window._sppEd.role=_segVal('spp_sportrole')||window._sppEd.role;
  sp.competitionLevel=_segVal('spp_level')||sp.competitionLevel;
  if(sc.type==='team'){
    if(sc.variants){var vv=_segVal('spp_variant');if(vv!=null&&vv!==''){sp.fields=sp.fields||{};sp.fields.variant=vv;}}
    var ps=_segVal('spp_pos');if(ps!=null&&ps!=='')sp.primaryPosition=ps;
    var r=_segVal('spp_role');if(r!=null&&r!=='')sp.playingRole=r;
    var cr=v('spp_customrole');if(cr!=null)sp.customRole=cr;
    var sec=chips('spp_secpos');if(sec)sp.secondaryPositions=sec;
    sp.teamSessionsPerWeek=n('spp_team');sp.typicalMatchMinutes=n('spp_min');sp.extraSessions=n('spp_extra');
    var md=_segVal('spp_matchday');if(md!=null&&md!=='')sp.matchDay=md;
    var lu=_segVal('spp_lineup');if(lu!=null&&lu!=='')sp.lineupStatus=lu;
    var se=_segVal('spp_season');if(se!=null&&se!=='')sp.seasonPhase=se;
  } else {
    (sc.fields||[]).forEach(function(f){var id='spp_'+f[0];if(f[2]==='bool'){var e=document.getElementById(id);if(e)sp.fields[f[0]]=e.checked;}
      else if(f[2]==='select'){var sv=_segVal(id);if(sv!=null)sp.fields[f[0]]=sv;}
      else if(f[0]==='linkedSports'){var lc=chips(id);if(lc)sp.fields.linkedSports=lc;}
      else if(f[2]==='number'){sp.fields[f[0]]=n(id);}else{var tv=v(id);if(tv!=null)sp.fields[f[0]]=tv;}});
  }
  var perf=chips('spp_perf');if(perf){var existing={};sp.performancePriorities.forEach(function(p){existing[p.key]=p;});
    sp.performancePriorities=perf.map(function(k){return existing[k]||{key:k,priority:2,currentLevel:null,targetLevel:null};});}
  var con=chips('spp_constr');if(con)sp.constraints=con;
  // kanonischer Trainingsstand (leere Eingaben lassen Bestandswerte unangetastet)
  var E2=window._sppEd;if(E2&&E2.canon){var cl=_segVal('spp_canlevel');if(cl!=null&&cl!=='')E2.canon.level=cl;
    var spwEl=document.getElementById('spp_spw');if(spwEl&&spwEl.value!==''&&!isNaN(parseInt(spwEl.value,10)))E2.canon.sessionsPerWeek=parseInt(spwEl.value,10);
    var durEl=document.getElementById('spp_dur');if(durEl&&durEl.value!==''&&!isNaN(parseInt(durEl.value,10)))E2.canon.typicalDuration=parseInt(durEl.value,10);}
  return sp;}
function saveSportProfileEditor(){var M=pmModel();var E=window._sppEd;_sppCollectInto(E.sp);
  var sports=M.normalizeSports(PROFILE.sports);
  // linkedSports gegen aktive Sportarten validieren (deaktivierte/gelöschte entfernen).
  if(E.sp.fields&&E.sp.fields.linkedSports){var actIds=sports.filter(function(s){return s.activeInApp&&s.sportId!=='gym';}).map(function(s){return s.sportId;});E.sp.fields.linkedSports=M.filterLinkedSports(E.sp.fields.linkedSports,actIds);}
  PROFILE.sports=sports.map(function(s){if(s.sportId!==E.sportId)return s;return _sppMergeSport(s,E.role,E.sp,E.canon);});
  _profileSave(['sports']);maybePlanImpact('sports',['sports']);
  _closeM('_sppEdM');try{if(window._sportMgr)openSportsManager();}catch(e){}if(typeof toast==='function')toast('' + T('pf.sportprofil_gespeichert') + '');}
function cancelSportProfileEditor(){var E=window._sppEd;_sppCollectInto(E.sp);
  if(pmModel().diffState(JSON.parse(E.orig),{role:E.role,sp:E.sp,canon:E.canon})){
    _modal('_sppDiscard','<h3>' + T('pf.aenderungen_verwerfen') + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.deine_letzten_anpassungen_wurden_noch') + '</p>'+
      '<button class="btn sec" onclick="_closeM(\'_sppDiscard\')">' + T('pf.weiter') + ' bearbeiten</button>'+
      '<button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_sppDiscard\');_closeM(\'_sppEdM\')">' + T('pf.aenderungen_verwerfen_btn') + '</button>');
  }else _closeM('_sppEdM');}

/* Trainingsverfügbarkeit bearbeiten (pro Wochentag + Wochenlimits). */
var WD_DE={mo:'' + T('pf.mo') + '',di:'' + T('pf.di') + '',mi:'' + T('pf.mi') + '',do:'' + T('pf.do') + '',fr:'' + T('pf.fr') + '',sa:'' + T('pf.sa') + '',so:'' + T('pf.so') + ''};
var AV_TIMES=[['','—'],['morning','Morgens'],['noon','Mittags'],['afternoon','Nachmittags'],['evening','Abends'],['flexible','Flexibel']];
var AV_INTENS=[['easy','' + T('pf.nur_locker') + ''],['moderate','' + T('pf.moderat_moeglich') + ''],['intense','' + T('pf.intensiv_moeglich') + '']];
var AV_FIX_DE={team_training:'Mannschaftstraining',match:'Spiel',fixed_session:'' + T('pf.feste_trainingseinheit') + '',work_school:'Arbeit/Schule',appointment:'Termin',other_load:'' + T('pf.sonstige_belastung') + ''};
function _avSports(){return (window.ORVIA&&ORVIA.profile&&ORVIA.profile.activeSports)?ORVIA.profile.activeSports():[];}
function _avTimeLabel(t){var p=AV_TIMES.filter(function(x){return x[0]===t;})[0];return p?p[1]:'';}
function openAvailabilityEditor(){var M=pmModel();var av=M.normalizeAvailability(PROFILE.availability);
  window._avEd={orig:JSON.stringify(av),av:JSON.parse(JSON.stringify(av)),open:{}};
  openSheet({id:'_secEdM',title:'Trainingsverfügbarkeit',onClose:cancelAvailabilityEditor,body:'<div id="avBody"></div>',
    actions:'<button class="btn" onclick="saveAvailabilityEditor()">' + T('pf.speichern') + '</button><button class="btn sec" onclick="cancelAvailabilityEditor()">' + T('pf.abbrechen') + '</button>'});renderAvailabilityEditor();}
function _avSlotHTML(d,idx,slot,sports){var p='av_'+d+'_'+idx+'_';
  return '<div class="gm-field"><label>' + T('pf.tageszeit') + '</label>'+segHTML(p+'time',AV_TIMES,slot.preferredTime||'')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.maximale_dauer_min') + '</label><input type="number" id="'+p+'min" value="'+(slot.maxMinutes!=null?slot.maxMinutes:'')+'"></div>'+
    (sports.length?'<div class="gm-field"><label>' + T('pf.bevorzugte_sportarten') + '</label><div class="gm-chips" id="'+p+'sp">'+sports.map(function(s){return '<button type="button" class="gm-chip'+(slot.preferredSports.indexOf(s.sportId)>=0?' on':'')+'" data-v="'+escH(s.sportId)+'" onclick="gmToggle(this)">'+escH(s.customName||_sportLabel(s))+'</button>';}).join('')+'</div></div>':'')+
    '<div class="gm-field"><label>' + T('pf.intensitaet__') + '</label>'+segHTML(p+'int',AV_INTENS,slot.intensityAllowed||'moderate')+'</div>';}
function renderAvailabilityEditor(){var M=pmModel();var E=window._avEd;var av=E.av;var box=document.getElementById('avBody');if(!box)return;var sports=_avSports();
  var cards=M.WEEKDAYS.map(function(d){var w=av.days[d];var open=E.open[d];
    if(!open){var sum=[];if(w.restDay)sum.push('Ruhetag');else if(!w.available)sum.push('' + T('pf.nicht_verfuegbar_') + '');else{sum.push('Verfügbar');
      if(w.doubleSession.enabled)sum.push('' + T('pf.2_einheiten') + '');var t1=_avTimeLabel(w.singleSession.preferredTime);if(!w.doubleSession.enabled&&t1)sum.push(t1);}
      if(w.fixedCommitments.length)sum.push(w.fixedCommitments.length+' feste');
      return '<div class="gmcard"><div class="gmc-h">'+WD_DE[d]+'</div><div class="gmc-meta">'+escH(sum.join(' · '))+'</div>'+
        '<div class="gmc-acts"><button class="gmc-b" onclick="avToggleOpen(\''+d+'\')">Weitere Einstellungen</button></div></div>';}
    var body='<div class="gmcard"><div class="gmc-h">'+WD_DE[d]+'</div>'+
      '<div class="gm-field gm-inline"><input type="checkbox" id="av_'+d+'_av"'+(w.available?' checked':'')+' onclick="avFlag(\''+d+'\')"><label>Verfügbar</label></div>'+
      '<div class="gm-field gm-inline"><input type="checkbox" id="av_'+d+'_rest"'+(w.restDay?' checked':'')+' onclick="avFlag(\''+d+'\')"><label>Als Ruhetag festlegen</label></div>';
    if(!w.restDay&&w.available){
      body+='<div class="gm-field gm-inline"><input type="checkbox" id="av_'+d+'_dbl"'+(w.doubleSession.enabled?' checked':'')+' onclick="avFlag(\''+d+'\')"><label>' + T('pf.doppeleinheit_moeglich') + '</label></div>';
      if(w.doubleSession.enabled){
        body+='<div class="gm-sec">' + T('pf.einheit_1') + '</div>'+_avSlotHTML(d,'0',w.doubleSession.sessions[0],sports)+'<div class="gm-sec">' + T('pf.einheit_2') + '</div>'+_avSlotHTML(d,'1',w.doubleSession.sessions[1],sports);
        if(w.doubleSession.sessions[0].preferredTime&&w.doubleSession.sessions[0].preferredTime===w.doubleSession.sessions[1].preferredTime)body+='<p class="ob2-err" role="alert">' + T('pf.beide_einheiten_haben_dieselbe_tageszeit') + '</p>';
      } else body+='<div class="gm-sec">' + T('pf.einheit') + '</div>'+_avSlotHTML(d,'s',w.singleSession,sports);
    }
    body+='<div class="gm-sec">' + T('pf.feste_verpflichtungen') + '</div>'+w.fixedCommitments.map(function(c){return _avFixHTML(d,c,sports);}).join('')+
      '<button class="gmc-b" onclick="avAddFixed(\''+d+'\')">' + T('pf.feste_verpflichtung_hinzufuegen') + '</button>';
    body+='<div class="gmc-acts" style="margin-top:8px"><button class="gmc-b" onclick="avToggleOpen(\''+d+'\')">' + T('pf.schliessen') + '</button></div></div>';
    return body;}).join('');
  box.innerHTML=_missingHintHTML('availability')+cards+
    '<div class="gm-sec">' + T('pf.wochenlimits') + '</div><p class="note" style="text-align:left">' + T('pf.orvia_nutzt_diese_grenzen_spaeter') + '</p>'+
    '<div class="row2"><div class="gm-field"><label>' + T('pf.max_einheiten_woche') + '</label><input type="number" id="av_maxS" value="'+(av.maxSessionsPerWeek!=null?av.maxSessionsPerWeek:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.max_intensive_einheiten') + '</label><input type="number" id="av_maxI" value="'+(av.maxIntenseSessions!=null?av.maxIntenseSessions:'')+'"></div></div>'+
    '<div class="gm-field"><label>' + T('pf.min_vollstaendige_ruhetage') + '</label><input type="number" id="av_minRest" value="'+(av.minimumFullRestDays!=null?av.minimumFullRestDays:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.bevorzugte_ruhetage') + '</label><div class="gm-chips" id="av_prefRest">'+M.WEEKDAYS.map(function(d){return '<button type="button" class="gm-chip'+(av.preferredRestDays.indexOf(d)>=0?' on':'')+'" data-v="'+d+'" onclick="gmToggle(this)">'+WD_DE[d]+'</button>';}).join('')+'</div></div>';}
function _avFixHTML(d,c,sports){var p='av_'+d+'_fix_'+c.id+'_';var types=Object.keys(AV_FIX_DE).map(function(k){return [k,AV_FIX_DE[k]];});
  return '<div class="gmcard" style="margin:6px 0"><div class="gm-field"><label>' + T('pf.typ') + '</label>'+segHTML(p+'type',types,c.type)+'</div>'+
    (sports.length?'<div class="gm-field"><label>' + T('pf.sportart_optional') + '</label>'+segHTML(p+'sport',[['','—']].concat(sports.map(function(s){return [s.sportId,s.customName||_sportLabel(s)];})),c.sportId||'')+'</div>':'')+
    '<div class="row2"><div class="gm-field"><label>' + T('pf.startzeit') + '</label><input type="time" id="'+p+'start" value="'+escH(c.startTime||'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.dauer_min') + '</label><input type="number" id="'+p+'dur" value="'+(c.durationMinutes!=null?c.durationMinutes:'')+'"></div></div>'+
    '<div class="gm-field"><label>' + T('pf.intensitaet__') + '</label>'+segHTML(p+'int',AV_INTENS,c.intensity||'moderate')+'</div>'+
    '<button class="gmc-b danger-btn" onclick="avDelFixed(\''+d+'\',\''+c.id+'\')">' + T('pf.entfernen') + '</button></div>';}
function _avSlotCollect(d,idx){var p='av_'+d+'_'+idx+'_';function n(id){var e=document.getElementById(id);return e&&e.value!==''?parseInt(e.value,10):null;}
  var c=document.getElementById(p+'sp');return {preferredTime:_segVal(p+'time')||'',maxMinutes:n(p+'min'),preferredSports:c?Array.prototype.slice.call(c.querySelectorAll('.on')).map(function(b){return b.dataset.v;}):[],intensityAllowed:_segVal(p+'int')||'moderate'};}
function _avCollectDraft(){var M=pmModel();var E=window._avEd;var av=E.av;function n(id){var e=document.getElementById(id);return e&&e.value!==''?parseInt(e.value,10):null;}
  M.WEEKDAYS.forEach(function(d){if(!E.open[d])return;var w=av.days[d];var avEl=document.getElementById('av_'+d+'_av');if(avEl)w.available=avEl.checked;var rEl=document.getElementById('av_'+d+'_rest');if(rEl)w.restDay=rEl.checked;
    var dEl=document.getElementById('av_'+d+'_dbl');if(dEl)w.doubleSession.enabled=dEl.checked;
    if(!w.restDay&&w.available){if(w.doubleSession.enabled){w.doubleSession.sessions[0]=_avSlotCollect(d,'0');w.doubleSession.sessions[1]=_avSlotCollect(d,'1');}else w.singleSession=_avSlotCollect(d,'s');}
    w.fixedCommitments=w.fixedCommitments.map(function(c){var p='av_'+d+'_fix_'+c.id+'_';function nn(id){var e=document.getElementById(id);return e&&e.value!==''?parseInt(e.value,10):null;}var st=document.getElementById(p+'start');
      return {id:c.id,type:_segVal(p+'type')||c.type,sportId:_segVal(p+'sport')||null,startTime:st?st.value:c.startTime,durationMinutes:nn(p+'dur'),intensity:_segVal(p+'int')||'moderate',fixed:true};});});
  if(document.getElementById('av_maxS'))av.maxSessionsPerWeek=n('av_maxS');if(document.getElementById('av_maxI'))av.maxIntenseSessions=n('av_maxI');if(document.getElementById('av_minRest'))av.minimumFullRestDays=n('av_minRest');
  var pr=document.getElementById('av_prefRest');if(pr)av.preferredRestDays=Array.prototype.slice.call(pr.querySelectorAll('.on')).map(function(b){return b.dataset.v;});
  E.av=M.normalizeAvailability(av);return E.av;}
function avToggleOpen(d){_avCollectDraft();window._avEd.open[d]=!window._avEd.open[d];renderAvailabilityEditor();}
function avFlag(d){_avCollectDraft();renderAvailabilityEditor();}   // available/restDay/double exklusiv via normalizeAvailability
function avAddFixed(d){_avCollectDraft();window._avEd.av.days[d].fixedCommitments.push(pmModel().normalizeFixedCommitment({}));renderAvailabilityEditor();}
function avDelFixed(d,id){_avCollectDraft();var w=window._avEd.av.days[d];w.fixedCommitments=w.fixedCommitments.filter(function(c){return c.id!==id;});renderAvailabilityEditor();}
function saveAvailabilityEditor(){PROFILE.availability=_avCollectDraft();_profileSave(['availability']);maybePlanImpact('availability',['availability']);
  _closeM('_secEdM');try{renderProfileScreen();}catch(e){}if(typeof toast==='function')toast('' + T('pf.verfuegbarkeit_gespeichert') + '');}
function cancelAvailabilityEditor(){_avCollectDraft();if(pmModel().diffState(JSON.parse(window._avEd.orig),window._avEd.av)){
    _modal('_secDiscard','<h3>' + T('pf.aenderungen_verwerfen') + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.deine_letzten_anpassungen_wurden_noch') + '</p>'+
      '<button class="btn sec" onclick="_closeM(\'_secDiscard\')">' + T('pf.weiter') + ' bearbeiten</button>'+
      '<button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_secDiscard\');_closeM(\'_secEdM\')">' + T('pf.aenderungen_verwerfen_btn') + '</button>');
  }else _closeM('_secEdM');}

/* Beschwerden und Einschränkungen (Liste, CRUD, Statuskreis). Keine Diagnose/Behandlung. */
var CSTR_STATUS_DE={active:'aktiv',improved:'verbessert',resolved:'behoben',observed:'pausiert beobachtet'};
function _constraintList(){return Array.isArray(PROFILE.constraintsList)?PROFILE.constraintsList:[];}
/* Sicherheits-Check außerhalb des Onboardings beantwortbar (Completion-Fixpaket):
   bewusstes „aktuell keine Beschwerden" setzt constraintsAcknowledgedAt — derselbe
   Vertrag wie der M7-Abschluss (ESSENTIAL_REQUIREMENTS.constraints). Kein Default,
   nur explizite Nutzeraktion. */
function orviaAcknowledgeNoConstraints(){
  var iso;try{iso=(window.ORVIA&&ORVIA.clock&&typeof ORVIA.clock.now==='function')?new Date(ORVIA.clock.now()).toISOString():new Date().toISOString();}catch(e){iso=new Date().toISOString();}
  PROFILE.constraintsAcknowledgedAt=iso;
  _profileSave(['constraints']);
  try{if(window._cmgr)openConstraintsEditor();}catch(e){}
  if(typeof toast==='function')toast('' + T('pf.sicherheits_check_bestaetigt') + '');}
function openConstraintsEditor(){window._cmgr=true;var list=_constraintList();
  var M=pmModel();var comp=null;try{comp=M.computeSectionCompleteness(PROFILE,'constraints');}catch(e){}
  var ack='';
  if(comp&&!comp.complete){ack=_missingHintHTML('constraints')+
    '<div class="gmcard"><div class="gmc-h">' + T('pf.sicherheits_check') + '</div><div class="gmc-meta">' + T('pf.bitte_einmal_bestaetigen_hast_du') + '</div>'+
    '<div class="gmc-acts"><button class="gmc-b" onclick="orviaAcknowledgeNoConstraints()">' + T('pf.ich_habe_aktuell_keine_beschwerden') + '</button></div></div>';}
  else if(!list.length&&PROFILE.constraintsAcknowledgedAt){ack='<p class="note" style="text-align:left">' + T('pf.sicherheits_check_bestaetigt_keine_aktiven') + '</p>';}
  var cards=list.length?list.map(function(c){return '<div class="gmcard"><div class="gmc-h">'+escH(c.title||c.bodyRegion||'Beschwerde')+'</div>'+
    '<div class="gmc-meta">'+escH((c.bodyRegion||'')+' · '+(CSTR_STATUS_DE[c.status]||c.status)+(c.intensity!=null?'' + T('pf.intensitaet') + ''+c.intensity+'/10':''))+'</div>'+
    '<div class="gmc-acts"><button class="gmc-b" onclick="openConstraintEditor(\''+c.id+'\')">' + T('pf.bearbeiten') + '</button>'+
    (c.status!=='improved'?'<button class="gmc-b" onclick="constraintStatus(\''+c.id+'\',\'improved\')">Verbessert</button>':'')+
    (c.status!=='resolved'?'<button class="gmc-b" onclick="constraintStatus(\''+c.id+'\',\'resolved\')">Behoben</button>':'')+
    (c.status!=='active'?'<button class="gmc-b" onclick="constraintStatus(\''+c.id+'\',\'active\')">Reaktivieren</button>':'')+
    '<button class="gmc-b" onclick="constraintStatus(\''+c.id+'\',\'observed\')">Archivieren</button>'+
    '<button class="gmc-b danger-btn" onclick="constraintRemove(\''+c.id+'\')">Löschen</button></div></div>';}).join(''):'<p class="note" style="text-align:left">' + T('pf.keine_beschwerden_erfasst') + '</p>';
  _modal('_cstrMgr','<h3>' + T('pf.beschwerden_und_einschraenkungen') + '</h3><p class="note" style="text-align:left">' + T('pf.hinweis_orvia_gibt_keine_diagnose') + '</p>'+ack+
    '<button class="btn" onclick="openConstraintEditor()">' + T('pf.beschwerde_hinzufuegen') + '</button>'+cards+
    '<button class="btn sec" style="margin-top:12px" onclick="_closeM(\'_cstrMgr\')">' + T('pf.schliessen') + '</button>');}
function c_regionLabel(code){var M=pmModel();var p=(M.BODY_REGIONS||[]).filter(function(x){return x[0]===code;})[0];return p?p[1]:(code||'Beschwerde');}
function openConstraintEditor(id){var M=pmModel();var c=id?_constraintList().filter(function(x){return x.id===id;})[0]:null;
  var st=['active','improved','resolved','observed'];var sports=(window.ORVIA&&ORVIA.profile&&ORVIA.profile.activeSports)?ORVIA.profile.activeSports():[];
  _modal('_cstrEd','<h3>'+(c?'' + T('pf.beschwerde_bearbeiten') + '':'' + T('pf.beschwerde_hinzufuegen') + '')+'</h3>'+
    '<div class="gm-field"><label>' + T('pf.koerperregion') + '</label>'+segHTML('c_region',M.BODY_REGIONS,(c&&c.bodyRegion)||'')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.seite') + '</label>'+segHTML('c_side',M.BODY_SIDES,(c&&c.side)||'na')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.intensitaet_0_10') + '</label><input type="number" id="c_int" value="'+(c&&c.intensity!=null?c.intensity:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.ausloeser') + '</label><input id="c_trig" value="'+escH(c?c.triggers:'')+'"></div>'+
    (sports.length?'<div class="gm-field"><label>' + T('pf.betroffene_sportarten') + '</label><div class="gm-chips" id="c_aff">'+sports.map(function(s){var on=c&&(c.affectedActivities||[]).indexOf(s.sportId)>=0;return '<button type="button" class="gm-chip'+(on?' on':'')+'" data-v="'+escH(s.sportId)+'" onclick="gmToggle(this)">'+escH(s.customName||_sportLabel(s))+'</button>';}).join('')+'</div></div>':'')+
    '<div class="gm-field"><label>' + T('pf.zu_vermeidende_bewegungen') + '</label><input id="c_avoid" value="'+escH(c?c.avoidMovements:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.beginn') + '</label><input id="c_since" value="'+escH(c?c.startedAt:'')+'"></div>'+
    '<div class="gm-field gm-inline"><input type="checkbox" id="c_train"'+(!c||c.currentlyTrainable?' checked':'')+'><label>' + T('pf.aktuell_trainierbar') + '</label></div>'+
    '<div class="gm-field"><label>' + T('pf.notiz') + '</label><input id="c_adapt" value="'+escH(c?c.notes:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.status_') + '</label>'+segHTML('c_status',st.map(function(s){return [s,CSTR_STATUS_DE[s]];}),(c&&c.status)||'active')+'</div>'+
    '<div class="gm-modal-actions"><button class="btn" onclick="saveConstraint(\''+(id||'')+'\')">' + T('pf.speichern') + '</button><button class="btn sec" style="margin-top:10px" onclick="_closeM(\'_cstrEd\')">' + T('pf.abbrechen') + '</button></div>');}
function saveConstraint(id){var M=pmModel();function v(i){var e=document.getElementById(i);return e?e.value:'';}
  var aff=document.getElementById('c_aff');var affs=aff?Array.prototype.slice.call(aff.querySelectorAll('.on')).map(function(b){return b.dataset.v;}):[];
  var reg=_segVal('c_region')||'';
  var raw={id:id||null,bodyRegion:reg,side:_segVal('c_side')||'na',title:c_regionLabel(reg),intensity:v('c_int')===''?null:parseInt(v('c_int'),10),triggers:v('c_trig'),affectedActivities:affs,avoidMovements:v('c_avoid'),startedAt:v('c_since'),
    currentlyTrainable:(document.getElementById('c_train')||{}).checked,notes:v('c_adapt'),status:_segVal('c_status')||'active'};
  var c=M.normalizeConstraint(raw);var list=_constraintList().slice();
  if(id){list=list.map(function(x){return x.id===id?c:x;});}else list.push(c);
  PROFILE.constraintsList=list;_persistConstraints();_closeM('_cstrEd');openConstraintsEditor();if(typeof toast==='function')toast('' + T('pf.beschwerde_gespeichert') + '');}
function constraintStatus(id,st){var M=pmModel();PROFILE.constraintsList=_constraintList().map(function(c){return c.id===id?M.normalizeConstraint(Object.assign({},c,{status:st})):c;});_persistConstraints();openConstraintsEditor();}
function constraintRemove(id){PROFILE.constraintsList=_constraintList().filter(function(c){return c.id!==id;});_persistConstraints();openConstraintsEditor();}
function _persistConstraints(){ // Beschwerden zentral speichern; issues[]-Projektion + Event über _profileSave
  _profileSave(['constraints']);
  maybePlanImpact('constraints',['constraints']);}

/* DEPRECATED (H5-Audit): openProfileSummary hat KEINEN produktiven Aufrufer mehr —
   das Profil-Center ist die kanonische Übersicht. Bleibt vorerst für Alt-Tests;
   Entfernung in einem Aufräum-Paket. Keinen neuen Einstieg darauf bauen. */
/* Profil-Übersicht: kompakte Zusammenfassung, jeder Abschnitt direkt bearbeitbar. */
function openProfileSummary(){var M=pmModel();var act=listGoals().filter(function(g){return g.status==='active';}).slice().sort(function(a,b){return a.priority-b.priority;});
  var primary=act[0];var others=act.slice(1);
  var sports=(PROFILE.sports||[]).map(function(s){return typeof s==='string'?s:(s.sportId||s.customName);}).filter(Boolean);
  var avs=M.availabilitySummary(PROFILE.availability);
  var avBits=[avs.availableDays+'' + T('pf.verfuegbare_tage') + ''];if(avs.maxSessionsPerWeek!=null)avBits.push('' + T('pf.bis_zu') + ''+avs.maxSessionsPerWeek+'' + T('pf.einheiten') + '');if(avs.doubleDays)avBits.push(avs.doubleDays+'' + T('pf.moegliche_doppeleinheiten') + '');if(avs.preferredRestDays.length)avBits.push('' + T('pf.bevorzugter_ruhetag') + ''+avs.preferredRestDays.map(function(d){return WD_DE[d]||d;}).join(', '));
  var perf=M.normalizePerformance(PROFILE.performance,PROFILE.body);var perfBits=[];var cw=(PROFILE.weightKg!=null?PROFILE.weightKg:M.currentWeightKg(perf));if(cw!=null)perfBits.push(cw+' kg');   // P10: kanonische Quelle zuerst
  if(perf.vo2max.value!=null)perfBits.push('' + T('pf.vo_max') + ''+(perf.vo2max.sportId?' '+(M.sportProfileSchema(perf.vo2max.sportId)||{label:perf.vo2max.sportId}).label:'')+': '+perf.vo2max.value);
  if(perf.personalBests.length){var pb=perf.personalBests[0];perfBits.push((pb.distance||pb.discipline||'Bestzeit')+': '+M.formatDuration(pb.timeSeconds));}
  if(perf.strengthRecords.length){var sr=perf.strengthRecords[0];perfBits.push(sr.exerciseName+': '+(sr.weightKg||'?')+' kg × '+(sr.repetitions||'?'));}
  var constraints=_constraintList().filter(function(c){return c.status==='active';}).map(function(c){return (c.title||c.bodyRegion)+(c.intensity!=null?'' + T('pf.intensitaet') + ''+c.intensity:'');});
  var rec=M.normalizeRecovery(PROFILE.recovery,PROFILE.recovery);var recDE={very_bad:'sehr schlecht',bad:'schlecht',mid:'mittel',good:'gut',very_good:'sehr gut',low:'niedrig',high:'hoch',very_high:'sehr hoch'};
  var recBits=[];if(rec.sleep.averageHours!=null)recBits.push('Ø '+rec.sleep.averageHours+'' + T('pf.h_schlaf') + '');if(rec.stress.generalLevel)recBits.push('' + T('pf.stress') + ''+(recDE[rec.stress.generalLevel]||rec.stress.generalLevel));var nutDE={deficit:'Kaloriendefizit',maintain:'' + T('pf.gewicht_halten') + '',surplus:'Kalorienüberschuss'};if(nutDE[rec.nutritionState.mode])recBits.push(nutDE[rec.nutritionState.mode]);
  var pr=M.normalizePreferences(PROFILE.preferences||PROFILE.trainingPrefs,PROFILE.trainingPrefs);var prBits=[];var envDE={indoor:'Indoor',outdoor:'Outdoor',both:'Indoor/Outdoor'};var tDE={morning:'Morgens',noon:'Mittags',afternoon:'Nachmittags',evening:'Abends',flexible:'Flexibel'};var iDE={easy:'eher locker',balanced:'ausgeglichen',intense:'eher intensiv'};
  if(pr.preferredTimes.length)prBits.push(pr.preferredTimes.map(function(t){return tDE[t]||t;}).join(', '));if(envDE[pr.preferredEnvironment])prBits.push(envDE[pr.preferredEnvironment]);if(pr.preferredSessionDurations.length)prBits.push(pr.preferredSessionDurations.filter(function(x){return x>0;}).join('–')+'' + T('pf.minuten') + '');if(iDE[pr.intensityPreference])prBits.push(iDE[pr.intensityPreference]+'' + T('pf.intensitaet_') + '');
  function sec(title,body,editId){return '<div class="ps-block"><div class="ps-h">'+escH(title)+(editId?'<button class="gmc-b" onclick="_closeM(\'_profSum\');openProfileSection(\''+editId+'\')">' + T('pf.bearbeiten') + '</button>':'')+'</div>'+body+'</div>';}
  _modal('_profSum','<h3>' + T('pf.dein_orvia_profil') + '</h3>'+
    sec('Hauptziel',primary?'<p>'+escH(primary.title)+'</p>':'<p class="note">—</p>','goals')+
    sec('' + T('pf.weitere_ziele') + '',others.length?'<ul class="ps-list">'+others.map(function(g){return '<li>'+escH(g.title)+'</li>';}).join('')+'</ul>':'<p class="note">—</p>','goals')+
    sec('' + T('pf.sportarten') + '',sports.length?'<p>'+escH(sports.join(', '))+'</p>':'<p class="note">—</p>','sports')+
    sec('Trainingsverfügbarkeit','<p>'+escH(avBits.join(' · '))+'</p>','availability')+
    sec('' + T('pf.koerper_und_leistung') + '',perfBits.length?'<p>'+escH(perfBits.join(' · '))+'</p>':'<p class="note">—</p>','body')+
    sec('' + T('pf.regeneration_und_alltag') + '',recBits.length?'<p>'+escH(recBits.join(' · '))+'</p>':'<p class="note">—</p>','recovery')+
    sec('Beschwerden',constraints.length?'<p>'+escH(constraints.join(', '))+'</p>':'<p class="note">keine</p>','constraints')+
    sec('Trainingspräferenzen',prBits.length?'<p>'+escH(prBits.join(' · '))+'</p>':'<p class="note">—</p>','preferences')+
    (function(){var dv=M.normalizeDevices(PROFILE.devices,PROFILE.dataSources);var b=[];M.INTEGRATION_IDS.forEach(function(k){var i=dv.integrations[k];b.push(({strava:'Strava',garmin:'Garmin',appleHealth:'' + T('pf.apple_health') + ''}[k])+' '+(i.connected?T('pf.verbunden'):(i.status==='not_available'?'' + T('pf.nicht_verfuegbar__') + '':T('pf.nicht_verbunden'))));});b.push(dv.equipment.filter(function(e){return e.available;}).length+'' + T('pf.trainingsgeraete') + '');if(dv.trainingLocations.length)b.push(dv.trainingLocations.length+'' + T('pf.trainingsorte') + '');return sec('' + T('pf.geraete_und_datenquellen') + '','<p>'+escH(b.join(' · '))+'</p>','devices');})()+
    '<button class="btn sec" style="margin-top:12px" onclick="_closeM(\'_profSum\')">' + T('pf.schliessen') + '</button>');}

/* ============================================================
   KÖRPER- UND LEISTUNGSDATEN (Inkrement 4f): strukturiert, Einheit/Quelle/Datum, editier-/löschbar.
   ============================================================ */
var PERF_SOURCE_DE={manual:'Manuell',garmin:'Garmin',strava:'Strava',apple_health:'' + T('pf.apple_health') + '',import:'Importiert',calculated:'Berechnet'};
var SET_TYPE_DE={working:'' + T('pf.normaler_arbeitssatz') + '',top_set:'' + T('pf.schwerster_satz') + '',test:'Test',estimated_1rm:'' + T('pf.geschaetztes_1rm') + ''};
function _today(){try{return new Date().toISOString().slice(0,10);}catch(e){return '';}}
function _perfM(){return pmModel();}
/* P2 (2026-07-09): Die flachen Felder (weightKg/heightCm/hfMaxMeasured/restingHrMeasured)
   sind KANONISCH — sie lesen Karten, Zonen, calc, nutrition und der Cloud-Sync.
   Der Editor arbeitet auf PROFILE.performance (Historie/Struktur); beim Öffnen wird
   performance.body aus den kanonischen Feldern GESEEDET (Altdaten wie 198/58/75/175
   werden dadurch endlich editierbar), beim Speichern wird zurückgespiegelt. */
function _perfSeedFromCanonical(perf){try{var b=perf.body;
  /* Phase 5 (Garmin, 2026-07-17): War der letzte Schreiber der Section 'body'
     der ProfileMetricResolver (_sectionMeta.body.source==='provider_sync'), stammt
     ein noch nicht editierter kanonischer Wert von Garmin, nicht vom Nutzer —
     korrektes Label 'garmin' statt der bisherigen Pauschalannahme 'manual'. */
  var seedSrc=(PROFILE._sectionMeta&&PROFILE._sectionMeta.body&&PROFILE._sectionMeta.body.source==='provider_sync')?'garmin':'manual';
  /* normalizePerfMetric() (profile-model.js) stempelt source IMMER auf 'manual', auch wenn
     value==null ist (Platzhalter-Default, keine echte Herkunftsangabe). Ein `metric.source||seedSrc`
     würde deshalb nie greifen. Da wir hier nur eintreten, wenn metric.value vorher null war, gab es
     keinen echten Vorwert — das vorhandene 'manual' ist reiner Default, kein belastbares Datum, und
     darf unbedingt (nicht nur bei Falsy) durch seedSrc ersetzt werden. */
  function seed(metric,val,unit){if(metric.value==null&&val!=null){metric.value=val;metric.unit=unit;metric.source=seedSrc;}}
  seed(b.weight,PROFILE.weightKg,'kg');seed(b.height,PROFILE.heightCm,'cm');
  seed(b.restingHr,PROFILE.restingHrMeasured,'bpm');seed(b.maxHr,PROFILE.hfMaxMeasured!=null?PROFILE.hfMaxMeasured:PROFILE.hfMax,'bpm');
}catch(e){}return perf;}
/* Phase 5 (Garmin, 2026-07-17): touchedBodyKeys begrenzt den Rückspiegel-Patch auf
   Felder, die in DIESER Editor-Sitzung tatsächlich verändert wurden (Teilmenge von
   ['weight','height','restingHr','maxHr']). Vorher wurden bei JEDEM _perfSave()-Aufruf
   (auch aus Ausdauerwerte-/Bestzeiten-/Kraftwerte-Editor oder Gewichtsverlauf-Löschen)
   ALLE vier Felder unbedingt zurückgeschrieben — ein länger unbearbeitetes, einmalig
   gecachtes Editor-Feld hätte dabei einen zwischenzeitlich frischeren, vom
   ProfileMetricResolver automatisch synchronisierten Garmin-Wert stillschweigend
   überschrieben (Doppelwelt-Risiko). Ohne touchedBodyKeys (undefined) wird NICHTS
   gemirrort — sicherer Default für Aufrufer, die keine Body-Felder betreffen. */
function _perfMirrorCanonical(perf,touchedBodyKeys){var M=_perfM();var p={};
  var touched=Array.isArray(touchedBodyKeys)?touchedBodyKeys:[];
  function touches(k){return touched.indexOf(k)>=0;}
  if(touches('weight'))p.weightKg=M.currentWeightKg(perf);           // aktuellstes Gewicht (Verlauf > Körperdaten)
  if(touches('height'))p.heightCm=perf.body.height.value;
  if(touches('restingHr')){
    p.restingHrMeasured=perf.body.restingHr.value;
    if(perf.body.restingHr.value!=null)p.rhrBaseline=perf.body.restingHr.value;   // Baseline nie auf null
  }
  if(touches('maxHr')){
    p.hfMaxMeasured=perf.body.maxHr.value;
    p.hfMax=perf.body.maxHr.value;                 // eine HFmax-Welt: hfMax folgt der Messung
  }
  return p;}
function openPerformanceManager(){var M=_perfM();var seeded=_perfSeedFromCanonical(M.normalizePerformance(PROFILE.performance,PROFILE.body));
  window._perfEd={orig:JSON.stringify(seeded),perf:seeded};
  window._gwSync={state:'idle',data:null,error:null}; // Phase 5: Zustand der Karte "Automatisch synchronisierte Daten"
  openSheet({id:'_perfMgr',title:'' + T('pf.koerper_und_leistung') + '',body:'<div id="perfBody"></div>',
    actions:'<button class="btn sec" onclick="_closeM(\'_perfMgr\')">' + T('pf.schliessen') + '</button>'});renderPerformanceManager();_gwSyncLoad();}
function _perfSave(touchedBodyKeys){var M=_perfM();PROFILE.performance=M.normalizePerformance(window._perfEd.perf,PROFILE.body);
  Object.assign(PROFILE,_perfMirrorCanonical(PROFILE.performance,touchedBodyKeys));   // P2/Phase 5: nur tatsächlich bearbeitete Felder folgen dem Editor
  _profileSave(['body']);try{if(window._perfMgr)renderPerformanceManager();}catch(e){}if(typeof toast==='function')toast('Gespeichert');}
function renderPerformanceManager(){var M=_perfM();var perf=window._perfEd.perf;var box=document.getElementById('perfBody');if(!box)return;
  var cw=M.currentWeightKg(perf);
  function row(label,val){return val?'<div class="gmc-meta">'+escH(label+': '+val)+'</div>':'';}
  var legacy=perf._legacyText?('<div class="gm-sec">' + T('pf.alte_notizen') + '</div>'+(perf._legacyText.bestTimes?'<div class="gmc-meta">'+escH('' + T('pf.bestzeiten') + ''+perf._legacyText.bestTimes)+'</div>':'')+(perf._legacyText.lifts?'<div class="gmc-meta">'+escH('' + T('pf.kraftwerte') + ''+perf._legacyText.lifts)+'</div>':'')):'';
  box.innerHTML=
    '<div class="gmcard"><div class="gmc-h">' + T('pf.koerperdaten') + '</div>'+row('' + T('pf.groesse') + '',perf.body.height.value&&perf.body.height.value+' cm')+row('' + T('pf.gewicht') + '',cw!=null&&cw+' kg')+row('Körperfett',perf.body.bodyFat.value&&perf.body.bodyFat.value+' %')+row('Ruhepuls',perf.body.restingHr.value&&perf.body.restingHr.value+' bpm')+row('HFmax',perf.body.maxHr.value&&perf.body.maxHr.value+' bpm')+((perf.body.height.value==null&&cw==null&&perf.body.restingHr.value==null&&perf.body.maxHr.value==null)?'<div class="gmc-meta">' + T('pf.nicht_angegeben') + '</div>':'')+'<div class="gmc-acts"><button class="gmc-b" onclick="openBodyEditor()">' + T('pf.bearbeiten') + '</button></div></div>'+
    '<div id="gwSync"></div>'+
    '<div class="gmcard"><div class="gmc-h">' + T('pf.gewichtsverlauf') + '</div>'+(perf.weightHistory.length?perf.weightHistory.slice(0,5).map(function(e){return '<div class="gw-ms"><span>'+escH((e.measuredAt||'—')+' · '+e.valueKg+' kg')+'</span><button class="gmc-b danger-btn" onclick="perfDelWeight(\''+e.id+'\')">✕</button></div>';}).join(''):'<p class="note" style="text-align:left">' + T('pf.keine_messungen') + '</p>')+'<div class="gmc-acts"><button class="gmc-b" onclick="openWeightAdd()">' + T('pf.messung_hinzufuegen') + '</button></div></div>'+
    '<div class="gmcard"><div class="gmc-h">' + T('pf.ausdauerwerte') + '</div>'+row('' + T('pf.vo_max') + '',perf.vo2max.value&&(perf.vo2max.value+(perf.vo2max.sportId?' ('+(M.sportProfileSchema(perf.vo2max.sportId)||{label:perf.vo2max.sportId}).label+')':'')))+row('FTP',perf.ftp.valueWatts&&perf.ftp.valueWatts+' W')+row('Schwellenpace',perf.thresholdPace.secondsPerKm&&M.formatPace(perf.thresholdPace.secondsPerKm)+'/km')+row('CSS-Pace',perf.cssPace.secondsPer100m&&M.formatPace(perf.cssPace.secondsPer100m)+'/100 m')+'<div class="gmc-acts"><button class="gmc-b" onclick="openEnduranceEditor()">' + T('pf.bearbeiten') + '</button></div></div>'+
    '<div class="gmcard"><div class="gmc-h">' + T('pf.persoenliche_bestzeiten_n') + ''+perf.personalBests.length+')</div>'+perf.personalBests.map(function(b){return '<div class="gw-ms"><span>'+escH((b.distance||b.discipline||'Bestzeit')+' · '+M.formatDuration(b.timeSeconds)+(b.measuredAt?' · '+b.measuredAt:''))+'</span><button class="gmc-b" onclick="openPbEditor(\''+b.id+'\')">✎</button><button class="gmc-b danger-btn" onclick="perfDelPb(\''+b.id+'\')">✕</button></div>';}).join('')+'<div class="gmc-acts"><button class="gmc-b" onclick="openPbEditor()">' + T('pf.bestzeit_hinzufuegen') + '</button></div></div>'+
    '<div class="gmcard"><div class="gmc-h">Kraftwerte ('+perf.strengthRecords.length+')</div>'+perf.strengthRecords.map(function(r){return '<div class="gw-ms"><span>'+escH(r.exerciseName+' · '+(r.weightKg||'?')+' kg × '+(r.repetitions||'?')+(r.estimatedOneRepMax?'' + T('pf.1rm') + ''+r.estimatedOneRepMax+' kg'+(r.oneRmEstimated?'' + T('pf.schaetzung') + '':''):''))+'</span><button class="gmc-b" onclick="openSrEditor(\''+r.id+'\')">✎</button><button class="gmc-b danger-btn" onclick="perfDelSr(\''+r.id+'\')">✕</button></div>';}).join('')+'<div class="gmc-acts"><button class="gmc-b" onclick="openSrEditor()">' + T('pf.kraftwert_hinzufuegen') + '</button></div></div>'+
    legacy;
  _gwSyncRenderInto();}
/* ============================================================
   Phase 5 (Garmin, 2026-07-17): Karte "Automatisch synchronisierte Daten"
   Datenfluss: openPerformanceManager → _gwSyncLoad → profileMetricResolver
   .refresh() (löst user_metrics auf und schreibt geänderte Werte über
   updateSection(...,'provider_sync') in die flachen kanonischen Felder)
   → _gwSyncRenderInto/_gwSyncCardHTML (Wert · Quelle · Gerät · Zeitpunkt ·
   Trend; editMode steuert die Korrigieren-Aktion). Reines Anzeige-/
   Aktions-UI — sämtliche Entscheidungslogik liegt im Resolver-Modul.
   ============================================================ */
function _gwSyncLoad(){var P=window.ORVIA&&ORVIA.profileMetricResolver;var st=window._gwSync;if(!P||!st||st.state==='loading')return;
  st.state='loading';_gwSyncRenderInto();
  P.refresh().then(function(r){var s=window._gwSync;if(!s)return;
    if(r&&r.success){s.state='ready';s.data=r.data;s.error=null;
      /* Wurden kanonische Felder aktualisiert und der Editor-Stand ist noch
         unberührt, neu seeden — sonst zeigt der offene Manager alte Werte. */
      try{var ed=window._perfEd;
        if(r.data.applied&&Object.keys(r.data.applied).length&&ed&&JSON.stringify(ed.perf)===ed.orig){
          var M=_perfM();var seeded=_perfSeedFromCanonical(M.normalizePerformance(PROFILE.performance,PROFILE.body));
          window._perfEd={orig:JSON.stringify(seeded),perf:seeded};
          if(window._perfMgr){renderPerformanceManager();return;}}}catch(e){}}
    else{s.state='error';s.error=(r&&r.error)||{message:'' + T('pf.unbekannter_fehler') + ''};}
    _gwSyncRenderInto();
  }).catch(function(e){var s=window._gwSync;if(s){s.state='error';s.error={message:String(e&&e.message||e)};_gwSyncRenderInto();}});}
function _gwSyncRenderInto(){var el=document.getElementById('gwSync');if(el)el.innerHTML=_gwSyncCardHTML();}
function _gwSyncCardHTML(){var st=window._gwSync;var P=window.ORVIA&&ORVIA.profileMetricResolver;var R=window.ORVIA&&ORVIA.metricRegistry;var MR=window.ORVIA&&ORVIA.metricResolver;
  if(!st||!P||!R||!MR)return '';
  var head='<div class="gmcard"><div class="gmc-h">' + T('pf.automatisch_synchronisierte_daten') + '</div>';
  if(st.state==='idle'||st.state==='loading')return head+'<div class="gmc-meta">' + T('pf.wird_geladen') + '</div></div>';
  if(st.state==='error'){var off=st.error&&st.error.code==='offline';
    return head+'<div class="gmc-meta">'+escH(off?'' + T('pf.offline_synchronisierte_werte_sind_gerade') + '':'' + T('pf.synchronisierte_werte_konnten_nicht_geladen') + '')+'</div></div>';}
  var d=st.data||{};var resolved=d.resolved||{};
  var groups={};
  R.METRICS.forEach(function(def){var res=resolved[def.id];if(!res)return;
    if(P.settingsFor(d.settingsRows||[],def.id).displayEnabled===false)return;
    (groups[def.category]=groups[def.category]||[]).push({def:def,res:res});});
  var cats=Object.keys(R.CATEGORY_LABELS).filter(function(c){return groups[c]&&groups[c].length;});
  if(!cats.length){ // §10: ohne Daten Karte nur zeigen, wenn ein Provider verbunden ist
    return (d.providers||[]).length?head+'<div class="gmc-meta">' + T('pf.noch_keine_synchronisierten_messwerte') + '</div></div>':'';}
  var html=head;
  cats.forEach(function(cat){html+='<div class="gm-sec">'+escH(R.CATEGORY_LABELS[cat])+'</div>';
    groups[cat].forEach(function(it){html+=_gwSyncRowHTML(it.def,it.res,d);});});
  return html+'</div>';}
function _gwSyncRowHTML(def,res,d){var MR=ORVIA.metricResolver;var P=ORVIA.profileMetricResolver;
  function provName(pid){var p=(d.providers||[]).filter(function(x){return x.id===pid;})[0];var t=p&&p.provider_type;
    return (t==='garmin_unofficial'||t==='garmin_official')?'Garmin':t==='apple_health'?'' + T('pf.apple_health') + '':t==='health_connect'?'' + T('pf.health_connect') + '':t==='strava'?'Strava':t?'Provider':'Automatisch';}
  function devName(did){if(!did)return null;var dv=(d.devices||[]).filter(function(x){return x.id===did;})[0];
    return dv?(dv.device_name||dv.model_name||dv.model||null):null;}
  var val=MR.displayValue(res);
  var srcTxt=res.source==='override'?'' + T('pf.manuell_korrigiert') + '':res.source==='automatic'?provName(res.entry&&res.entry.providerId):res.source==='manual'?'Manuell':res.source==='estimate'?'Schätzung':res.source==='historical'?'Historisch':'' + T('pf.unbekannte_quelle') + '';
  var dev=res.source==='automatic'?devName(res.entry&&res.entry.deviceId):null;
  var when=res.metricDate||String(res.measuredAt||'').slice(0,10)||'';
  var trTxt='';
  if(def.valueKind!=='text'){var tr=P.trendFor(def.id,d.entries||[],res);
    if(tr&&typeof tr.delta==='number'&&isFinite(tr.delta)&&tr.delta!==0){
      var dec=def.decimals!=null?def.decimals:0;var arrow=tr.delta>0?'▲':'▼';
      var unit=(def.unit==='s'||def.unit==='s/km')?' s':(def.unit?' '+def.unit:'');
      trTxt=' · '+arrow+' '+Math.abs(tr.delta).toFixed(dec).replace('.',',')+unit;}}
  var meta=[srcTxt,dev,when].filter(Boolean).join(' · ')+trTxt+(res.stale?' · veraltet':'');
  var act=def.editMode==='automatic_override_allowed'?'<button class="gmc-b" onclick="openMetricOverride(\''+def.id+'\')">Korrigieren</button>':'';
  return '<div class="gw-ms"><span><strong>'+escH(def.label)+':</strong> '+escH(val)+'<br><span class="gmc-meta" style="margin-top:0">'+escH(meta)+'</span></span>'+act+'</div>';}
/* Manuelle Korrektur (editMode automatic_override_allowed): append-only über
   metricsRepository.saveManualOverride; Original bleibt referenziert erhalten. */
function openMetricOverride(metricId){var R=window.ORVIA&&ORVIA.metricRegistry;var def=R&&R.byId(metricId);if(!def)return;
  var st=window._gwSync;var res=st&&st.data&&st.data.resolved?st.data.resolved[metricId]:null;
  var reasons=[['garmin_value_wrong','' + T('pf.garmin_wert_falsch') + ''],['external_measurement_more_accurate','' + T('pf.externe_messung_genauer') + ''],['lab_test_available','' + T('pf.labortest_vorhanden') + ''],['manual_correction','' + T('pf.manuelle_korrektur') + ''],['other','Sonstiges']];
  openSheet({id:'_perfSub',title:def.label+' korrigieren',size:'large',
    body:'<div class="gm-field"><label>'+escH(def.label)+(def.unit?' ('+escH(def.unit)+')':'')+'</label><input type="number" id="mo_val" value="'+(res&&res.value!=null?res.value:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.grund') + '</label>'+segHTML('mo_reason',reasons,'manual_correction')+'</div>'+
    '<div class="gmc-meta">' + T('pf.der_originalwert_bleibt_gespeichert_die') + '</div>'+
    '<span class="ob2-err" id="mo_err" role="alert"></span>',
    actions:'<button class="btn" onclick="saveMetricOverride(\''+metricId+'\')">' + T('pf.speichern') + '</button><button class="btn sec" onclick="_closeM(\'_perfSub\')">' + T('pf.abbrechen') + '</button>'});}
function saveMetricOverride(metricId){var R=window.ORVIA&&ORVIA.metricRegistry;var def=R&&R.byId(metricId);if(!def)return;
  var e=document.getElementById('mo_val');var v=e&&e.value!==''?parseFloat(e.value.replace(',','.')):null;
  var err=document.getElementById('mo_err');
  if(v==null||!isFinite(v)){if(err)err.textContent='' + T('pf.bitte_einen_gueltigen_wert_eingeben') + '';return;}
  if(def.plausible&&(v<def.plausible[0]||v>def.plausible[1])){if(err)err.textContent='' + T('pf.wert_ausserhalb_des_plausiblen_bereichs') + ''+def.plausible[0]+'–'+def.plausible[1]+(def.unit?' '+def.unit:'')+').';return;}
  var st=window._gwSync;var res=st&&st.data&&st.data.resolved?st.data.resolved[metricId]:null;
  var repo=window.ORVIA&&ORVIA.repos&&ORVIA.repos.metrics;
  if(!repo){if(err)err.textContent='' + T('pf.speichern_derzeit_nicht_moeglich') + '';return;}
  repo.saveManualOverride(metricId,v,def.unit,_segVal('mo_reason')||'manual_correction',(res&&res.entry&&res.entry.id)||null).then(function(r){
    if(r&&r.success){_closeM('_perfSub');if(typeof toast==='function')toast('' + T('pf.korrektur_gespeichert') + '');
      window._gwSync={state:'idle',data:null,error:null};_gwSyncLoad();}
    else{var el=document.getElementById('mo_err');if(el)el.textContent=(r&&r.error&&r.error.message)||'' + T('pf.speichern_fehlgeschlagen') + '';}});}
function _metricSet(m,val,unit){var changed=(m.value!=val);if(val===''||val==null){return {value:null,unit:unit,sportId:m.sportId||null,source:m.source||'manual',measuredAt:m.measuredAt||null};}
  return {value:val,unit:unit,sportId:m.sportId||null,source:changed?'manual':(m.source||'manual'),measuredAt:changed?_today():(m.measuredAt||_today())};}
/* Körperdaten-Editor */
function openBodyEditor(){var perf=window._perfEd.perf;var b=perf.body;
  function f(k,lab,unit){return '<div class="gm-field"><label>'+lab+' ('+unit+', optional)</label><input type="number" id="bd_'+k+'" value="'+(b[k].value!=null?b[k].value:'')+'"></div>';}
  openSheet({id:'_perfSub',title:'' + T('pf.koerperdaten') + '',size:'large',
    body:f('height','' + T('pf.groesse') + '','cm')+f('weight','' + T('pf.gewicht') + '','kg')+f('bodyFat','Körperfett','%')+f('leanMass','' + T('pf.fettfreie_masse') + '','kg')+f('waist','Taillenumfang','cm')+f('restingHr','Ruhepuls','bpm')+f('maxHr','' + T('pf.maximale_herzfrequenz') + '','bpm')+'<span class="ob2-err" id="bd_err" role="alert"></span>',
    actions:'<button class="btn" onclick="saveBodyEditor()">' + T('pf.speichern') + '</button><button class="btn sec" onclick="_closeM(\'_perfSub\')">' + T('pf.abbrechen') + '</button>'});}
function saveBodyEditor(){var perf=window._perfEd.perf;var b=perf.body;function val(k){var e=document.getElementById('bd_'+k);return e&&e.value!==''?parseFloat(e.value.replace(',','.')):null;}
  var bf=val('bodyFat');if(bf!=null&&(bf<0||bf>100)){document.getElementById('bd_err').textContent='' + T('pf.koerperfett_muss_zwischen_0_und') + '';return;}
  var h=val('height'),w=val('weight');if((h!=null&&h<=0)||(w!=null&&w<=0)){document.getElementById('bd_err').textContent='' + T('pf.werte_muessen_positiv_sein') + '';return;}
  // Phase 5 (Garmin, 2026-07-17): welche der vier kanonisch gemappten Felder wurden
  // TATSÄCHLICH verändert (gleicher Vergleich wie in _metricSet) — VOR der Mutation
  // durch _metricSet ermittelt. Nur diese dürfen beim Speichern zurückgespiegelt
  // werden (siehe _perfMirrorCanonical); unangetastete Felder bleiben unangetastet,
  // damit ein automatisch synchronisierter Garmin-Wert nicht überschrieben wird.
  var touchedBodyKeys=['weight','height','restingHr','maxHr'].filter(function(k){return b[k].value!=val(k);});
  ['height','weight','bodyFat','leanMass','waist','restingHr','maxHr'].forEach(function(k){var u={height:'cm',weight:'kg',bodyFat:'%',leanMass:'kg',waist:'cm',restingHr:'bpm',maxHr:'bpm'}[k];b[k]=_metricSet(b[k],val(k),u);});
  // Gewichtsänderung zusätzlich in den Verlauf aufnehmen.
  if(b.weight.value!=null){var wh=perf.weightHistory;if(!wh.length||wh[0].valueKg!==b.weight.value)wh.unshift({id:'w:'+Date.now().toString(36),valueKg:b.weight.value,measuredAt:_today(),source:'manual'});}
  _closeM('_perfSub');_perfSave(touchedBodyKeys);}
/* Gewichtsmessung hinzufügen */
function openWeightAdd(){openSheet({id:'_perfSub',title:'Gewichtsmessung',size:'large',
  body:'<div class="gm-field"><label>' + T('pf.gewicht_kg') + '</label><input type="number" id="wa_val"></div><div class="gm-field"><label>' + T('pf.datum') + '</label><input type="date" id="wa_date" value="'+_today()+'"></div><span class="ob2-err" id="wa_err" role="alert"></span>',
  actions:'<button class="btn" onclick="saveWeightAdd()">' + T('pf.speichern') + '</button><button class="btn sec" onclick="_closeM(\'_perfSub\')">' + T('pf.abbrechen') + '</button>'});}
function saveWeightAdd(){var v=document.getElementById('wa_val');var val=v&&v.value!==''?parseFloat(v.value.replace(',','.')):null;if(!(val>0)){document.getElementById('wa_err').textContent='' + T('pf.bitte_ein_gueltiges_gewicht_eingeben') + '';return;}
  window._perfEd.perf.weightHistory.unshift({id:'w:'+Date.now().toString(36)+Math.random().toString(36).slice(2,5),valueKg:val,measuredAt:(document.getElementById('wa_date')||{}).value||_today(),source:'manual'});_closeM('_perfSub');_perfSave(['weight']);}
function perfDelWeight(id){window._perfEd.perf.weightHistory=window._perfEd.perf.weightHistory.filter(function(e){return e.id!==id;});_perfSave(['weight']);}
/* Ausdauerwerte */
function openEnduranceEditor(){var M=_perfM();var perf=window._perfEd.perf;var sports=(window.ORVIA&&ORVIA.profile&&ORVIA.profile.activeSports)?ORVIA.profile.activeSports():[];
  openSheet({id:'_perfSub',title:'' + T('pf.ausdauerwerte') + '',size:'large',
    body:'<div class="gm-field"><label>' + T('pf.vo_max') + '</label><input type="number" id="en_vo2" value="'+(perf.vo2max.value!=null?perf.vo2max.value:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.vo_max_sportart_optional') + '</label>'+segHTML('en_vo2sport',[['','allgemein']].concat(sports.map(function(s){return [s.sportId,s.customName||_sportLabel(s)];})),perf.vo2max.sportId||'')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.ftp_watt') + '</label><input type="number" id="en_ftp" value="'+(perf.ftp.valueWatts!=null?perf.ftp.valueWatts:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.schwellenpace_min_km_z_b') + '</label><input id="en_tp" value="'+(perf.thresholdPace.secondsPerKm?M.formatPace(perf.thresholdPace.secondsPerKm):'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.css_pace_min_100_m') + '</label><input id="en_css" value="'+(perf.cssPace.secondsPer100m?M.formatPace(perf.cssPace.secondsPer100m):'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.2_000_m_rudern_z') + '</label><input id="en_row" value="'+(perf.rowing2k.timeSeconds?M.formatDuration(perf.rowing2k.timeSeconds):'')+'"></div>'+
    '<span class="ob2-err" id="en_err" role="alert"></span>',
    actions:'<button class="btn" onclick="saveEnduranceEditor()">' + T('pf.speichern') + '</button><button class="btn sec" onclick="_closeM(\'_perfSub\')">' + T('pf.abbrechen') + '</button>'});}
function saveEnduranceEditor(){var M=_perfM();var perf=window._perfEd.perf;function num(id){var e=document.getElementById(id);return e&&e.value!==''?parseFloat(e.value.replace(',','.')):null;}
  var vo2=num('en_vo2');perf.vo2max=Object.assign(_metricSet(perf.vo2max,vo2,null),{sportId:_segVal('en_vo2sport')||null});
  var ftp=num('en_ftp');perf.ftp=Object.assign(_metricSet(perf.ftp,ftp,'W'),{valueWatts:ftp,wattsPerKg:null});
  perf.thresholdPace=Object.assign(_metricSet(perf.thresholdPace,1,null),{secondsPerKm:M.parsePace((document.getElementById('en_tp')||{}).value)});
  perf.cssPace=Object.assign(_metricSet(perf.cssPace,1,null),{secondsPer100m:M.parsePace((document.getElementById('en_css')||{}).value)});
  perf.rowing2k=Object.assign(_metricSet(perf.rowing2k,1,null),{timeSeconds:M.parseDuration((document.getElementById('en_row')||{}).value)});
  _closeM('_perfSub');_perfSave([]);}
/* Bestzeiten */
function openPbEditor(id){var M=_perfM();var perf=window._perfEd.perf;var b=id?perf.personalBests.filter(function(x){return x.id===id;})[0]:null;
  var sports=(window.ORVIA&&ORVIA.profile&&ORVIA.profile.activeSports)?ORVIA.profile.activeSports():[];
  openSheet({id:'_perfSub',title:(b?'' + T('pf.bestzeit_bearbeiten') + '':'' + T('pf.bestzeit_hinzufuegen') + ''),size:'large',
    body:'<div class="gm-field"><label>' + T('pf.sportart') + '</label>'+segHTML('pb_sport',sports.map(function(s){return [s.sportId,s.customName||_sportLabel(s)];}),(b&&b.sportId)||(sports[0]&&sports[0].sportId)||'')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.distanz_disziplin') + '</label><input id="pb_dist" value="'+escH(b?(b.distance||b.discipline):'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.zeit_z_b_24_30') + '</label><input id="pb_time" value="'+(b?M.formatDuration(b.timeSeconds):'')+'"><span class="ob2-err" id="pb_err" role="alert"></span></div>'+
    '<div class="gm-field"><label>' + T('pf.kontext') + '</label>'+segHTML('pb_ctx',[['race','' + T('pf.wettkampf') + ''],['training','' + T('pf.training') + '']],(b&&b.context)||'race')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.datum') + '</label><input type="date" id="pb_date" value="'+escH(b&&b.measuredAt?b.measuredAt:_today())+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.notiz_optional') + '</label><input id="pb_notes" value="'+escH(b?b.notes:'')+'"></div>',
    actions:'<button class="btn" onclick="savePbEditor(\''+(id||'')+'\')">' + T('pf.speichern') + '</button><button class="btn sec" onclick="_closeM(\'_perfSub\')">' + T('pf.abbrechen') + '</button>'});}
function savePbEditor(id){var M=_perfM();var perf=window._perfEd.perf;var secs=M.parseDuration((document.getElementById('pb_time')||{}).value);
  if(secs==null){document.getElementById('pb_err').textContent='' + T('pf.bitte_eine_gueltige_zeit_eingeben_') + '';return;}
  var rec={id:id||null,sportId:_segVal('pb_sport')||null,distance:(document.getElementById('pb_dist')||{}).value||'',discipline:(document.getElementById('pb_dist')||{}).value||'',timeSeconds:secs,context:_segVal('pb_ctx')||'race',measuredAt:(document.getElementById('pb_date')||{}).value||_today(),source:'manual',notes:(document.getElementById('pb_notes')||{}).value||''};
  if(id)perf.personalBests=perf.personalBests.map(function(x){return x.id===id?M.normalizePersonalBest(Object.assign({},x,rec)):x;});else perf.personalBests.push(M.normalizePersonalBest(rec));
  _closeM('_perfSub');_perfSave([]);}
function perfDelPb(id){window._perfEd.perf.personalBests=window._perfEd.perf.personalBests.filter(function(x){return x.id!==id;});_perfSave([]);}
/* Kraftwerte */
function openSrEditor(id){var M=_perfM();var perf=window._perfEd.perf;var r=id?perf.strengthRecords.filter(function(x){return x.id===id;})[0]:null;
  openSheet({id:'_perfSub',title:(r?'' + T('pf.kraftwert_bearbeiten') + '':'' + T('pf.kraftwert_hinzufuegen') + ''),size:'large',
    body:'<div class="gm-field"><label>' + T('pf.uebung') + '</label><input id="sr_ex" value="'+escH(r?r.exerciseName:'')+'"><span class="ob2-err" id="sr_err" role="alert"></span></div>'+
    '<div class="row2"><div class="gm-field"><label>' + T('pf.gewicht_kg') + '</label><input type="number" id="sr_w" value="'+(r&&r.weightKg!=null?r.weightKg:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.wiederholungen') + '</label><input type="number" id="sr_r" value="'+(r&&r.repetitions!=null?r.repetitions:'')+'"></div></div>'+
    '<div class="gm-field"><label>' + T('pf.satzart') + '</label>'+segHTML('sr_type',[['working','Arbeitssatz'],['top_set','' + T('pf.schwerster_satz') + ''],['test','Test'],['estimated_1rm','' + T('pf.geschaetztes_1rm') + '']],(r&&r.setType)||'working')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.datum') + '</label><input type="date" id="sr_date" value="'+escH(r&&r.measuredAt?r.measuredAt:_today())+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.notiz_optional') + '</label><input id="sr_notes" value="'+escH(r?r.notes:'')+'"></div>',
    actions:'<button class="btn" onclick="saveSrEditor(\''+(id||'')+'\')">' + T('pf.speichern') + '</button><button class="btn sec" onclick="_closeM(\'_perfSub\')">' + T('pf.abbrechen') + '</button>'});}
function saveSrEditor(id){var M=_perfM();var perf=window._perfEd.perf;var ex=(document.getElementById('sr_ex')||{}).value||'';
  if(!ex.trim()){document.getElementById('sr_err').textContent='' + T('pf.bitte_eine_uebung_angeben') + '';return;}
  function num(i){var e=document.getElementById(i);return e&&e.value!==''?parseFloat(e.value.replace(',','.')):null;}
  var rec={id:id||null,exerciseName:ex.trim(),weightKg:num('sr_w'),repetitions:num('sr_r'),setType:_segVal('sr_type')||'working',measuredAt:(document.getElementById('sr_date')||{}).value||_today(),source:'manual',notes:(document.getElementById('sr_notes')||{}).value||''};
  if(id)perf.strengthRecords=perf.strengthRecords.map(function(x){return x.id===id?M.normalizeStrengthRecord(Object.assign({},x,rec,{estimatedOneRepMax:null})):x;});else perf.strengthRecords.push(M.normalizeStrengthRecord(rec));
  _closeM('_perfSub');_perfSave([]);}
function perfDelSr(id){window._perfEd.perf.strengthRecords=window._perfEd.perf.strengthRecords.filter(function(x){return x.id!==id;});_perfSave([]);}

/* ============================================================
   REGENERATION & ALLTAG + TRAININGSPRÄFERENZEN (Inkrement 4g), strukturiert.
   ============================================================ */
function _recSports(){return (window.ORVIA&&ORVIA.profile&&ORVIA.profile.activeSports)?ORVIA.profile.activeSports():[];}
function openRecoveryEditor(){var M=pmModel();var r=M.normalizeRecovery(PROFILE.recovery,PROFILE.recovery);
  window._recEd={orig:JSON.stringify(r),r:JSON.parse(JSON.stringify(r))};var s=r.sleep,st=r.stress,wp=r.workPattern,ns=r.nutritionState,rp=r.recoveryPreferences;
  openSheet({id:'_recEdM',title:'' + T('pf.regeneration_und_alltag') + '',onClose:cancelRecoveryEditor,
    actions:'<button class="btn" onclick="saveRecoveryEditor()">' + T('pf.speichern') + '</button><button class="btn sec" onclick="cancelRecoveryEditor()">' + T('pf.abbrechen') + '</button>',
    body:'<p class="note" style="text-align:left">' + T('pf.orvia_nutzt_schlaf_und_stressdaten') + '</p>'+
    '<div class="gm-field"><label>' + T('pf.durchschnittliche_schlafdauer_h') + '</label><input type="number" id="rc_sleepH" value="'+(s.averageHours!=null?s.averageHours:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.schlafqualitaet') + '</label>'+segHTML('rc_sleepQ',[['very_bad','' + T('pf.sehr_schlecht') + ''],['bad','Schlecht'],['mid','Mittel'],['good','Gut'],['very_good','' + T('pf.sehr_gut') + '']],s.quality)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.schlafregelmaessigkeit') + '</label>'+segHTML('rc_sleepC',[['very_irregular','' + T('pf.sehr_unregelmaessig') + ''],['irregular','' + T('pf.eher_unregelmaessig') + ''],['varying','Wechselnd'],['regular','' + T('pf.regelmaessig') + ''],['very_regular','' + T('pf.sehr_regelmaessig') + '']],s.consistency)+'</div>'+
    '<div class="row2"><div class="gm-field"><label>' + T('pf.schlafenszeit') + '</label><input type="time" id="rc_bed" value="'+escH(s.bedtime||'')+'"></div><div class="gm-field"><label>' + T('pf.aufstehzeit') + '</label><input type="time" id="rc_wake" value="'+escH(s.wakeTime||'')+'"></div></div>'+
    '<div class="gm-field"><label>' + T('pf.stressniveau') + '</label>'+segHTML('rc_stress',[['low','Niedrig'],['mid','Mittel'],['high','Hoch'],['very_high','' + T('pf.sehr_hoch') + '']],st.generalLevel)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.arbeits_schulbelastung') + '</label>'+segHTML('rc_work',[['light','Leicht'],['normal','Normal'],['high','Hoch'],['very_high','' + T('pf.sehr_hoch') + '']],st.workSchoolLevel)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.alltag_koerperlich_belastend') + '</label>'+segHTML('rc_phys',[['no','' + T('pf.nein') + ''],['partly','Teilweise'],['often','Häufig']],wp.physicallyDemanding)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.arbeitsmodell') + '</label>'+segHTML('rc_shift',[['none','' + T('pf.keine_schichtarbeit') + ''],['early','Frühschicht'],['late','Spätschicht'],['night','Nachtschicht'],['rotating','' + T('pf.wechselnde_schichten') + ''],['irregular','Unregelmäßig']],wp.shiftType)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.aktuelle_ernaehrungssituation') + '</label>'+segHTML('rc_nut',[['deficit','Kaloriendefizit'],['maintain','' + T('pf.gewicht_halten') + ''],['surplus','Kalorienüberschuss'],['unknown','Unbekannt']],ns.mode)+'</div>'+
    '<div class="gm-field gm-inline"><input type="checkbox" id="rc_eal"'+(ns.energyAvailabilityLimited?' checked':'')+'><label>' + T('pf.energieverfuegbarkeit_aktuell_eingeschraenkt') + '</label></div>'+
    '<div class="gm-field gm-inline"><input type="checkbox" id="rc_arec"'+(rp.activeRecoveryAllowed?' checked':'')+'><label>' + T('pf.aktive_regeneration_erlaubt') + '</label></div>'});}
function _recCollect(){var r=window._recEd.r;function num(id){var e=document.getElementById(id);return e&&e.value!==''?parseFloat(e.value.replace(',','.')):null;}function val(id){var e=document.getElementById(id);return e?e.value:'';}
  r.sleep.averageHours=num('rc_sleepH');r.sleep.quality=_segVal('rc_sleepQ')||'';r.sleep.consistency=_segVal('rc_sleepC')||'';r.sleep.bedtime=val('rc_bed');r.sleep.wakeTime=val('rc_wake');
  r.stress.generalLevel=_segVal('rc_stress')||'';r.stress.workSchoolLevel=_segVal('rc_work')||'';
  r.workPattern.physicallyDemanding=_segVal('rc_phys')||'';r.workPattern.shiftType=_segVal('rc_shift')||'';
  r.nutritionState.mode=_segVal('rc_nut')||'';r.nutritionState.energyAvailabilityLimited=(document.getElementById('rc_eal')||{}).checked;
  r.recoveryPreferences.activeRecoveryAllowed=(document.getElementById('rc_arec')||{}).checked;return r;}
function saveRecoveryEditor(){PROFILE.recovery=pmModel().normalizeRecovery(_recCollect());_profileSave(['recovery']);_closeM('_recEdM');try{renderProfileScreen();}catch(e){}if(typeof toast==='function')toast('Gespeichert');}
function cancelRecoveryEditor(){_recCollect();if(pmModel().diffState(JSON.parse(window._recEd.orig),window._recEd.r)){
  _modal('_secDiscard','<h3>' + T('pf.aenderungen_verwerfen') + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.deine_letzten_anpassungen_wurden_noch') + '</p><button class="btn sec" onclick="_closeM(\'_secDiscard\')">' + T('pf.weiter') + ' bearbeiten</button><button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_secDiscard\');_closeM(\'_recEdM\')">' + T('pf.aenderungen_verwerfen_btn') + '</button>');
  }else _closeM('_recEdM');}

var PREF_DISLIKED=[['long_easy','' + T('pf.lange_ruhige_einheiten') + ''],['intervals','Intervalle'],['treadmill','Laufband'],['indoor_bike','Indoor-' + T('pf.rad') + ''],['heavy_compounds','' + T('pf.schwere_grunduebungen') + ''],['circuit','Zirkeltraining'],['long_strength','' + T('pf.sehr_lange_kraftsessions') + ''],['group_classes','Gruppenkurse'],['competition_sim','Wettkampfsimulationen'],['technique','Techniktraining']];
function openPreferencesEditor(){var M=pmModel();var p=M.normalizePreferences(PROFILE.preferences||PROFILE.trainingPrefs,PROFILE.trainingPrefs);
  window._prefEd={orig:JSON.stringify(p),p:JSON.parse(JSON.stringify(p))};var sports=_recSports();
  function chipset(id,opts,sel){return '<div class="gm-chips" id="'+id+'">'+opts.map(function(o){return '<button type="button" class="gm-chip'+(sel.indexOf(o[0])>=0?' on':'')+'" data-v="'+escH(o[0])+'" onclick="gmToggle(this)">'+escH(o[1])+'</button>';}).join('')+'</div>';}
  openSheet({id:'_prefEdM',title:'Trainingspräferenzen',onClose:cancelPreferencesEditor,
    actions:'<button class="btn" onclick="savePreferencesEditor()">' + T('pf.speichern') + '</button><button class="btn sec" onclick="cancelPreferencesEditor()">' + T('pf.abbrechen') + '</button>',
    body:'<div class="gm-field"><label>' + T('pf.anpassungs_modus_wie_greift_orvia') + '</label>'+segHTML('pf_adapt',[['manual','' + T('pf.nur_hinweis') + ''],['assisted','Vorschlag'],['automatic','Automatisch']],p.adaptationMode||'assisted')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.risikobereitschaft') + '</label>'+segHTML('pf_risk',[['conservative','Konservativ'],['balanced','Ausgewogen'],['ambitious','Ambitioniert']],p.riskTolerance||'balanced')+'</div>'+
    (sports.length?'<div class="gm-field"><label>' + T('pf.bevorzugte_sportarten') + '</label>'+chipset('pf_sports',sports.map(function(s){return [s.sportId,s.customName||_sportLabel(s)];}),p.preferredSports)+'</div>':'')+
    '<div class="gm-field"><label>' + T('pf.unbeliebte_trainingsformen') + '</label>'+chipset('pf_dislike',PREF_DISLIKED,p.dislikedTrainingForms)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.eigene_angabe_optional') + '</label><input id="pf_dislikeCustom" value="'+escH(p.dislikedCustom||'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.bevorzugte_einheitsdauer') + '</label>'+chipset('pf_dur',[['30','30 min'],['45','45 min'],['60','60 min'],['75','75 min'],['90','90 min'],['120','90+ min'],['0','Flexibel']],p.preferredSessionDurations.map(String))+'</div>'+
    '<div class="gm-field"><label>' + T('pf.umgebung') + '</label>'+segHTML('pf_env',[['indoor','' + T('pf.bevorzugt_indoor') + ''],['outdoor','' + T('pf.bevorzugt_outdoor') + ''],['both','Beides'],['none','' + T('pf.keine_praeferenz') + '']],p.preferredEnvironment)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.trainingszeiten') + '</label>'+chipset('pf_times',[['morning','Morgens'],['noon','Mittags'],['afternoon','Nachmittags'],['evening','Abends'],['flexible','Flexibel']],p.preferredTimes)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.intensitaetspraeferenz') + '</label>'+segHTML('pf_int',[['easy','' + T('pf.eher_locker') + ''],['balanced','Ausgeglichen'],['intense','' + T('pf.eher_intensiv') + ''],['none','' + T('pf.keine_praeferenz') + '']],p.intensityPreference)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.allein_oder_gruppe') + '</label>'+segHTML('pf_social',[['solo','Allein'],['group','Gruppe'],['both','Beides'],['none','' + T('pf.keine_praeferenz') + '']],p.socialPreference)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.abwechslung') + '</label>'+segHTML('pf_variety',[['low','' + T('pf.wenig_klare_wiederholung') + ''],['balanced','Ausgewogen'],['high','' + T('pf.viel_haeufig_wechselnd') + '']],p.varietyPreference)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.coaching_stil_optional') + '</label>'+segHTML('pf_coach',[['direct','' + T('pf.direkt_und_leistungsorientiert') + ''],['motivating','Motivierend'],['analytic','Analytisch'],['reserved','Zurückhaltend'],['none','' + T('pf.keine_praeferenz') + '']],p.coachingStyle)+'</div>'+
    '<div class="gm-field"><label>' + T('pf.zu_vermeidende_uebungen_optional_komma') + '</label><input id="pf_avoid" value="'+escH(p.avoidedExercises.map(function(e){return e.exerciseName;}).filter(Boolean).join(', '))+'"></div>'});}
function _prefChips(id){var c=document.getElementById(id);return c?Array.prototype.slice.call(c.querySelectorAll('.on')).map(function(b){return b.dataset.v;}):[];}
function _prefCollect(){var p=window._prefEd.p;
  p.preferredSports=_prefChips('pf_sports');p.dislikedTrainingForms=_prefChips('pf_dislike');p.dislikedCustom=(document.getElementById('pf_dislikeCustom')||{}).value||'';
  p.preferredSessionDurations=_prefChips('pf_dur').map(function(x){return parseInt(x,10);});
  p.preferredEnvironment=_segVal('pf_env')||'';p.preferredTimes=_prefChips('pf_times');p.intensityPreference=_segVal('pf_int')||'';p.socialPreference=_segVal('pf_social')||'';
  p.varietyPreference=_segVal('pf_variety')||'';p.coachingStyle=_segVal('pf_coach')||'';
  p.adaptationMode=_segVal('pf_adapt')||p.adaptationMode||'';p.riskTolerance=_segVal('pf_risk')||p.riskTolerance||'';   // P4
  var av=(document.getElementById('pf_avoid')||{}).value||'';var prev=p.avoidedExercises||[];
  p.avoidedExercises=av.split(',').map(function(s){return s.trim();}).filter(Boolean).map(function(name){var ex=prev.filter(function(e){return e.exerciseName===name;})[0];return ex||{exerciseId:null,exerciseName:name,reason:'',constraintId:null};});
  return p;}
function savePreferencesEditor(){PROFILE.preferences=pmModel().normalizePreferences(_prefCollect());
  /* P4: Legacy-Spiegel für bestehende Leser (buildTrainingDecision/calc) — geschrieben
     wird NUR hier; die Setup-Card ist read-only. */
  try{if(PROFILE.preferences.adaptationMode)PROFILE.adaptationMode=PROFILE.preferences.adaptationMode;
      if(PROFILE.preferences.riskTolerance)PROFILE.riskTolerance=PROFILE.preferences.riskTolerance;}catch(e){}
  _profileSave(['preferences']);_closeM('_prefEdM');try{renderProfileScreen();}catch(e){}if(typeof toast==='function')toast('Gespeichert');}
function cancelPreferencesEditor(){_prefCollect();if(pmModel().diffState(JSON.parse(window._prefEd.orig),window._prefEd.p)){
  _modal('_secDiscard','<h3>' + T('pf.aenderungen_verwerfen') + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.deine_letzten_anpassungen_wurden_noch') + '</p><button class="btn sec" onclick="_closeM(\'_secDiscard\')">' + T('pf.weiter') + ' bearbeiten</button><button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_secDiscard\');_closeM(\'_prefEdM\')">' + T('pf.aenderungen_verwerfen_btn') + '</button>');
  }else _closeM('_prefEdM');}

/* ============================================================
   GERÄTE, TRAININGSAUSSTATTUNG & DATENQUELLEN (Inkrement 4h). Keine Fake-Verbindungen.
   ============================================================ */
var INT_STATUS_DE={not_available:T('pf.nicht_verfuegbar_'),not_connected:T('pf.nicht_verbunden_'),connecting:T('pf.verbindung_wird_hergestellt'),connected:T('pf.verbunden_'),permission_required:T('pf.berechtigung_erforderlich'),error:T('pf.fehler_'),sync_paused:T('pf.synchronisierung_pausiert')};
var INT_NAME_DE={strava:'Strava',garmin:'Garmin',appleHealth:'' + T('pf.apple_health') + ''};
var CAP_DE={activities:'Aktivitäten',heartRate:'Herzfrequenz',route:'Strecke',distance:'Distanz',pace:'Pace',power:'Leistung',sleep:'Schlaf',hrv:'HRV',bodyWeight:'' + T('pf.gewicht') + '',workouts:'Workouts'};
var EQUIP_GROUPS=[['' + T('pf.ausdauer') + '',[['road_bike','Rennrad'],['gravel_bike','Gravelbike'],['mtb','Mountainbike'],['indoor_trainer','Indoor-Trainer'],['treadmill','Laufband'],['row_erg','Ruderergometer'],['ski_erg','SkiErg'],['air_bike','AirBike'],['cross_trainer','Crosstrainer']]],['Krafttraining',[['gym_access','Fitnessstudio'],['barbell','Langhantel'],['dumbbells','Kurzhanteln'],['machines','Maschinen'],['cable','Kabelzug'],['kettlebells','Kettlebells'],['pullup_bar','Klimmzugstange'],['bands','Widerstandsbänder'],['home_gym','Home-Gym']]],['Schwimmen',[['pool25','25-m-Pool'],['pool50','50-m-Pool'],['open_water','Freiwasserzugang'],['pullbuoy','Pullbuoy'],['paddles','Paddles'],['fins','Flossen']]],['HYROX',[['hx_ski','SkiErg'],['hx_row','RowErg'],['hx_sled_push','' + T('pf.sled_push') + ''],['hx_sled_pull','' + T('pf.sled_pull') + ''],['hx_wallball','' + T('pf.wall_balls') + ''],['hx_sandbag','Sandbag'],['hx_farmers','Farmers-Carry-Gewichte']]],['Sonstiges',[['other','' + T('pf.eigene_ausstattung') + '']]]];
var EQUIP_LABEL={};EQUIP_GROUPS.forEach(function(g){g[1].forEach(function(p){EQUIP_LABEL[p[0]]=p[1];});});
var LOC_TYPES=[['gym','Fitnessstudio'],['home','Zuhause'],['club','Verein'],['pool','Schwimmbad'],['track','Laufbahn'],['outdoor','Outdoor'],['other','' + T('pf.sonstiger_ort') + '']];
var MANUAL_TYPES=[['manual','' + T('pf.manuelle_eingabe') + ''],['gpx','GPX-Datei'],['tcx','TCX-Datei'],['csv','CSV-Import'],['other','' + T('pf.sonstiger_import') + '']];
function _devM(){return pmModel();}
function openDevicesManager(){var M=_devM();_eqEnsureMigrated();window._devEd={dev:M.normalizeDevices(PROFILE.devices,PROFILE.dataSources)};_modal('_devMgr','<div id="devBody"></div>');renderDevicesManager();}
function _devPersist(){var M=_devM();PROFILE.devices=M.normalizeDevices(window._devEd.dev,PROFILE.dataSources);_profileSave(['devices']);renderDevicesManager();if(typeof toast==='function')toast('Gespeichert');}
function renderDevicesManager(){var M=_devM();var dev=window._devEd.dev;var box=document.getElementById('devBody');if(!box)return;
  var eq=dev.equipment.filter(function(e){return e.available;});
  var intCards=M.INTEGRATION_IDS.map(function(k){var i=dev.integrations[k];var bits=[INT_STATUS_DE[i.status]||i.status];
    if(i.connected&&i.lastSyncAt)bits.push('' + T('pf.letzte_synchronisierung') + ''+i.lastSyncAt);
    if(i.connected&&i.capabilities.length)bits.push(i.capabilities.map(function(c){return CAP_DE[c]||c;}).join(', '));
    if(i.status==='error'&&i.errorCode)bits.push('' + T('pf.fehler') + ''+i.errorCode);
    var note=(k==='garmin'&&!i.connected)?'<div class="gmc-meta">' + T('pf.noch_nicht_verbunden_die_synchronisierung') + '</div>':((k==='appleHealth'&&i.status==='not_available')?'<div class="gmc-meta">' + T('pf.in_dieser_version_nicht_verfuegbar') + '</div>':(k==='strava'&&!i.connected?'<div class="gmc-meta">' + T('pf.import_per_gpx_tcx_json') + '</div>':''));
    return '<div class="gmcard"><div class="gmc-h">'+INT_NAME_DE[k]+'</div><div class="gmc-meta">'+escH(bits.join(' · '))+'</div>'+note+(i.connected?'<div class="gmc-acts"><button class="gmc-b danger-btn" onclick="devDisconnect(\''+k+'\')">Trennen</button></div>':'')+'</div>';}).join('');
  var legacy=(dev._legacyText&&dev._legacyText.length)?'<div class="gmc-meta">Alte Angaben: '+escH(dev._legacyText.join(', '))+'</div>':'';
  box.innerHTML='<h3>' + T('pf.geraete_und_datenquellen') + '</h3>'+
    '<div class="gmcard"><div class="gmc-h">Trainingsausstattung ('+eq.length+'' + T('pf.verfuegbar_n') + '</div>'+(dev.equipment.length?dev.equipment.map(function(e){return '<div class="gw-ms"><span>'+escH((EQUIP_LABEL[e.type]||e.label||e.type)+(e.available?'':'' + T('pf.nicht_verfuegbar') + ''))+'</span><button class="gmc-b" onclick="openEquipmentEditor(\''+e.id+'\')">✎</button><button class="gmc-b danger-btn" onclick="devDelEquip(\''+e.id+'\')">✕</button></div>';}).join(''):'<p class="note" style="text-align:left">' + T('pf.keine_ausstattung') + '</p>')+'<div class="gmc-acts"><button class="gmc-b" onclick="openEquipmentEditor()">' + T('pf.ausstattung_hinzufuegen') + '</button></div></div>'+
    '<div class="gmcard"><div class="gmc-h">Trainingsorte ('+dev.trainingLocations.length+')</div>'+(dev.trainingLocations.length?dev.trainingLocations.map(function(l){return '<div class="gw-ms"><span>'+escH((l.name||_locTypeLabel(l.type)))+'</span><button class="gmc-b" onclick="openLocationEditor(\''+l.id+'\')">✎</button><button class="gmc-b danger-btn" onclick="devDelLoc(\''+l.id+'\')">✕</button></div>';}).join(''):'<p class="note" style="text-align:left">' + T('pf.keine_orte') + '</p>')+'<div class="gmc-acts"><button class="gmc-b" onclick="openLocationEditor()">' + T('pf.trainingsort_hinzufuegen') + '</button></div></div>'+
    '<div class="gm-sec">' + T('pf.datenintegrationen') + '</div>'+intCards+
    '<div class="gmcard"><div class="gmc-h">' + T('pf.manuelle_datenquellen') + '</div><div class="gm-chips" id="dev_manual">'+MANUAL_TYPES.map(function(t){var on=dev.manualSources.some(function(m){return m.type===t[0];});return '<button type="button" class="gm-chip'+(on?' on':'')+'" data-v="'+t[0]+'" onclick="gmToggle(this)">'+escH(t[1])+'</button>';}).join('')+'</div><div class="gmc-acts"><button class="gmc-b" onclick="devSaveManual()">' + T('pf.datenquellen_speichern') + '</button></div></div>'+
    legacy+'<div class="gm-modal-actions"><button class="btn sec" onclick="_closeM(\'_devMgr\')">' + T('pf.schliessen') + '</button></div>';}
function _locTypeLabel(t){var p=LOC_TYPES.filter(function(x){return x[0]===t;})[0];return p?p[1]:t;}
function devDisconnect(k){_modal('_devSubC','<h3>' + T('pf.trennen_q', { name: INT_NAME_DE[k] }) + '</h3><p class="modtext" style="margin:0 0 14px">' + T('pf.verbindung_getrennt_hinweis') + '</p><button class="btn sec" onclick="_closeM(\'_devSubC\')">' + T('pf.abbrechen') + '</button><button class="btn danger-btn" style="margin-top:10px" onclick="_closeM(\'_devSubC\');_devDoDisconnect(\''+k+'\')">Trennen</button>');}
function _devDoDisconnect(k){window._devEd.dev.integrations[k]={status:'not_connected',connected:false,lastSyncAt:null,capabilities:[],accountLabel:null,errorCode:null};_devPersist();}
function openEquipmentEditor(id){var M=_devM();var dev=window._devEd.dev;var e=id?dev.equipment.filter(function(x){return x.id===id;})[0]:null;
  // P6: Katalog gefiltert nach AKTIVEN Sportarten (sportartfremde Typen erscheinen nicht);
  // beim Bearbeiten bleibt der bestehende Typ immer wählbar (auch wenn Sportart inaktiv).
  var actIds=(window.ORVIA&&ORVIA.profile&&ORVIA.profile.activeSports)?ORVIA.profile.activeSports().map(function(x){return x.sportId;}):[];
  var groups=M.equipmentCatalogFor(actIds);
  if(e&&e.type){var present=groups.some(function(g){return g[1].some(function(p){return p[0]===e.type;});});
    if(!present){var lbl=(EQUIP_LABEL[e.type]||e.type)+'' + T('pf.sportart_inaktiv') + '';groups=groups.concat([['Bestehend',[[e.type,lbl]]]]);}}
  var wear=e&&e.wear?e.wear:null;
  _modal('_devSub','<h3>'+(e?'' + T('pf.ausstattung_bearbeiten') + '':'' + T('pf.ausstattung_hinzufuegen') + '')+'</h3>'+
    '<div class="gm-field"><label>' + T('pf.geraet') + '</label>'+segGroupedHTML('eq_type',groups,(e&&e.type)||'')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.bezeichnung_optional') + '</label><input id="eq_label" value="'+escH(e?e.label:'')+'"></div>'+
    '<div class="row2"><div class="gm-field"><label>' + T('pf.bisherige_km_optional') + '</label><input type="number" id="eq_startkm" value="'+(wear&&wear.startKm!=null?wear.startKm:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.wechsel_limit_km_optional') + '</label><input type="number" id="eq_limitkm" value="'+(wear&&wear.limitKm!=null?wear.limitKm:'')+'"></div></div>'+
    '<div class="gm-field gm-inline"><input type="checkbox" id="eq_avail"'+(!e||e.available?' checked':'')+'><label>Verfügbar</label></div>'+
    '<div class="gm-field"><label>' + T('pf.notiz_optional') + '</label><input id="eq_notes" value="'+escH(e?e.notes:'')+'"></div>'+
    '<div class="gm-modal-actions"><button class="btn" onclick="saveEquipmentEditor(\''+(id||'')+'\')">' + T('pf.speichern') + '</button><button class="btn sec" style="margin-top:10px" onclick="_closeM(\'_devSub\')">' + T('pf.abbrechen') + '</button></div>');}
function saveEquipmentEditor(id){var M=_devM();var dev=window._devEd.dev;
  function num(i){var el=document.getElementById(i);if(!el||el.value==='')return null;var n=parseFloat(String(el.value).replace(',','.'));return isNaN(n)?null:n;}
  var startKm=num('eq_startkm'),limitKm=num('eq_limitkm');
  var rec={id:id||null,type:_segVal('eq_type')||'other',label:(document.getElementById('eq_label')||{}).value||'',available:(document.getElementById('eq_avail')||{}).checked,notes:(document.getElementById('eq_notes')||{}).value||''};
  if(startKm!=null||limitKm!=null)rec.wear={limitKm:limitKm,startKm:startKm||0,since:(id&&dev.equipment.filter(function(x){return x.id===id;})[0]||{}).wear?dev.equipment.filter(function(x){return x.id===id;})[0].wear.since:(typeof todayStr==='function'?todayStr():null)};
  if(id)dev.equipment=dev.equipment.map(function(x){return x.id===id?M.normalizeEquipment(Object.assign({},x,rec)):x;});else dev.equipment.push(M.normalizeEquipment(rec));_closeM('_devSub');_devPersist();}
function devDelEquip(id){window._devEd.dev.equipment=window._devEd.dev.equipment.filter(function(x){return x.id!==id;});_devPersist();}
function openLocationEditor(id){var dev=window._devEd.dev;var l=id?dev.trainingLocations.filter(function(x){return x.id===id;})[0]:null;
  var caps=[['barbell','Langhantel'],['machines','Maschinen'],['cable','Kabelzug'],['pool','Pool'],['track','Bahn'],['cardio','Cardio']];
  _modal('_devSub','<h3>'+(l?'' + T('pf.trainingsort_bearbeiten') + '':'' + T('pf.trainingsort_hinzufuegen') + '')+'</h3>'+
    '<div class="gm-field"><label>' + T('pf.typ') + '</label>'+segHTML('loc_type',LOC_TYPES,(l&&l.type)||'gym')+'</div>'+
    '<div class="gm-field"><label>' + T('pf.name') + '</label><input id="loc_name" value="'+escH(l?l.name:'')+'"></div>'+
    '<div class="gm-field"><label>' + T('pf.ausstattung_vor_ort') + '</label><div class="gm-chips" id="loc_caps">'+caps.map(function(c){var on=l&&(l.capabilities||[]).indexOf(c[0])>=0;return '<button type="button" class="gm-chip'+(on?' on':'')+'" data-v="'+c[0]+'" onclick="gmToggle(this)">'+escH(c[1])+'</button>';}).join('')+'</div></div>'+
    '<div class="gm-field"><label>' + T('pf.verfuegbare_tage_') + '</label><div class="gm-chips" id="loc_days">'+pmModel().WEEKDAYS.map(function(d){var on=l&&(l.availableDays||[]).indexOf(d)>=0;return '<button type="button" class="gm-chip'+(on?' on':'')+'" data-v="'+d+'" onclick="gmToggle(this)">'+WD_DE[d]+'</button>';}).join('')+'</div></div>'+
    '<div class="gm-modal-actions"><button class="btn" onclick="saveLocationEditor(\''+(id||'')+'\')">' + T('pf.speichern') + '</button><button class="btn sec" style="margin-top:10px" onclick="_closeM(\'_devSub\')">' + T('pf.abbrechen') + '</button></div>');}
function saveLocationEditor(id){var M=_devM();var dev=window._devEd.dev;function chips(i){var c=document.getElementById(i);return c?Array.prototype.slice.call(c.querySelectorAll('.on')).map(function(b){return b.dataset.v;}):[];}
  var rec={id:id||null,type:_segVal('loc_type')||'gym',name:(document.getElementById('loc_name')||{}).value||'',capabilities:chips('loc_caps'),availableDays:chips('loc_days')};
  if(id)dev.trainingLocations=dev.trainingLocations.map(function(x){return x.id===id?M.normalizeTrainingLocation(Object.assign({},x,rec)):x;});else dev.trainingLocations.push(M.normalizeTrainingLocation(rec));_closeM('_devSub');_devPersist();}
function devDelLoc(id){window._devEd.dev.trainingLocations=window._devEd.dev.trainingLocations.filter(function(x){return x.id!==id;});_devPersist();}
function devSaveManual(){var c=document.getElementById('dev_manual');var sel=c?Array.prototype.slice.call(c.querySelectorAll('.on')).map(function(b){return b.dataset.v;}):[];
  var lab={};MANUAL_TYPES.forEach(function(t){lab[t[0]]=t[1];});window._devEd.dev.manualSources=sel.map(function(t){return {id:'ms:'+t,type:t,label:lab[t]||t};});_devPersist();}
