/* B-13: nutzersichtbare Texte ueber t() (locales/de.js). Lokaler Name, damit das globale T aus profile.js nicht doppelt deklariert wird. */
var _actT = function (k, p) { try { var I = window.ORVIA && window.ORVIA.i18n; if (I && typeof I.t === 'function') return I.t(k, p); } catch (e) {} return String(k); };
/* ============================================================
   ORVIA — Aktivität  (Phase 4)
   Aktivitäten-Liste, ORVIA Workout Card mit eigener SVG-Streckenkarte,
   Mock-Import mit Import-Animation, manuelle Aktivität.
   Liest/schreibt Trainings in DB[date].sessions[typ]; route optional.
   ============================================================ */

/* ---- Encoded-Polyline-Decoder (Google/Strava) → [[lat,lng],...] ---- */
function decodePolyline(str, precision) {
  if (!str) return [];
  var index = 0, lat = 0, lng = 0, out = [], shift, result, byte, factor = Math.pow(10, precision || 5);
  while (index < str.length) {
    shift = 0; result = 0;
    do { byte = str.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20);
    lat += (result & 1) ? ~(result >> 1) : (result >> 1);
    shift = 0; result = 0;
    do { byte = str.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20);
    lng += (result & 1) ? ~(result >> 1) : (result >> 1);
    out.push([lat / factor, lng / factor]);
  }
  return out;
}

/* ---- ORVIA-eigene Streckenkarte als SVG (Gold-Linie, dunkel, ohne Tiles) ---- */
/* opts (optional, rein darstellend — Geometrie der Strecke bleibt unveraendert):
     aspect:'auto'  viewBox uebernimmt das echte Seitenverhaeltnis der Strecke, statt sie
                    in eine feste 320x180-Kachel zu setzen (Story-Cover nutzt so die volle
                    Seitenhoehe formtreu).
     noBg:true      ohne Hintergrundflaeche (freistehende Route).
   Ohne opts verhaelt sich die Funktion exakt wie bisher. */
function routeSVG(pts, opts) {
  if (!pts || pts.length < 2) return '';
  opts = opts || {};
  var lats = pts.map(function (p) { return p[0]; }), lngs = pts.map(function (p) { return p[1]; });
  var minLat = Math.min.apply(null, lats), maxLat = Math.max.apply(null, lats);
  var midLat = (minLat + maxLat) / 2, cos = Math.cos(midLat * Math.PI / 180);
  var xs = pts.map(function (p) { return (p[1]) * cos; });
  var ys = pts.map(function (p) { return -(p[0]); });
  var minX = Math.min.apply(null, xs), maxX = Math.max.apply(null, xs);
  var minY = Math.min.apply(null, ys), maxY = Math.max.apply(null, ys);
  var W = 320, H = 180, pad = 20;
  var spanX = (maxX - minX) || 1e-6, spanY = (maxY - minY) || 1e-6;
  if (opts.aspect === 'auto') {
    /* Laengere Achse auf 320 normieren, kuerzere proportional — dadurch bleibt die Form
       exakt erhalten und das SVG fuellt den verfuegbaren Raum ohne Leerraender. */
    var ratio = spanY / spanX;
    if (ratio >= 1) { H = 320; W = Math.max(120, Math.round(320 / ratio)); }
    else { W = 320; H = Math.max(120, Math.round(320 * ratio)); }
    pad = 16;
  }
  var scale = Math.min((W - 2 * pad) / spanX, (H - 2 * pad) / spanY);
  var offX = (W - spanX * scale) / 2, offY = (H - spanY * scale) / 2;
  var px = function (i) { return (offX + (xs[i] - minX) * scale).toFixed(1); };
  var py = function (i) { return (offY + (ys[i] - minY) * scale).toFixed(1); };
  var d = pts.map(function (p, i) { return (i ? 'L' : 'M') + px(i) + ' ' + py(i); }).join(' ');
  var last = pts.length - 1;
  return '<svg class="rmap" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="xMidYMid meet" aria-hidden="true">' +
    (opts.noBg ? '' : '<rect x="0" y="0" width="' + W + '" height="' + H + '" rx="16" fill="#0b121d"/>') +
    '<path d="' + d + '" fill="none" stroke="url(#orviaMarkGrad)" stroke-width="3" stroke-linejoin="round" stroke-linecap="round" filter="drop-shadow(0 0 5px rgba(201,174,124,.45))"/>' +
    '<circle cx="' + px(0) + '" cy="' + py(0) + '" r="4.5" fill="#34c77b"/>' +
    '<circle cx="' + px(last) + '" cy="' + py(last) + '" r="4.5" fill="#e5556a"/></svg>';
}

/* GM7.8: geschlossener Legacy-Typsatz der DB-Sessions (deutsche Schluessel) -> kanonische
   Sport-ID. Dient AUSSCHLIESSLICH als letzte Aufloesung im Verknuepfungs-Guard, damit der
   Schutz nicht an einem optionalen Modul haengt. Keine Anzeige-Logik. */
var LEGACY_TYPE_SPORT = { 'Laufen': 'running', 'Rad': 'cycling', 'Radfahren': 'cycling', 'Schwimmen': 'swimming',
  'Gym': 'gym', 'Krafttraining': 'gym', 'Mobilität': 'mobility', 'Mobilitaet': 'mobility', 'Wandern': 'hiking', 'Gehen': 'walking' };
/* ---- Aktivität-Helfer ---- */
var ACT_TYPES = { Laufen: { ic: 'run', unit: 'km' }, Rad: { ic: 'bike', unit: 'km' }, Schwimmen: { ic: 'swim', unit: 'm' }, Gym: { ic: 'dumbbell', unit: '' }, 'Mobilität': { ic: 'stretch', unit: '' } };
function actRoute(s) { if (!s) return null; if (Array.isArray(s.route) && s.route.length > 1) return s.route; if (s.polyline) { try { var p = decodePolyline(s.polyline); return p.length > 1 ? p : null; } catch (e) {} } return null; }
function isIndoorType(typ, s) { if (s && s.indoor) return true; return typ === 'Gym' || typ === 'Mobilität' || typ === 'Schwimmen'; }
function paceStr(distKm, durMin) { if (!distKm || !durMin) return '–'; return Calc.fmtPace(durMin * 60 / distKm) + '/km'; }

/* ---- ORVIA-Bewertung (Pace vs. Easy-Zone des Ziels) ---- */
function rateActivity(typ, s) {
  if (typ !== 'Laufen' || !s.dist || !s.dur) return null;
  // Unplausible Läufe nicht loben — sie fließen auch nicht in Statistik/Prognose.
  if (typeof Calc !== 'undefined' && Calc.isValidRunForAnalytics && !Calc.isValidRunForAnalytics(s)) {
    return { badge: '' + _actT('act.daten_pruefen') + '', cls: 'r', txt: '' + _actT('act.die_werte_wirken_fuer_einen') + '', next: '' + _actT('act.sportart_oder_werte_bearbeiten') + '' };
  }
  var pace = s.dur * 60 / s.dist; // sec/km
  var g = (typeof goalOf === 'function') ? goalOf() : null;
  var zones = (g && g.targetMin && typeof Calc.paceZones === 'function') ? Calc.paceZones(g.distanceKm, g.targetMin) : null;
  if (!zones) {
    return { badge: 'erfasst', cls: 'y', txt: '' + _actT('act.pace') + '' + Calc.fmtPace(pace) + '' + _actT('act.km_lege_eine_zielzeit_fest') + '', next: '' };
  }
  var easy = zones.find(function (z) { return z.k === 'Easy'; });
  var tgt = zones.find(function (z) { return z.k === 'Zielpace'; });
  // Heuristik: lange/langsame Läufe = Easy-Vergleich
  if (pace < easy.lo - 25) return { badge: 'stark / schnell', cls: 'g', txt: '' + _actT('act.deutlich_schneller_als_easy') + '' + Calc.fmtPace(easy.lo) + '–' + Calc.fmtPace(easy.hi) + '' + _actT('act.das_war_eine_qualitaets_oder') + '', next: '' + _actT('act.auf_einen_leichten_tag_danach') + '' };
  if (pace < easy.lo) return { badge: 'leicht zu schnell', cls: 'y', txt: '' + _actT('act.schneller_als_der_easy_bereich') + '' + Calc.fmtPace(easy.lo) + '–' + Calc.fmtPace(easy.hi) + '' + _actT('act.easy_laeufe_bringen_mehr_wenn') + '', next: '' + _actT('act.naechster_easy_run_10_15') + '' };
  if (pace <= easy.hi + 10) return { badge: 'kontrolliert', cls: 'g', txt: '' + _actT('act.sauber_im_easy_bereich') + '' + Calc.fmtPace(easy.lo) + '–' + Calc.fmtPace(easy.hi) + '' + _actT('act.genau_richtig_fuer_grundlage') + '', next: '' + _actT('act.so_weitermachen') + '' };
  return { badge: 'sehr locker', cls: 'g', txt: '' + _actT('act.langsamer_als_easy_als_recovery') + '', next: '' + _actT('act.fuer_tempoeffekt_gezielt_eine_schnellere') + '' };
}

/* ---- ORVIA Workout Card ---- */
function workoutCardHTML(date, typ, s) {
  var meta = ACT_TYPES[typ] || { ic: 'pulse', unit: '' };
  var route = actRoute(s);
  var rows = [];
  /* P1A: de-DE-Zahlenformat — fmtDe (ui.js) statt toFixed (kein „7.20 km" mehr). */
  if (s.dist != null) rows.push(['Distanz', (typ === 'Schwimmen' ? s.dist + ' m' : fmtDe(s.dist) + ' km')]);
  if (s.dur != null) rows.push(['Zeit', Calc.fmtDuration(s.dur, 'min')]);
  if (typ === 'Laufen' && s.dist && s.dur) rows.push(['Pace', paceStr(s.dist, s.dur)]);
  if (typ === 'Rad' && s.dist && s.dur) rows.push(['Schnitt', fmtDe(s.dist / (s.dur / 60)) + ' km/h']);
  if (s.hr != null) rows.push(['' + _actT('act.hf') + '', s.hr + ' bpm']);
  if (s.cad != null) rows.push(['Schrittfreq.', s.cad + ' spm']);
  if (s.gearId && typeof gearName === 'function') { var _gn = gearName(s.gearId); if (_gn) rows.push([typ === 'Rad' ? 'Rad' : 'Schuhe', _gn]); }
  if (s.elev != null) rows.push(['' + _actT('act.hoehenmeter') + '', Math.round(s.elev) + ' m']);
  if (s.rpe != null) rows.push(['RPE', s.rpe + '/10']);
  var rate = rateActivity(typ, s);
  var dlabel = (typeof relDayTitle === 'function') ? relDayTitle(date) : date;
  return '<div class="wcard">' +
    '<div class="wc-head"><span class="wc-brand"><svg class="omark" viewBox="0 0 512 512" aria-hidden="true"><use href="#orvia-mark"/></svg>ORVIA</span>' +
      '<span class="wc-type"><svg class="ic"><use href="#i-' + meta.ic + '"/></svg>' + escH(typ) + '</span></div>' +
    '<div class="wc-title">' + escH(typ) + (s.dist != null && typ !== 'Schwimmen' ? ' · ' + fmtDe(s.dist) + ' km' : '') + '</div>' +
    '<div class="wc-day">' + escH(dlabel) + (s.note ? ' · ' + escH(s.note) : '') + '</div>' +
    (route ? '<div class="wc-map">' + routeSVG(route) + '</div>' : '<div class="wc-nomap">' + (isIndoorType(typ, s) ? '' + _actT('act.indoor_aktivitaet_ohne_gps_route') + '' : '' + _actT('act.fuer_diese_aktivitaet_sind_keine') + '') + '</div>') +
    '<div class="wc-stats">' + rows.map(function (r) { return '<div class="wc-stat"><span class="wc-sv">' + escH(r[1]) + '</span><span class="wc-sk">' + escH(r[0]) + '</span></div>'; }).join('') + '</div>' +
    ((s.splits && s.splits.length && typeof splitsMiniHTML === 'function') ? splitsMiniHTML(s.splits) : '') +
    (function () { var lg = (s.exLog && s.exLog.length) ? s.exLog : ((s.exercises && s.exercises.length) ? s.exercises.map(function (n) { return { n: n }; }) : null); if (!lg) return ''; return '<div class="wc-ex"><div class="wc-ex-h">' + _actT('act.uebungen_n', { n: lg.length }) + '</div>' + lg.map(function (x) { var det = []; if (x.sets != null || x.reps != null) det.push((x.sets != null ? x.sets : '?') + '×' + (x.reps != null ? x.reps : '?')); if (x.kg != null) det.push(x.kg + ' kg'); return '<div class="wc-exrow"><span class="wc-exrow-n">' + escH(x.n) + '</span>' + (det.length ? '<span class="wc-exrow-d">' + escH(det.join(' · ')) + '</span>' : '') + '</div>'; }).join('') + '</div>'; })() +
    (rate ? '<div class="wc-rate"><span class="wc-badge wc-' + rate.cls + '">' + escH(rate.badge) + '</span>' +
      '<p class="wc-analysis">' + escH(rate.txt) + '</p>' +
      (rate.next ? '<p class="wc-next"><b>' + _actT('act.naechste_einheit') + '</b> ' + escH(rate.next) + '</p>' : '') + '</div>' : '') +
    '</div>';
}

/* ---- Aktivität-Detail als Sheet ---- */
function openActivity(date, typ) {
  // AD1b-Legacy-Adapter: löst (Datum, Typ) auf die kanonische Legacy-Activity-ID auf und
  // öffnet den EINEN Renderer. Kein eigenes Overlay, keine Datum-only-Blind-Auswahl.
  if (date && typeof date === 'object' && date.dataset) { typ = date.dataset.t; date = date.dataset.d; }
  if (!date || !typ) return openActivityDetail(null, 'legacy_adapter');
  var leg = null; try { leg = _legacyActivities().find(function (x) { return x._legacy && x._legacy.date === date && x._legacy.type === typ; }); } catch (e) {}
  return openActivityDetail(leg ? leg.clientRecordId : ('legacy:' + date + ':' + typ), 'legacy_adapter');
}
function closeActivity() { if (window._actModal) { try { window._actModal.remove(); } catch (e) {} window._actModal = null; } closeActivityDetail(); }

/* ---- Aktivität bearbeiten (Phase 4.4): Sportart/Datum/Werte korrigieren, atomar neu berechnen ---- */
var EDIT_TYPES = ['Laufen', 'Rad', 'Schwimmen', 'Gym', 'Mobilität', 'Wandern'];
function closeEditActivity() { if (window._editModal) { try { window._editModal.remove(); } catch (e) {} window._editModal = null; } }
function openEditActivity(date, typ) {
  var e = DB[date]; if (!e || !e.sessions || !e.sessions[typ]) return;
  var s = e.sessions[typ];
  var chips = EDIT_TYPES.map(function (t, i) { return '<button type="button" class="gm-chip' + (t === typ ? ' on' : '') + '" data-v="' + t + '" onclick="gmPick(this,\'eaType\')">' + t + '</button>'; }).join('');
  var src = s.externalId ? 'Import' : (s.source === 'live' ? 'Live-Workout' : (s.note || 'Manuell'));
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg';
  wrap.innerHTML = '<div class="orvia-modal goal-modal"><h3>' + _actT('act.aktivitaet_bearbeiten') + '</h3>' +
    '<div class="gm-field"><label>' + _actT('act.sportart') + '</label><div class="gm-chips" id="eaType">' + chips + '</div></div>' +
    '<div class="gm-field"><label>' + _actT('act.untertyp_optional') + '</label><input id="eaSub" value="' + escH(s.sub || '') + '" placeholder="' + _actT('act.z_b_easy_run_intervall') + '"></div>' +
    '<div class="gm-field"><label>' + _actT('act.datum') + '</label><input type="date" id="eaDate" value="' + escH(date) + '"></div>' +
    '<div class="row2"><div class="gm-field"><label>' + _actT('act.distanz_km_schwimmen_m') + '</label><input type="number" inputmode="decimal" id="eaDist" value="' + (s.dist != null ? s.dist : '') + '"></div>' +
    '<div class="gm-field"><label>' + _actT('act.dauer_min') + '</label><input type="number" inputmode="numeric" id="eaDur" value="' + (s.dur != null ? s.dur : '') + '"></div></div>' +
    '<div class="row2"><div class="gm-field"><label>' + _actT('act.hf') + '</label><input type="number" inputmode="numeric" id="eaHr" value="' + (s.hr != null ? s.hr : '') + '"></div>' +
    '<div class="gm-field"><label>' + _actT('act.hf_max') + '</label><input type="number" inputmode="numeric" id="eaHrMax" value="' + (s.hrMax != null ? s.hrMax : '') + '"></div></div>' +
    '<div class="row2"><div class="gm-field"><label>' + _actT('act.hoehenmeter') + '</label><input type="number" inputmode="numeric" id="eaElev" value="' + (s.elev != null ? s.elev : '') + '"></div>' +
    '<div class="gm-field"><label>' + _actT('act.rpe_1_10') + '</label><input type="number" inputmode="numeric" id="eaRpe" value="' + (s.rpe != null ? s.rpe : '') + '"></div></div>' +
    '<div class="gm-field"><label>' + _actT('act.notiz') + '</label><input id="eaNote" value="' + escH(s.note || '') + '"></div>' +
    '<p class="note" style="text-align:left">Quelle: ' + escH(src) + (s.externalId ? '' + _actT('act.id_bleibt_erhalten') + '' : '') + '</p>' +
    '<button class="btn" onclick="saveEditActivity(\'' + date + '\',\'' + escH(typ) + '\')">' + _actT('act.speichern') + '</button>' +
    '<button class="btn sec" style="margin-top:10px" onclick="deleteActivity(\'' + date + '\',\'' + escH(typ) + '\')">' + _actT('act.aktivitaet_loeschen') + '</button>' +
    '<button class="btn sec" style="margin-top:10px" onclick="closeEditActivity()">' + _actT('act.aenderungen_verwerfen') + '</button></div>';
  document.body.appendChild(wrap); window._editModal = wrap;
  wrap.addEventListener('click', function (ev) { if (ev.target === wrap) closeEditActivity(); });
}
function _eaNum(id) { var el = document.getElementById(id); if (!el || el.value === '') return null; var n = parseFloat(el.value.replace(',', '.')); return isNaN(n) ? null : n; }
function _mvInvalidate() {
  try { if (typeof invalidateDecision === 'function') invalidateDecision(); } catch (e) {}
  try { _goalCache = null; } catch (e) {}
  try { window._goalCache = null; } catch (e) {}
  try { window._mvData = null; } catch (e) {}
}
function _mvRerender() {
  _mvInvalidate();
  if (typeof save === 'function') save();
  try { if (typeof renderDay === 'function') renderDay(); } catch (e) {}
  try { if (typeof renderAkt === 'function') renderAkt(); } catch (e) {}
  try { if (typeof renderDash === 'function') { var dash = document.getElementById('tab-dash'); if (dash && !dash.classList.contains('hide')) renderDash(); } } catch (e) {}
}
var EDIT_DISTANCE_SPORTS = ['Laufen', 'Rad', 'Schwimmen', 'Wandern'];
function _eaStr(id) { var el = document.getElementById(id); var v = el ? (el.value || '').trim() : ''; return v === '' ? null : v; }
// Effektiver Datensatz GENAU wie moveActivity (null = Feld löschen) — zentral in Calc (SSOT).
function applyActivityPatchPreview(current, patch) { return Calc.applyActivityPatchPreview(current, patch); }
function saveEditActivity(origDate, origType) {
  var tEl = document.querySelector('#eaType .on'); var newType = tEl ? tEl.dataset.v : origType;
  var dEl = document.getElementById('eaDate'); var newDate = dEl && dEl.value ? dEl.value : origDate;
  if (!isDay(newDate)) { if (typeof toast === 'function') toast('' + _actT('act.bitte_gueltiges_datum') + ''); return; }
  // Echte Lösch-Semantik: leeres Feld → null. moveActivity entfernt null-Felder aus dem Datensatz
  // (Altwert verschwindet). KEIN Strip mehr — sonst bliebe der alte Wert stehen.
  var patch = { sub: _eaStr('eaSub'), dist: _eaNum('eaDist'), dur: _eaNum('eaDur'), hr: _eaNum('eaHr'), hrMax: _eaNum('eaHrMax'), elev: _eaNum('eaElev'), rpe: _eaNum('eaRpe'), note: _eaStr('eaNote') };
  // Effektive Werte EXAKT wie nach moveActivity (null löscht das Feld) — sonst könnte ein gelöschtes
  // Pflichtfeld die Prüfung „bestehen" und danach trotzdem entfernt werden.
  var cur = DB[origDate].sessions[origType] || {};
  var eff = applyActivityPatchPreview(cur, patch);
  // Pflichtfeld-Validierung sportartspezifisch: Distanzsportarten brauchen Distanz UND Dauer.
  if (EDIT_DISTANCE_SPORTS.indexOf(newType) >= 0 && (!(eff.dist > 0) || !(eff.dur > 0))) {
    if (typeof toast === 'function') toast('' + _actT('act.distanz_und_dauer_sind_fuer') + '' + newType + '" erforderlich'); return;
  }
  // Gym/Mobilität: Dauer ist Pflicht.
  if ((newType === 'Gym' || newType === 'Mobilität') && !(eff.dur > 0)) {
    if (typeof toast === 'function') toast('' + _actT('act.dauer_ist_fuer') + '' + newType + '" erforderlich'); return;
  }
  /* P1A: native Browser-Bestätigungen → orviaConfirm (Continuation-Kette; Reihenfolge und
     Abbruch-Semantik unverändert: jede Absage lässt das Editor-Modal offen). */
  function _finalizeSave() {
    var r = Calc.moveActivity(DB, origDate, origType, newDate, newType, patch);
    if (!r.ok && r.code === 'target_conflict') {
      if (typeof orviaConfirm === 'function') orviaConfirm({ title: 'Zielkonflikt', text: '' + _actT('act.an_diesem_tag_existiert_bereits') + '' + newType + '' + _actT('act.aktivitaet_es_ist_nur_eine') + '', okLabel: 'Verstanden', cancelLabel: null });
      else if (typeof toast === 'function') toast('' + _actT('act.zielkonflikt_bereits_eine') + '' + newType + '' + _actT('act.aktivitaet_an_diesem_tag') + '');
      return; // Editor-Modal bleibt offen — Nutzer kann Datum/Sportart anpassen, nichts wird überschrieben.
    }
    if (!r.ok) { if (typeof toast === 'function') toast('' + _actT('act.aktivitaet_nicht_gefunden') + ''); return; }
    closeEditActivity();
    _mvRerender();
    if (typeof toast === 'function') toast(newType !== origType ? '' + _actT('act.auf') + '' + newType + '" korrigiert ✓' : '' + _actT('act.aktivitaet_aktualisiert') + '');
  }
  function _confirmTypeChange() {
    // Sportartwechsel bestätigen (verändert alle sportartspezifischen Statistiken)
    if (newType !== origType && typeof orviaConfirm === 'function') {
      orviaConfirm({ title: '' + _actT('act.sportart_aendern') + '', text: '' + _actT('act.sportart_von') + '' + origType + '" zu „' + newType + '' + _actT('act.aendern_alle') + '' + origType + '' + _actT('act.statistiken_pace_bestzeiten_wochenumfang_werden') + '' + newType + ' neu berechnet.', okLabel: '' + _actT('act.sportart_aendern_') + '', danger: true, onOk: _finalizeSave });
      return;
    }
    _finalizeSave();
  }
  // Plausibilität (inkl. HF-Konsistenz, RPE-Bereich, Einheiten).
  var plaus = Calc.activityPlausibility(newType, eff);
  if (plaus.warn && typeof orviaConfirm === 'function') {
    orviaConfirm({ title: '' + _actT('act.plausibilitaet_pruefen') + '', text: plaus.msg, okLabel: '' + _actT('act.trotzdem_speichern') + '', onOk: _confirmTypeChange });
    return;
  }
  _confirmTypeChange();
}
function deleteActivity(date, typ) {
  // AD1b-Legacy-Adapter: löst (Datum, Typ) auf die kanonische Legacy-ID auf und löscht über
  // den EINEN Pfad (deleteActivityCanonical → activityStore.deleteActivity + DB-Spiegel).
  var leg = null; try { leg = _legacyActivities().find(function (x) { return x._legacy && x._legacy.date === date && x._legacy.type === typ; }); } catch (e) {}
  return deleteActivityCanonical(leg ? leg.clientRecordId : ('legacy:' + date + ':' + typ));
}

/* ---- Aktivität-Tab (Inkrement 2A: kanonische Quelle + klar abgegrenzter Legacy-Adapter) ---- */
// Sprite-Icons sind begrenzt → kanonischer Fallback 'pulse' statt falscher Zuordnung.
// v8-312: 'ball' ergaenzt — Sprite #i-ball existiert bereits in index.html und ist laut
// Sport-Katalog (onboarding-sports-logic.js) die kanonische Fussball-Ikone; sie fehlte
// hier und fiel deshalb bisher fälschlich auf 'pulse' zurück (Aktivitätenliste).
var SPRITE_ICONS = { run: 1, bike: 1, swim: 1, dumbbell: 1, stretch: 1, ball: 1, pulse: 1, plus: 1, list: 1, chart: 1 };
function _iconForSport(sportId) {
  var ic = (window.ORVIA && ORVIA.activityConfig) ? ORVIA.activityConfig.sportIcon(sportId) : 'pulse';
  return SPRITE_ICONS[ic] ? ic : 'pulse';
}
// Nutzer-Sportauswahl defensiv aus den verfügbaren Quellen ableiten (für dynamische Kacheln/Erfassung).
function _userSportsSelection() {
  try {
    var sl = window.ORVIA && ORVIA.onboardingSportsLogic; if (!sl) return null;
    var p = (typeof PROFILE !== 'undefined' && PROFILE) ? PROFILE : null;
    if (p && p.sportsSelection && p.sportsSelection.sports) return sl.normalizeSportsSelection(p.sportsSelection);
    var ob = window.ORVIA && ORVIA.onboardingV2Store;
    if (ob && typeof ob.load === 'function') { var d = ob.load(); if (d && d.draftData && d.draftData.sports) return sl.normalizeSportsSelection(d.draftData.sports); }
    if (p && Array.isArray(p.sports) && p.sports.length) return sl.seedFromExistingProfile({ sports: p.sports });
  } catch (e) {}
  return null;
}
// Legacy-Aktivitäten aus DB[date].sessions über den reinen Adapter (keine Mutation).
// Projektionen kanonischer Activities (derivedFromActivity) werden NICHT als eigene Activity gezählt.
function _legacyActivities() {
  var out = [];
  if (!(window.ORVIA && ORVIA.activityConfig)) return out;
  var days = Object.keys(DB).filter(isDay).sort().reverse();
  for (var i = 0; i < days.length; i++) {
    var e = DB[days[i]]; if (!e || !e.sessions) continue;
    Object.keys(e.sessions).filter(function (k) { return k !== '_ts'; }).forEach(function (typ) {
      var sess = e.sessions[typ];
      if (sess && sess.derivedFromActivity) return;   // reine Projektion → keine zweite UI-Activity
      out.push(ORVIA.activityConfig.legacySessionToActivity(days[i], typ, sess));
    });
  }
  return out;
}
// Server-Activities-Cache (cross-device). Wird asynchron aktualisiert, blockiert das Rendern nicht.
var _serverActivities = [];
var _serverFetching = false;
var _serverFetchedAt = 0;
function _fetchServerActivities(force) {
  if (_serverFetching || !(window.ORVIA && ORVIA.repos && ORVIA.repos.activity)) return;
  if (!force && (Date.now() - _serverFetchedAt) < 15000) return;   // frisch → kein erneuter Fetch (kein Render-Loop)
  _serverFetching = true;
  try {
    ORVIA.repos.activity.list({ limit: 200 }).then(function (r) {
      _serverFetching = false; _serverFetchedAt = Date.now();
      if (r && r.success && Array.isArray(r.data)) {
        _serverActivities = r.data.map(function (row) { return ORVIA.activityConfig.normalizeServerActivity(row); });
        renderAkt();   // einmal neu rendern mit Serverdaten (kein erneuter Fetch → kein Loop)
      }
    }).catch(function () { _serverFetching = false; });
  } catch (e) { _serverFetching = false; }
}
// EINE vereinheitlichte, sortierte, deduplizierte Liste: Server > lokal pending > Legacy.
function listActivitiesUnified(limit) {
  var local = (window.ORVIA && ORVIA.activityStore) ? ORVIA.activityStore.listActivities() : [];
  var legacy = _legacyActivities();
  var ts = (window.ORVIA && ORVIA.activityStore && ORVIA.activityStore.isTombstoned) ? ORVIA.activityStore.isTombstoned : null;
  var merged = (window.ORVIA && ORVIA.activityConfig && ORVIA.activityConfig.mergeAllActivities)
    ? ORVIA.activityConfig.mergeAllActivities(_serverActivities, local, legacy, { isTombstoned: ts })
    : local.concat(legacy);
  return limit ? merged.slice(0, limit) : merged;
}
/* GM7-Fix: Legacy-Renderer umbenannt (vorher `function renderAkt()`). Die gehoistete
   Deklaration überschrieb die kanonische GM3-Zuweisung in ui.js (Ladereihenfolge
   index.html:422→423) und rendert nur in das ausgeblendete #aktBox (styles.css §GM3).
   Kein produktiver Aufrufer mehr; bewusst behalten, bis der Legacy-Pfad komplett
   abgebaut ist (Regressionstest: tools/collision_scan.mjs). */
function renderAktLegacy() {
  var el = document.getElementById('aktBox'); if (!el) return;
  _fetchServerActivities();   // cross-device Serverdaten asynchron nachladen (Guard verhindert Loop)
  var acts = listActivitiesUnified(40);
  var demoEnabled = !!(window.ORVIA_CFG && window.ORVIA_CFG.enableDemoData && window.ORVIA_REAL_RUN);
  var head = '<div class="act-actions">' +
    (demoEnabled ? '<button class="btn" onclick="importRealRun()"><svg class="ic"><use href="#i-pulse"/></svg>' + _actT('act.demo_strava_lauf_importieren') + '</button>' : '') +
    '<button class="btn' + (demoEnabled ? ' sec' : '') + '" style="' + (demoEnabled ? 'margin-top:10px' : '') + '" onclick="openImportSheet()"><svg class="ic"><use href="#i-pulse"/></svg>' + _actT('act.strava_gpx_tcx_importieren') + '</button>' +
    '<button class="btn sec" style="margin-top:10px" onclick="openManualActivity()"><svg class="ic"><use href="#i-plus"/></svg>' + _actT('act.aktivitaet_manuell_hinzufuegen') + '</button>' +
    '<p class="note" style="text-align:left;margin-top:10px">' + _actT('act.import_per_gpx_tcx_datei') + '</p></div>';
  if (!acts.length) {
    el.innerHTML = head + '<div class="empty-card" style="margin-top:14px"><div class="empty-h">' + _actT('act.noch_keine_aktivitaeten') + '</div>' +
      '<p class="empty-p">' + _actT('act.trage_eine_aktivitaet_manuell_ein') + '</p></div>';
    return;
  }
  var cfg = ORVIA.activityConfig;
  var rows = acts.map(function (a) {
    var label = cfg.sportLabel(a.sportId);
    var dateStr = a.startedAt ? a.startedAt.slice(0, 10) : (a._legacy && a._legacy.date) || '';
    var dl = (typeof fmtDate === 'function' && dateStr) ? fmtDate(dateStr) : dateStr;
    var sub = cfg.summaryLine(a);
    var hasRoute = a._legacy && actRoute((DB[a._legacy.date] && DB[a._legacy.date].sessions || {})[a._legacy.type]);
    return '<button class="actrow" data-aid="' + escH(a.clientRecordId || a.id) + '" onclick="openActivityDetails(this)">' +
      '<span class="actrow-ic"><svg class="ic"><use href="#i-' + _iconForSport(a.sportId) + '"/></svg></span>' +
      '<span class="actrow-main"><span class="actrow-t">' + escH(label) + (hasRoute ? ' <span class="actrow-route">' + _actT('act.strecke') + '</span>' : '') + '</span>' +
      '<span class="actrow-sub">' + escH(dl) + ' · ' + escH(sub) + '</span></span>' +
      '<svg class="ic actrow-go"><use href="#i-chart"/></svg></button>';
  }).join('');
  el.innerHTML = head + '<div class="card" style="margin-top:14px"><h2><svg class="ic"><use href="#i-list"/></svg>' + _actT('act.deine_aktivitaeten') + '</h2><div class="actlist">' + rows + '</div></div>';
}
// Activity über stabile ID auflösen (verbindliche Reihenfolge: lokal id → server id → clientRecordId → source+sourceRecordId).
function _resolveActivity(aid) {
  var store = window.ORVIA && ORVIA.activityStore;
  var a = store ? store.getActivityById(aid) : null;             // lokal: id ODER clientRecordId
  if (a) return a;
  if (_serverActivities && _serverActivities.length) {
    a = _serverActivities.find(function (x) { return x.id === aid || x.clientRecordId === aid; });
    if (a) return a;
  }
  return null;
}
// Zentraler Detail-Einstieg (beide Verläufe). Auflösung NUR über stabile ID.
function openActivityDetails(idOrEl) {
  // AD1b-Adapter: EIN kanonischer Einstieg, Auflösung ausschließlich über die stabile Activity-ID.
  var aid = (idOrEl && idOrEl.dataset) ? idOrEl.dataset.aid : idOrEl;
  return openActivityDetail(aid, 'training');
}
// AD1b: Kompatibilitäts-Adapter — baut das kanonische View-Model und rendert über den EINEN Renderer.
function renderGeneralActivityDetails(a) { return renderActivityDetail(activityDetailViewModel(a), (a && a._detailContext) || 'import_review'); }
function _pace100(sec, meters) { if (!sec || !meters) return '–'; var p = sec / (meters / 100); var mm = Math.floor(p / 60), ss = Math.round(p % 60); return mm + ':' + String(ss).padStart(2, '0') + '/100 m'; }

/* ============================================================
   AD1b · Kanonischer Activity-Detail-Vertrag: EINE ID, EIN reines View-Model,
   EIN Renderer, EIN Overlay-Owner, EIN Löschpfad. Alle Alt-Einstiege sind ab
   hier dünne Adapter (s. openActivityDetails/openActivity/renderGeneralActivityDetails).
   ============================================================ */
// Auflösung inkl. Legacy-Adapter-IDs (legacy:date:sportId). Kein Blind-Matching, kein Datum-only-Pick.
function _resolveActivityAny(aid) {
  if (!aid) return null;
  var a = _resolveActivity(aid); if (a) return a;
  if (String(aid).indexOf('legacy:') === 0) { try { return _legacyActivities().find(function (x) { return x.clientRecordId === aid; }) || null; } catch (e) {} }
  return null;
}
// Reines Detail-View-Model (Summary-Umfang; ehrliche Missingness; keine erfundenen Defaults).
function activityDetailViewModel(a) {
  a = a || {};
  var cfg = window.ORVIA && ORVIA.activityConfig, an = window.ORVIA && ORVIA.activityNormalize;
  var s = a.summary || {}, m = a.metrics || {};
  var id = a.clientRecordId || a.id || null;
  var sportId = a.sportId || null;
  var startedAt = a.startedAt || null;
  var date = startedAt ? startedAt.slice(0, 10) : null;
  var time = (startedAt && startedAt.length >= 16) ? startedAt.slice(11, 16) : (m.time || null);
  var dm = (an && typeof an.activityDetailModel === 'function') ? an.activityDetailModel(sportId, s, a.durationSeconds, m) : null;
  var vm = {
    id: id, sportId: sportId, sportLabel: cfg ? cfg.sportLabel(sportId) : sportId,
    title: (dm && dm.name) || s.name || m.name || null,
    startedAt: startedAt, date: date, time: time,
    durationSeconds: (a.durationSeconds != null ? a.durationSeconds : null),
    durationLabel: (an && a.durationSeconds != null) ? an.fmtDurationSeconds(a.durationSeconds) : null,
    distanceLabel: dm ? dm.distanceLabel : null,
    paceLabel: dm ? dm.paceLabel : null,
    elevationM: dm ? dm.elevationM : (s.elevationM != null ? s.elevationM : null),
    avgHr: dm ? dm.avgHr : (s.avgHr != null ? s.avgHr : null),
    maxHr: dm ? dm.maxHr : (s.maxHr != null ? s.maxHr : null),
    caloriesKcal: dm ? dm.caloriesKcal : (s.caloriesKcal != null ? s.caloriesKcal : null),
    source: a.source || null,
    sourceRecordId: a.sourceRecordId || null,
    workoutSessionId: a.workoutSessionId || null,
    planLink: (function () {
      try { var st = window.ORVIA && ORVIA.activityStore; if (st && st.planLinkOf) return st.planLinkOf(a); } catch (_) {}
      return a.plannedSessionId || (m && m.plannedSessionId) || null;
    })(),
    workoutDetail: null, workoutDetailState: null, storyRef: null, missing: {},
    /* GM7.3: kanonische Route direkt aus dem Activity-Record (metrics.route) — überlebt
       ohne Legacy-Blob und ist cloud-/geräteübergreifend. Fallback bleibt storyRef→Blob. */
    canonicalRoute: (a.metrics && Array.isArray(a.metrics.route) && a.metrics.route.length > 1) ? a.metrics.route : null,
    /* GM7.4.1: kanonische Garmin-Detail-Streams (metrics.streams, aus
       get_activity_details geparst) — HF/Kadenz/Höhe/Geschwindigkeit/Distanz je
       Aktivität; rohe Werte-Arrays (keine Neuberechnung, keine Tempo-Ableitung). */
    canonicalStreams: (a.metrics && a.metrics.streams && typeof a.metrics.streams === 'object') ? a.metrics.streams : null,
    canonicalStreamUnits: (a.metrics && a.metrics.stream_units && typeof a.metrics.stream_units === 'object') ? a.metrics.stream_units : null,
    /* GM7.7: kanonische Garmin-Runden (metrics.splits — der Worker speichert sie bereits
       aus splitSummaries/laps, das Frontend hat sie bisher NIE gelesen; Splits kamen nur
       aus dem Legacy-Blob). Defensive Normalisierung auf {km, sec, hr}: ausschliesslich
       echte Felder des Rohobjekts, keine Interpolation, keine erfundene Runde. */
    /* KF-021: die Normalisierung liegt jetzt EINMAL in js/run-bests.js, weil die
       Bestzeiten dieselben Runden lesen muessen. Zwei Kopien derselben Regel
       waeren zwei Wahrheiten. Die >=2-Schwelle bleibt hier lokal: die
       Detailansicht zeigt erst ab zwei Runden eine sinnvolle Rundentabelle,
       die Bestzeiten dagegen werten auch eine einzelne Runde aus. */
    canonicalSplits: (function () {
      var rb = window.ORVIA && ORVIA.runBests;
      var out = (rb && rb.normalizeSplits) ? rb.normalizeSplits(a.metrics && a.metrics.splits) : null;
      return (out && out.length >= 2) ? out : null;
    })()
  };
  ['title', 'distanceLabel', 'paceLabel', 'elevationM', 'avgHr', 'maxHr', 'caloriesKcal'].forEach(function (k) { vm.missing[k] = (vm[k] == null || vm[k] === ''); });
  try {
    var store = window.ORVIA && ORVIA.activityStore;
    if (a.source === 'orvia_workout' && store && store.getWorkoutDetailsForActivity && id) {
      var det = store.getWorkoutDetailsForActivity(id);
      if (det && det.ok && det.hasDetails) vm.workoutDetail = det.exercises || null;
    }
  } catch (e) {}
  // AD1c: Story nur bei EINDEUTIGER Legacy-Verknüpfung (genau diese eine Session mit Route/Splits).
  try {
    if (a.source === 'import' && !a._legacy && typeof DB !== 'undefined') {
      /* GM7: Datei-Importe schreiben Route/Splits in den Legacy-Blob desselben Tages —
         Verknuepfung ueber Datum + Sportart (eindeutig: max. 1 Session je Typ/Tag). */
      var _d0 = a.startedAt ? String(a.startedAt).slice(0, 10) : null;
      var _e0 = _d0 && DB[_d0]; var _ss = _e0 && _e0.sessions;
      if (_ss) Object.keys(_ss).some(function (t) {
        if (t === '_ts') return false; var sess0 = _ss[t]; if (!sess0) return false;
        var has0 = (typeof actRoute === 'function' && actRoute(sess0)) || (sess0.splits && sess0.splits.length);
        if (!has0) return false;
        /* GM7.8-Fix (fail-closed): Der Sportart-Guard haengte an einem OPTIONALEN Modul —
           fehlte ORVIA.trainingDomain, wurde die Sportart gar nicht geprueft und ein
           Rad-Import konnte die Route einer LAUF-Session erben (Blind-Zuordnung).
           Jetzt wird zusaetzlich ueber das kanonische Sport-Label aufgeloest; laesst sich
           die Sportart mit KEINER Quelle bestimmen, wird bewusst NICHT verknuepft. */
        var sid0 = null, lbl0 = null;
        try { sid0 = (ORVIA.trainingDomain && ORVIA.trainingDomain.normSport) ? ORVIA.trainingDomain.normSport(t) : null; } catch (e0) {}
        try { var _cfg0 = ORVIA.activityConfig; lbl0 = (_cfg0 && _cfg0.sportLabel && a.sportId) ? _cfg0.sportLabel(a.sportId) : null; } catch (e1) {}
        if (!sid0) sid0 = LEGACY_TYPE_SPORT[String(t)] || null;   /* letzte Aufloesung ueber den geschlossenen Legacy-Typsatz */
        var sameSport = (sid0 && a.sportId) ? (sid0 === a.sportId)
          : ((lbl0 && lbl0 !== 'Aktivität') ? (String(lbl0) === String(t)) : false);
        if (!sameSport) return false;
        vm.storyRef = { date: _d0, typ: t }; return true;
      });
    }
    if (a.source === 'legacy_local' && a._legacy && typeof DB !== 'undefined') {
      var _e = DB[a._legacy.date]; var _sess = _e && _e.sessions && _e.sessions[a._legacy.type];
      if (_sess && ((typeof actRoute === 'function' && actRoute(_sess)) || (_sess.splits && _sess.splits.length))) vm.storyRef = { date: a._legacy.date, typ: a._legacy.type };
    }
  } catch (e) {}
  return vm;
}
function _adRow(k, v) { return '<div class="wc-stat"><span class="wc-sv">' + escH(v) + '</span><span class="wc-sk">' + escH(k) + '</span></div>'; }
// EIN Overlay-Owner: window._activityDetailOverlay. Erneutes Öffnen ersetzt, nie dupliziert.
function closeActivityDetail() { if (window._activityDetailOverlay) { try { window._activityDetailOverlay.remove(); } catch (e) {} window._activityDetailOverlay = null; } }
// AD1c: EIN Renderer, EIN Overlay — Inhalt wird über _activityDetailHtml gebaut und bei
// asynchron nachgeladenen Cloud-Workoutdetails IN DEMSELBEN Overlay aktualisiert (kein zweites Overlay).
function _workoutDetailHtml(vm) {
  if (vm.source !== 'orvia_workout') return '';
  var ex = vm.workoutDetail;
  if (ex && ex.length) {
    var names = ex.map(function (x) { return (x && (x.n || (x.exercise && x.exercise.name) || x.exerciseNameSnapshot || (x.workoutExercise && x.workoutExercise.exercise_name_snapshot))) || 'Übung'; });
    /* B-05: Superset-Label nur fuer ECHTE Gruppen (>= 2 Uebungen mit gleicher Gruppe). */
    var gcount = {}; ex.forEach(function (x) { var g = x && x.supersetGroup; if (g != null) gcount[g] = (gcount[g] || 0) + 1; });
    var labels = ex.map(function (x) { var g = x && x.supersetGroup; if (g == null || gcount[g] < 2) return ''; var GA = window.ORVIA && ORVIA.gymAdapters; var l = (GA && GA.groupLabel) ? GA.groupLabel(g) : String(g); return l ? '<span class="wc-exrow-ss">Superset ' + escH(l) + '</span>' : ''; });
    return '<div class="wc-ex"><div class="wc-ex-h">' + _actT('act.uebungen_n', { n: ex.length }) + '</div>' + names.map(function (n, i) { return '<div class="wc-exrow"><span class="wc-exrow-n">' + escH(n) + '</span>' + labels[i] + '</div>'; }).join('') + '</div>';
  }
  if (vm.workoutDetailState === 'loading') return '<div class="wc-ex"><div class="wc-ex-h">' + _actT('act.uebungen_werden_geladen') + '</div></div>';
  if (vm.workoutDetailState === 'error') return '<div class="wc-nomap">' + _actT('act.uebungsdetails_konnten_nicht_geladen_werden') + '</div>';
  if (vm.workoutDetailState === 'missing') return '<div class="wc-nomap">' + _actT('act.fuer_diese_einheit_sind_keine') + '</div>';
  return '';
}
function _activityDetailHtml(vm, context) {
  var rows = [];
  if (vm.date) rows.push(_adRow('' + _actT('act.datum') + '', (typeof fmtDate === 'function') ? fmtDate(vm.date) : vm.date));
  if (vm.time) rows.push(_adRow('Uhrzeit', vm.time));
  if (vm.durationLabel) rows.push(_adRow('Dauer', vm.durationLabel));
  if (vm.distanceLabel) rows.push(_adRow('Distanz', vm.distanceLabel));
  if (vm.paceLabel) rows.push(_adRow('Pace', vm.paceLabel));
  if (vm.elevationM != null) rows.push(_adRow('' + _actT('act.hoehenmeter') + '', vm.elevationM + ' m'));
  if (vm.avgHr != null) rows.push(_adRow('' + _actT('act.hf') + '', vm.avgHr + ' bpm'));
  if (vm.maxHr != null) rows.push(_adRow('' + _actT('act.hf_max') + '', vm.maxHr + ' bpm'));
  if (vm.caloriesKcal != null) rows.push(_adRow('Kalorien', vm.caloriesKcal + ' kcal'));
  if (vm.source) rows.push(_adRow('Quelle', vm.source));
  var wd = _workoutDetailHtml(vm);
  var story = vm.storyRef ? '<button class="btn" style="margin-top:12px" onclick="closeActivityDetail();openStory(\'' + escH(vm.storyRef.date) + '\',\'' + escH(vm.storyRef.typ) + '\')">▶ Story ansehen</button>' : '';
  return '<div class="orvia-modal wcard-modal" role="dialog" aria-modal="true"><div class="wcard">' +
    '<div class="wc-title">' + escH(vm.title || vm.sportLabel || 'Aktivität') + '</div>' +
    '<div class="wc-day">' + escH(vm.sportLabel || '') + '</div>' +
    '<div class="wc-stats">' + rows.join('') + '</div>' + wd + '</div>' + story +
    (vm.planLink ? '<button class="btn sec" style="margin-top:12px" onclick="unlinkActivityPlanCanonical(\'' + escH(vm.id) + '\',\'' + escH(vm.planLink) + '\')">' + _actT('act.vom_wochenplan_loesen_btn') + '</button>' : '') +
    '<button class="btn sec danger-btn" style="margin-top:12px" onclick="deleteActivityCanonical(\'' + escH(vm.id) + '\')">' + _actT('act.aktivitaet_loeschen') + '</button>' +
    '<button class="btn sec" style="margin-top:10px" onclick="closeActivityDetail()">' + _actT('act.schliessen') + '</button></div>';
}
function renderActivityDetail(vm, context) {
  if (!vm || !vm.id) return renderActivityUnavailable(null, context);
  closeActivityDetail();
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg';
  wrap.dataset.activityId = vm.id; wrap.dataset.context = context || ''; wrap._vm = vm; wrap._context = context;
  wrap.innerHTML = _activityDetailHtml(vm, context);
  document.body.appendChild(wrap); window._activityDetailOverlay = wrap;
  wrap.addEventListener('click', function (ev) { if (ev.target === wrap) closeActivityDetail(); });
  // Cloud-only-Workout ohne lokalen Snapshot: Satzdetails asynchron über die bestehende
  // loadWorkoutTree-Logik nachladen und IN DIESES Overlay einsetzen.
  if (vm.source === 'orvia_workout' && !(vm.workoutDetail && vm.workoutDetail.length)) _loadWorkoutDetailInto(wrap, vm);
  return wrap;
}
function _loadWorkoutDetailInto(overlay, vm) {
  var repos = window.ORVIA && ORVIA.repos && ORVIA.repos.workout;
  var sid = vm.sourceRecordId || vm.workoutSessionId || vm.id;
  var reRender = function () { if (window._activityDetailOverlay === overlay) overlay.innerHTML = _activityDetailHtml(vm, overlay._context); };
  if (!repos || !repos.loadWorkoutTree || !sid) { vm.workoutDetailState = 'missing'; reRender(); return; }
  vm.workoutDetailState = 'loading'; reRender();
  try {
    Promise.resolve(repos.loadWorkoutTree(sid)).then(function (r) {
      if (window._activityDetailOverlay !== overlay) return;   // Overlay ersetzt → nichts tun (kein zweites Overlay)
      if (r && r.success && r.data && Array.isArray(r.data.exercises) && r.data.exercises.length) { vm.workoutDetail = r.data.exercises; vm.workoutDetailState = 'loaded'; }
      else if (r && r.success) { vm.workoutDetailState = 'missing'; }
      else { vm.workoutDetailState = 'error'; }
      reRender();
    }).catch(function () { if (window._activityDetailOverlay === overlay) { vm.workoutDetailState = 'error'; reRender(); } });
  } catch (e) { vm.workoutDetailState = 'error'; reRender(); }
}
function renderActivityUnavailable(activityId, context) {
  closeActivityDetail();
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg';
  wrap.dataset.activityId = ''; wrap.dataset.unavailable = '1'; wrap.dataset.context = context || '';
  wrap.innerHTML = '<div class="orvia-modal wcard-modal" role="dialog" aria-modal="true"><div class="wcard">' +
    '<div class="wc-title">' + _actT('act.aktivitaet_nicht_verfuegbar') + '</div>' +
    '<p class="wc-nomap">' + _actT('act.zu_dieser_auswahl_ist_keine') + '</p></div>' +
    '<button class="btn sec" style="margin-top:10px" onclick="closeActivityDetail()">' + _actT('act.schliessen') + '</button></div>';
  document.body.appendChild(wrap); window._activityDetailOverlay = wrap;
  wrap.addEventListener('click', function (ev) { if (ev.target === wrap) closeActivityDetail(); });
  return wrap;
}
// Einziger öffentlicher Detail-Einstieg. context steuert Navigation, nie die Daten.
function openActivityDetail(activityId, context) {
  context = context || 'training';
  var a = _resolveActivityAny(activityId);
  if (!a) { renderActivityUnavailable(activityId, context); return { ok: false, code: 'activity_not_found', id: activityId || null, context: context }; }
  var vm = activityDetailViewModel(a);
  renderActivityDetail(vm, context);
  return { ok: true, id: vm.id, context: context };
}
// Plan-Actual-Auflösung: eindeutig / keiner / mehrdeutig — NIE Blind-Auswahl.
function resolvePlannedActivity(occurrenceId) {
  if (!occurrenceId) return { status: 'none' };
  var list = []; try { list = listActivitiesUnified(200) || []; } catch (e) { list = []; }
  var store = window.ORVIA && ORVIA.activityStore;
  var hits = list.filter(function (a) {
    if (!a) return false;
    var link = (store && store.planLinkOf) ? store.planLinkOf(a) : (a.plannedSessionId || (a.metrics && a.metrics.plannedSessionId) || null);
    return link === occurrenceId;
  });
  if (hits.length === 1) return { status: 'unique', id: hits[0].clientRecordId || hits[0].id };
  if (hits.length > 1) return { status: 'ambiguous', ids: hits.map(function (h) { return h.clientRecordId || h.id; }) };
  return { status: 'none' };
}
// EIN Löschpfad: genau eine Bestätigung, dann der bestehende Store-/Tombstone-Pfad (doDeleteActivity).
// Legacy-only (kein kanonischer Store-Record): klar abgegrenzter Adapter entfernt zusätzlich den DB-Spiegel.
function deleteActivityCanonical(activityId) {
  var a = _resolveActivityAny(activityId) || { clientRecordId: activityId };
  var isWk = a && a.source === 'orvia_workout';
  var run = function () {
    if (a && a.source === 'legacy_local' && a._legacy) {
      try { var e = DB[a._legacy.date]; if (e && e.sessions) { delete e.sessions[a._legacy.type]; e.sessions._ts = Date.now(); } if (typeof save === 'function') save(); } catch (_) {}
    }
    doDeleteActivity(a.clientRecordId || a.id || activityId);
  };
  var title = isWk ? '' + _actT('act.workout_wirklich_loeschen') + '' : '' + _actT('act.aktivitaet_wirklich_loeschen') + '';
  var text = isWk ? '' + _actT('act.das_workout_inkl_uebungen_und') + '' : '' + _actT('act.diese_aktivitaet_und_ihre_zugehoerigen') + '';
  if (typeof orviaConfirm === 'function') { orviaConfirm({ title: title, text: text, okLabel: '' + _actT('act.endgueltig_loeschen') + '', danger: true, onOk: run }); return; }
  run();
}

/* v8-310b · Korrekturpfad 2: NUR die Plan-Zuordnung loesen. Die Aktivitaet
   bleibt vollstaendig erhalten; insbesondere entstehen weder Tombstone noch
   Workout-Loeschung. Der Store schreibt eine explizite Korrektur-Provenance,
   die beim Cloud-Upsert und bei spaeteren Snapshot-Retries gewinnt. */
function unlinkActivityPlanCanonical(activityId, expectedOccurrenceId) {
  var a = _resolveActivityAny(activityId);
  var store = window.ORVIA && ORVIA.activityStore;
  if (!a || !store || !store.unlinkActivityFromPlan) return { ok: false, code: 'unavailable' };
  var run = function () {
    var r = store.unlinkActivityFromPlan(a.clientRecordId || a.id || activityId, expectedOccurrenceId || null);
    if (!r || !r.ok) {
      if (typeof toast === 'function') toast('' + _actT('act.zuordnung_nicht_geaendert') + '' + (r && r.code ? ': ' + r.code : '.'));
      return r;
    }
    try { closeActivityDetail(); } catch (_) {}
    try { if (typeof gmCloseActivityPage === 'function') gmCloseActivityPage(); } catch (_) {}
    try { if (typeof renderAkt === 'function') renderAkt(); } catch (_) {}
    try { if (window.dispatchEvent) window.dispatchEvent(new CustomEvent('orvia:activity-updated', { detail: { planLinkCorrected: true, activityId: activityId } })); } catch (_) {}
    try { if (ORVIA.activitySync && ORVIA.activitySync.flushPendingActivities) ORVIA.activitySync.flushPendingActivities(); } catch (_) {}
    if (typeof toast === 'function') toast('' + _actT('act.aktivitaet_bleibt_erhalten_planzuordnung_geloest') + '');
    return r;
  };
  if (typeof orviaConfirm === 'function') {
    orviaConfirm({ title: '' + _actT('act.vom_wochenplan_loesen') + '', text: '' + _actT('act.die_aktivitaet_und_alle_trainingsdaten') + '', okLabel: '' + _actT('act.zuordnung_loesen') + '', onOk: run });
    return { ok: true, code: 'confirmation_open' };
  }
  return run();
}

// ---- Löschen (manuell/Workout/Legacy) mit Bestätigung, offline-fest ----
// AD1b: Kompatibilitäts-Adapter → EIN Löschpfad (deleteActivityCanonical, genau eine Bestätigung).
function confirmDeleteActivity(aid) { return deleteActivityCanonical(aid); }
function _closeDelModal() { if (window._delModal) { try { window._delModal.remove(); } catch (e) {} window._delModal = null; } }
function doDeleteActivity(aid) {
  _closeDelModal();
  var store = window.ORVIA && ORVIA.activityStore; if (!store) return;
  var a = _resolveActivity(aid) || { clientRecordId: aid };
  // 1) Lokal löschen + Tombstone (sofort aus UI, offline-fest).
  store.deleteActivity(a.clientRecordId || a.id || aid, a);
  // 2) Legacy-Projektion / -Spiegel entfernen, die eindeutig zu dieser Activity gehört.
  _removeLegacyFor(a);
  // 3) Aktiven Workout-Store-Datensatz mitnehmen (falls dieselbe Session lokal aktiv wäre — selten).
  // 4) Sofort neu rendern + Statistiken aktualisieren.
  try { closeActivity(); } catch (e) {}
  try { if (typeof gmCloseActivityPage === 'function') gmCloseActivityPage(); } catch (e) {}
  try { if (typeof _mvRerender === 'function') _mvRerender(); } catch (e) {}
  if (typeof renderAkt === 'function') renderAkt();
  try { if (window.dispatchEvent) window.dispatchEvent(new CustomEvent('orvia:activity-updated', { detail: { deleted: true } })); } catch (e) {}
  // 5) Server-Löschung anstoßen (Outbox; offline → bleibt pending, kein Wiederauftauchen).
  try { if (ORVIA.activitySync) ORVIA.activitySync.flushPendingActivities(); } catch (e) {}
  if (typeof toast === 'function') toast('Gelöscht');
}
// Legacy-DB-Spiegel zu einer kanonischen Activity entfernen (Projektion ODER eindeutiger Session-Spiegel).
function _removeLegacyFor(a) {
  try {
    if (typeof DB === 'undefined') return;
    var days = Object.keys(DB).filter(isDay);
    for (var i = 0; i < days.length; i++) {
      var e = DB[days[i]]; if (!e || !e.sessions) continue;
      Object.keys(e.sessions).filter(function (k) { return k !== '_ts'; }).forEach(function (typ) {
        var sess = e.sessions[typ]; if (!sess) return;
        var match = (a.clientRecordId && sess.canonicalActivityId === a.clientRecordId)
          || (a.workoutSessionId && (sess.workoutSessionId === a.workoutSessionId || sess.clientSessionId === a.workoutSessionId));
        if (match) { delete e.sessions[typ]; e.sessions._ts = Date.now(); }
      });
    }
    if (typeof save === 'function') save();
  } catch (e) {}
}
// Nach Workout-Abschluss/Activity-Änderung den Aktivität-Tab neu rendern (kein App-Reload nötig).
if (typeof window !== 'undefined' && window.addEventListener) {
  window.addEventListener('orvia:activity-updated', function () { try { if (document.getElementById('gmAkt')) renderAkt(); } catch (e) {} });
  // Inkrement 4d: Profil-Sportänderung → Schnellaktionen/Aktivitäts-Picker ohne App-Neustart aktualisieren.
  window.addEventListener('orvia:profile-updated', function (ev) {
    try { if (ev && ev.detail && ev.detail.changedSections && ev.detail.changedSections.indexOf('sports') < 0) return; } catch (e) {}
    try { if (document.getElementById('gmAkt')) renderAkt(); } catch (e) {}
    try { if (typeof renderDay === 'function' && document.getElementById('dayQuick')) renderDay(); } catch (e) {}
  });
}
// Hook für den Gym-Shadow-Report: aktuell geladene Server-Activities (cross-device) ohne Netzwerkzugriff.
if (typeof window !== 'undefined') { window.ORVIA = window.ORVIA || {}; window.ORVIA.activityServerCache = function () { try { return (_serverActivities || []).slice(); } catch (e) { return []; } }; }
// AD1b: kanonischer Activity-Detail-Namespace (für Plan-Klick, Workout-Sheet-Adapter u. a.).
if (typeof window !== 'undefined') {
  window.ORVIA = window.ORVIA || {};
  window.ORVIA.activityUI = {
    decodePolyline: decodePolyline,
    openActivityDetail: openActivityDetail,
    activityDetailViewModel: activityDetailViewModel,
    resolvePlannedActivity: resolvePlannedActivity,
    closeActivityDetail: closeActivityDetail,
    deleteActivityCanonical: deleteActivityCanonical,
    unlinkActivityPlanCanonical: unlinkActivityPlanCanonical
  };
}

/* ============================================================
   GPX/TCX-Datei-Import → Aktivität mit Route. Modular für Lauf/Rad/
   Schwimmen/Wandern/Triathlon. Keine externen Dienste/Keys.
   ============================================================ */
function _haversineKm(a, b) { var R = 6371, dLat = (b[0] - a[0]) * Math.PI / 180, dLng = (b[1] - a[1]) * Math.PI / 180; var la1 = a[0] * Math.PI / 180, la2 = b[0] * Math.PI / 180; var x = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.sin(dLng / 2) * Math.sin(dLng / 2) * Math.cos(la1) * Math.cos(la2); return 2 * R * Math.asin(Math.min(1, Math.sqrt(x))); }
function _routeDistKm(pts) { var d = 0; for (var i = 1; i < pts.length; i++) d += _haversineKm(pts[i - 1], pts[i]); return d; }
function _downsample(pts, max) { max = max || 300; if (pts.length <= max) return pts; var step = Math.ceil(pts.length / max), out = []; for (var i = 0; i < pts.length; i += step) out.push(pts[i]); if (out[out.length - 1] !== pts[pts.length - 1]) out.push(pts[pts.length - 1]); return out; }
function _localDateFromISO(iso) { if (!iso) return null; var d = new Date(iso); if (isNaN(d.getTime())) return null; return (typeof todayStr === 'function') ? todayStr(d) : d.toISOString().slice(0, 10); }
function parseGpxTcx(text) {
  var doc = new DOMParser().parseFromString(text, 'application/xml');
  if (doc.getElementsByTagName('parsererror').length) return null;
  var pts = [], times = [], hrs = [], totalDistM = null, sport = null;
  var trkpts = doc.getElementsByTagName('trkpt');
  if (trkpts.length) { // GPX
    for (var i = 0; i < trkpts.length; i++) {
      var p = trkpts[i], lat = parseFloat(p.getAttribute('lat')), lon = parseFloat(p.getAttribute('lon'));
      if (!isNaN(lat) && !isNaN(lon)) pts.push([lat, lon]);
      var tEl = p.getElementsByTagName('time')[0]; if (tEl) times.push(tEl.textContent);
    }
    var typeEl = doc.getElementsByTagName('type')[0]; if (typeEl) sport = typeEl.textContent;
  } else { // TCX
    var tps = doc.getElementsByTagName('Trackpoint');
    for (var j = 0; j < tps.length; j++) {
      var tp = tps[j];
      var la = tp.getElementsByTagName('LatitudeDegrees')[0], lo = tp.getElementsByTagName('LongitudeDegrees')[0];
      if (la && lo) { var laV = parseFloat(la.textContent), loV = parseFloat(lo.textContent); if (!isNaN(laV) && !isNaN(loV)) pts.push([laV, loV]); }
      var tEl2 = tp.getElementsByTagName('Time')[0]; if (tEl2) times.push(tEl2.textContent);
      var dm = tp.getElementsByTagName('DistanceMeters'); if (dm.length) { var dv = parseFloat(dm[dm.length - 1].textContent); if (!isNaN(dv)) totalDistM = dv; }
      var hrEl = tp.getElementsByTagName('HeartRateBpm')[0]; if (hrEl) { var vv = hrEl.getElementsByTagName('Value')[0]; if (vv) { var h = parseFloat(vv.textContent); if (!isNaN(h)) hrs.push(h); } }
    }
    var actEl = doc.getElementsByTagName('Activity')[0]; if (actEl) sport = actEl.getAttribute('Sport');
  }
  if (!times.length && !pts.length) return null;
  var durMin = null;
  if (times.length >= 2) { var t0 = new Date(times[0]), t1 = new Date(times[times.length - 1]); if (!isNaN(t0.getTime()) && !isNaN(t1.getTime())) durMin = (t1 - t0) / 60000; }
  var distKm = totalDistM != null ? totalDistM / 1000 : (pts.length > 1 ? _routeDistKm(pts) : null);
  var hr = hrs.length ? Math.round(hrs.reduce(function (s, x) { return s + x; }, 0) / hrs.length) : null;
  var raw = (sport || '').toLowerCase();
  var type = raw.indexOf('bik') >= 0 || raw.indexOf('cycl') >= 0 || raw.indexOf('ride') >= 0 ? 'ride'
    : raw.indexOf('swim') >= 0 ? 'swim' : 'run';
  return { date: _localDateFromISO(times[0]) || (typeof todayStr === 'function' ? todayStr() : ''), type: type, dur: durMin, dist: distKm, hr: hr, route: _downsample(pts, 300), note: 'GPX/TCX-Import' };
}
function importGpxTcxFile(input) {
  var f = input && input.files && input.files[0]; if (!f) return;
  if (/\.fit$/i.test(f.name)) { if (typeof toast === 'function') toast('' + _actT('act.fit_dateien_bitte_als_gpx') + ''); input.value = ''; return; }
  var r = new FileReader();
  r.onload = function () {
    try {
      var act = parseGpxTcx(String(r.result));
      if (!act) { if (typeof toast === 'function') toast('' + _actT('act.datei_nicht_lesbar_gpx_oder') + ''); return; }
      if (!act.route || act.route.length < 2) delete act.route;
      var res = (typeof importActivityArray === 'function') ? importActivityArray([act]) : null;
      _importToCanonical([act]);   // H3: kanonisch spiegeln (Cloud-Sync)
      if (res && typeof reportImport === 'function') reportImport(res);
    } catch (e) { if (typeof toast === 'function') toast('' + _actT('act.import_fehler') + '' + (e && e.message || 'unbekannt')); }
  };
  r.readAsText(f); input.value = '';
}
/* H3 (2026-07-11): Importierte Aktivitäten landeten NUR im Legacy-Blob (data.js →
   DB.sessions) und waren damit nicht cloud-synchron (Zweitgerät-Verlust, LWW-Risiko).
   Zusätzlich kanonisch in den activityStore spiegeln — activity-sync pusht source
   'import' bereits; Dedupe über sourceRecordId (Datum+Typ+Dauer). */
function _importToCanonical(arr){
  try{
    if(!(window.ORVIA&&ORVIA.activityStore&&ORVIA.activityStore.upsertManualActivity))return 0;
    var n=0;
    (arr||[]).forEach(function(a){
      if(!a||!a.date)return;
      var sportId=null;
      try{if(ORVIA.trainingDomain&&ORVIA.trainingDomain.normSport)sportId=ORVIA.trainingDomain.normSport(a.type);}catch(e){}
      if(!sportId)sportId='other';
      var durSec=a.dur!=null?Math.round(a.dur*60):null;
      var summary={};
      if(a.dist!=null)summary.distanceKm=a.dist;
      if(a.hr!=null)summary.avgHr=a.hr;
      if(a.elev!=null)summary.elevationM=a.elev;
      var r=ORVIA.activityStore.upsertManualActivity({
        sportId:sportId,source:'import',
        sourceRecordId:'import:'+a.date+':'+(sportId)+':'+(durSec!=null?durSec:'x'),
        startedAt:a.date+'T'+(a.time&&/^\d{2}:\d{2}/.test(a.time)?a.time.slice(0,5):'00:00')+':00',
        endedAt:null,durationSeconds:durSec,summary:summary,
        metrics:(window.ORVIA&&ORVIA.activityNormalize&&ORVIA.activityNormalize.buildImportMetrics)?ORVIA.activityNormalize.buildImportMetrics(a):((a.polyline||a.route)?{hasRoute:true}:{})  /* GM7.3: Route verlustfrei in metrics (jsonb, cloud-synchron) */
      });
      if(r&&r.ok)n++;
    });
    return n;
  }catch(e){try{console.error('[ORVIA import] kanonische Spiegelung fehlgeschlagen',e);}catch(_){}return 0;}
}
/* ---- Paste-Import (JSON) als Sheet, self-contained ---- */
function openImportSheet() {
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg';
  wrap.innerHTML = '<div class="orvia-modal goal-modal"><h3>' + _actT('act.aktivitaeten_importieren') + '</h3>' +
    '<p class="note" style="text-align:left">' + _actT('act.gpx_tcx_datei_garmin_strava') + '</p>' +
    '<label class="btn sec" style="margin-top:10px;display:block;text-align:center">' + _actT('act.gpx_tcx_datei_waehlen') + '' +
    '<input type="file" accept=".gpx,.tcx,application/gpx+xml,application/octet-stream" style="display:none" onchange="importGpxTcxFile(this);closeImportSheet()"></label>' +
    '<textarea class="paste" id="impPaste" style="margin-top:12px;width:100%;min-height:120px" placeholder=\'[{"date":"2026-06-15","type":"run","dist":7.2,"dur":36.1,"hr":150,"polyline":"…"}]\'></textarea>' +
    '<button class="btn" style="margin-top:10px" onclick="runPasteImport()">' + _actT('act.json_importieren') + '</button>' +
    '<button class="btn sec" style="margin-top:10px" onclick="closeImportSheet()">' + _actT('act.schliessen') + '</button></div>';
  document.body.appendChild(wrap); window._impModal = wrap;
  wrap.addEventListener('click', function (ev) { if (ev.target === wrap) closeImportSheet(); });
}
function closeImportSheet() { if (window._impModal) { try { window._impModal.remove(); } catch (e) {} window._impModal = null; } }
function runPasteImport() {
  var el = document.getElementById('impPaste'); if (!el) return;
  var arr; try { arr = JSON.parse(el.value); if (!Array.isArray(arr)) throw 0; } catch (e) { if (typeof toast === 'function') toast('' + _actT('act.ungueltiges_json') + ''); return; }
  var res = (typeof importActivityArray === 'function') ? importActivityArray(arr) : null;
  _importToCanonical(arr);   // H3: kanonisch spiegeln (Cloud-Sync)
  closeImportSheet();
  if (res && typeof reportImport === 'function') reportImport(res);
}

/* ---- Import-Animation + Mock-Import ---- */
function importAnimation(steps, onDone) {
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg import-bg';
  wrap.innerHTML = '<div class="import-card"><svg class="import-mark" viewBox="0 0 512 512" aria-hidden="true"><use href="#orvia-mark"/></svg>' +
    '<div class="import-title">' + _actT('act.synchronisiere') + '</div><div class="import-steps">' +
    steps.map(function (s, i) { return '<div class="import-step" data-i="' + i + '"><span class="is-dot"></span><span class="is-txt">' + escH(s) + '</span></div>'; }).join('') +
    '</div></div>';
  document.body.appendChild(wrap);
  var i = 0;
  var tick = function () {
    if (i > 0) { var prev = wrap.querySelector('.import-step[data-i="' + (i - 1) + '"]'); if (prev) prev.classList.add('done'); }
    if (i >= steps.length) {
      setTimeout(function () { try { wrap.remove(); } catch (e) {} if (onDone) onDone(); }, 350);
      return;
    }
    var cur = wrap.querySelector('.import-step[data-i="' + i + '"]'); if (cur) cur.classList.add('active');
    i++; setTimeout(tick, 520);
  };
  setTimeout(tick, 300);
}
function demoRoute() {
  // synthetische Demo-Lauf-Schleife (fiktive, neutrale Koordinaten — P2: keine personenbezogenen Geodaten)
  var pts = [], cx = 50.000, cy = 8.000, n = 90;
  for (var i = 0; i <= n; i++) {
    var t = i / n * Math.PI * 2;
    var r = 0.010 + 0.004 * Math.sin(t * 3) + 0.002 * Math.cos(t * 5);
    pts.push([cx + r * Math.sin(t) * 0.7, cy + r * Math.cos(t)]);
  }
  return pts;
}
function importDemoActivity() {
  if (window._importing) return;
  var k = (typeof todayStr === 'function') ? todayStr() : new Date().toISOString().slice(0, 10);
  var e = entry(k); e.sessions = e.sessions || {};
  if (e.sessions.Laufen && !e.sessions.Laufen.demo) {
    // P1A: native Browser-Bestätigung → orviaConfirm (destruktiv: überschreibt echten Lauf).
    if (typeof orviaConfirm === 'function') {
      orviaConfirm({ title: '' + _actT('act.lauf_ueberschreiben') + '', text: '' + _actT('act.heute_ist_bereits_ein_lauf') + '', okLabel: 'Überschreiben', danger: true, onOk: function () { e.sessions.Laufen = null; delete e.sessions.Laufen; importDemoActivity(); } });
      return;
    }
    return;
  }
  window._importing = true;
  importAnimation(
    ['' + _actT('act.aktivitaet_geladen') + '', '' + _actT('act.gps_route_geladen') + '', '' + _actT('act.pace_zonen_geprueft') + '', '' + _actT('act.herzfrequenz_analysiert') + '', '' + _actT('act.trainingslast_berechnet') + '', '' + _actT('act.tagesentscheidung_aktualisiert') + ''],
    function () {
      window._importing = false;
      e.sessions.Laufen = { dist: 7.2, dur: 43, hr: 149, elev: 54, rpe: 4, perf: 7, note: 'Demo-Import', route: demoRoute(), demo: true };
      e.sessions._ts = Date.now();
      if (typeof save === 'function') save();
      if (typeof renderDay === 'function') renderDay();
      renderAkt();
      openActivity(k, 'Laufen');
      if (typeof toast === 'function') toast('' + _actT('act.demo_aktivitaet_importiert') + '');
    }
  );
}

/* ---- Manuelle Aktivität (Inkrement 2A: dynamisch aus Nutzer-Sportauswahl + zentraler Form-Registry) ---- */
function _maTiles() {
  var sel = _userSportsSelection();
  var cfg = window.ORVIA && ORVIA.activityConfig;
  if (cfg) { var t = cfg.userSportTiles(sel); if (t && t.length > 1) return t; }
  // Fallback ohne Auswahl: Katalog-Standard (KEINE hart codierte Fünferliste im Renderpfad).
  return [{ sportId: 'running', label: 'Laufen' }, { sportId: 'gym', label: 'Krafttraining' }, { sportId: 'other', label: '' + _actT('act.weitere_aktivitaet_') + '', isMore: true }];
}
// onlyWhen-Bedingung erfüllt? (z. B. Höhenmeter nur outdoor, Beckenlänge nur Pool)
function _maFieldVisible(fld, vals) {
  if (!fld.onlyWhen) return true;
  return Object.keys(fld.onlyWhen).every(function (k) { return vals[k] === fld.onlyWhen[k]; });
}
// Felder eines Sport-Schemas als HTML. Enums = ORVIA-Segment-Buttons (keine nativen Selects, deutsche Labels).
function _maFieldsHTML(sportId, prevVals) {
  var cfg = ORVIA.activityConfig; var schema = cfg.formSchemaForSport(sportId); prevVals = prevVals || {};
  return schema.fields.filter(function (fld) { return _maFieldVisible(fld, prevVals); }).map(function (fld) {
    var v = prevVals[fld.key] != null ? prevVals[fld.key] : '';
    var id = 'ma_' + fld.key;
    var lab = fld.label + (fld.optional ? ' (optional)' : '');
    if (fld.type === 'date') return '<div class="gm-field"><label>' + escH(lab) + '</label><input type="date" id="' + id + '" value="' + escH(v || (typeof todayStr === 'function' ? todayStr() : '')) + '"></div>';
    if (fld.type === 'time') return '<div class="gm-field"><label>' + escH(lab) + '</label><input type="time" id="' + id + '" value="' + escH(v) + '"></div>';
    if (fld.type === 'enum') {
      if (!v) v = fld.options[0];   // Default = erste Option (kein leerer Rohwert)
      return '<div class="gm-field"><label>' + escH(lab) + '</label><div class="ob2-seg ma-seg" data-key="' + fld.key + '">' +
        fld.options.map(function (o) { return '<button type="button" class="ob2-segbtn' + (v === o ? ' on' : '') + '" data-v="' + escH(o) + '" onclick="maEnumPick(this)">' + escH(cfg.enumLabel(fld.key, o, sportId)) + '</button>'; }).join('') + '</div></div>';
    }
    if (fld.type === 'text') return '<div class="gm-field"><label>' + escH(lab) + '</label><input type="text" id="' + id + '" value="' + escH(v) + '"></div>';
    return '<div class="gm-field"><label>' + escH(lab) + '</label><input type="number" inputmode="decimal" id="' + id + '" value="' + escH(v) + '"></div>';
  }).join('');
}
function _maReadVals(sportId) {
  var cfg = ORVIA.activityConfig; var schema = cfg.formSchemaForSport(sportId); var out = {};
  schema.fields.forEach(function (fld) {
    if (fld.type === 'enum') { var seg = document.querySelector('.ma-seg[data-key="' + fld.key + '"] .on'); if (seg) out[fld.key] = seg.dataset.v; return; }
    var el = document.getElementById('ma_' + fld.key); if (!el) return; var val = (el.value || '').trim(); if (val === '') return;
    out[fld.key] = (fld.type === 'number') ? parseFloat(val.replace(',', '.')) : val;
  });
  return out;
}
function _maRerenderFields() { var box = document.getElementById('maFields'); if (box) box.innerHTML = _maFieldsHTML(window._maType, _maReadVals(window._maType)); }
// Enum-Auswahl (Segment): umschalten + neu rendern (gated Felder wie Höhenmeter/Beckenlänge reagieren).
function maEnumPick(el) {
  try { var p = el.parentNode; Array.prototype.forEach.call(p.children, function (c) { c.classList.remove('on'); el.removeAttribute && 0; }); } catch (e) {}
  el.classList.add('on');
  _maRerenderFields();
}
// 4d.1/4c.1c: Position aus dem Sportprofil vorausfüllen (alle Mannschaftssportarten; pro Aktivität änderbar).
var _TEAM_PREFILL_SPORTS = { football: 1, basketball: 1, handball: 1, volleyball: 1, hockey: 1, rugby: 1 };
function _maPrefillFor(sportId) {
  try {
    var s = window.ORVIA && ORVIA.profile && ORVIA.profile.sportById && ORVIA.profile.sportById(sportId);
    if (!s || !s.sportProfile) return {};
    if (_TEAM_PREFILL_SPORTS[sportId] && s.sportProfile.primaryPosition) return { position: s.sportProfile.primaryPosition };
    // 4c.1d Racketsport: Format (tennis/badminton) bzw. gespielte Seite (padel) vorausfüllen.
    var fld = s.sportProfile.fields || {}; var pf = {};
    if (sportId === 'tennis' && fld.mode && fld.mode !== 'beides') pf.format = fld.mode === 'Einzel' ? 'single' : 'double';
    if (sportId === 'badminton' && fld.format && ['Einzel', 'Doppel', 'Mixed'].indexOf(fld.format) >= 0) pf.format = fld.format === 'Einzel' ? 'single' : (fld.format === 'Doppel' ? 'double' : 'mixed');
    if (sportId === 'padel' && fld.side && fld.side !== 'Flexibel') pf.side = fld.side;
    return pf;
  } catch (e) { return {}; }
}
function openManualActivity(presetSportId) {
  var tiles = _maTiles().filter(function (t) { return !t.isMore; });   // direkte Typen = Nutzerauswahl
  window._maType = presetSportId || (tiles[0] && tiles[0].sportId) || 'other';
  var cfg = ORVIA.activityConfig;
  var chips = tiles.map(function (t) { return '<button type="button" class="gm-chip' + (t.sportId === window._maType ? ' on' : '') + '" data-v="' + escH(t.sportId) + '" onclick="maPickType(this)">' + escH(t.label) + '</button>'; }).join('') +
    '<button type="button" class="gm-chip gm-chip-more" onclick="openMoreActivityPicker()">' + _actT('act.weitere_aktivitaet') + '</button>';
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg';
  wrap.innerHTML = '<div class="orvia-modal goal-modal"><h3 id="maTitle">' + escH(cfg.activityTitle(window._maType)) + '</h3>' +
    '<p class="note" style="text-align:left;margin:-4px 0 12px">' + _actT('act.erfasse_die_werte_die_fuer') + '</p>' +
    '<div class="gm-field"><label>' + _actT('act.sportart') + '</label><div class="gm-chips" id="maType">' + chips + '</div></div>' +
    '<div id="maFields">' + _maFieldsHTML(window._maType, _maPrefillFor(window._maType)) + '</div>' +
    '<div class="ma-actions"><button class="btn" onclick="saveManualActivity()">' + _actT('act.speichern') + '</button>' +
    '<button class="btn sec" style="margin-top:10px" onclick="closeManualActivity()">' + _actT('act.abbrechen') + '</button></div></div>';
  document.body.appendChild(wrap); window._maModal = wrap;
  wrap.addEventListener('click', function (ev) { if (ev.target === wrap) closeManualActivity(); });
}
// Sportwechsel: Werte lesen, sportfremde Felder entfernen, Formular + Titel neu aufbauen.
function maPickType(el) {
  var prev = _maReadVals(window._maType);
  try { var p = el.parentNode; Array.prototype.forEach.call(p.children, function (c) { c.classList.remove('on'); }); el.classList.add('on'); } catch (e) {}
  window._maType = el.dataset.v;
  var kept = ORVIA.activityConfig.stripForeignFields(prev, window._maType);
  var pf = _maPrefillFor(window._maType); Object.keys(pf).forEach(function (k) { if (kept[k] == null) kept[k] = pf[k]; });
  var box = document.getElementById('maFields'); if (box) box.innerHTML = _maFieldsHTML(window._maType, kept);
  var t = document.getElementById('maTitle'); if (t) t.textContent = ORVIA.activityConfig.activityTitle(window._maType);
}
// Zweistufige „Weitere Aktivität": gruppierter Katalog (ohne bereits sichtbare Sportarten).
function openMoreActivityPicker() {
  var cfg = ORVIA.activityConfig;
  var visible = _maTiles().filter(function (t) { return !t.isMore; }).map(function (t) { return t.sportId; });
  var groups = cfg.moreActivityGroups(visible);
  var body = groups.map(function (g) {
    return '<div class="ma-group"><div class="ma-group-h">' + escH(g.label) + '</div><div class="gm-chips">' +
      g.items.map(function (it) { return '<button type="button" class="gm-chip" onclick="pickMoreActivity(\'' + escH(it.sportId) + '\')">' + escH(it.label) + '</button>'; }).join('') + '</div></div>';
  }).join('');
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg'; window._moreModal = wrap;
  wrap.innerHTML = '<div class="orvia-modal goal-modal"><h3>' + _actT('act.weitere_aktivitaet_auswaehlen') + '</h3>' + body +
    '<button class="btn sec" style="margin-top:12px" onclick="closeMorePicker()">' + _actT('act.zurueck') + '</button></div>';
  document.body.appendChild(wrap);
  wrap.addEventListener('click', function (ev) { if (ev.target === wrap) closeMorePicker(); });
}
function closeMorePicker() { if (window._moreModal) { try { window._moreModal.remove(); } catch (e) {} window._moreModal = null; } }
function pickMoreActivity(sportId) { closeMorePicker(); closeManualActivity(); openManualActivity(sportId); }
function closeManualActivity() { if (window._maModal) { try { window._maModal.remove(); } catch (e) {} window._maModal = null; } }
// F3: Auswahl bei wahrscheinlichem Duplikat (gleiche Einheit live + manuell/Import).
function showActivityDuplicate(date, typ, prior, dup) {
  var conf = dup && dup.confidence ? dup.confidence : 'mittel';
  var src = prior && prior.source === 'live' ? 'live erfasst' : (prior && prior.note) ? prior.note : 'bereits vorhanden';
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg'; window._maDup = wrap;
  wrap.innerHTML = '<div class="orvia-modal goal-modal"><h3>' + _actT('act.bereits_vorhanden') + '</h3>' +
    '<p class="modtext" style="margin:0 0 12px">' + _actT('act.dup_einheit_frage', { typ: '<b>' + escH(typ) + '</b>', date: escH(date), src: escH(src), conf: escH(conf) }) + '</p>' +
    '<button class="btn sec" onclick="dupOpenExisting(\'' + date + '\',\'' + typ + '\')">' + _actT('act.vorhandene_oeffnen') + '</button>' +
    '<button class="btn" style="margin-top:10px" onclick="dupMerge()">' + _actT('act.zusammenfuehren') + '</button>' +
    '<button class="btn sec" style="margin-top:10px" onclick="dupReplace(\'' + date + '\',\'' + typ + '\')">Trotzdem als neu speichern</button>' +
    '<button class="btn sec" style="margin-top:10px" onclick="dupCancel()">' + _actT('act.abbrechen') + '</button></div>';
  document.body.appendChild(wrap);
  wrap.addEventListener('click', function (ev) { if (ev.target === wrap) dupCancel(); });
}
function _closeDup() { if (window._maDup) { try { window._maDup.remove(); } catch (e) {} window._maDup = null; } }
function dupCancel() { _closeDup(); }
// GM7.5d: Cross-Source-Duplikatschutz (manuell vs. bereits kanonisch synchronisiert, z.B. Garmin).
// Reine Erkennung anhand vorhandener kanonischer Felder (source, sportId, startedAt) -- keine
// neue Aggregations-/Engine-Logik, kein neues Speicherformat.
function gmFindCrossSourceDuplicateActivity(date, sportId) {
  try {
    var st = window.ORVIA && ORVIA.activityStore; if (!st || !st.listActivities) return null;
    var acts = st.listActivities({ sportId: sportId }) || [];
    for (var i = 0; i < acts.length; i++) {
      var a = acts[i];
      if (a && a.source && a.source !== 'manual' && String(a.startedAt || '').slice(0, 10) === date) return a;
    }
  } catch (e) {}
  return null;
}
function showCrossSourceDuplicate(date, typ, act) {
  var src = ({ garmin: 'Garmin', strava: 'Strava', apple_health: '' + _actT('act.apple_health') + '' })[String(act.source || '').toLowerCase()] || act.source || '' + _actT('act.einer_anderen_quelle') + '';
  var wrap = document.createElement('div'); wrap.className = 'orvia-modal-bg'; window._maCrossDup = wrap;
  wrap.innerHTML = '<div class="orvia-modal goal-modal"><h3>' + _actT('act.bereits_synchronisiert') + '</h3>' +
    '<p class="modtext" style="margin:0 0 12px">' + _actT('act.dup_aktivitaet_hinweis', { typ: '<b>' + escH(typ) + '</b>', date: escH(date), src: escH(src) }) + '</p>' +
    '<button class="btn sec" onclick="_closeCrossDup()">' + _actT('act.abbrechen') + '</button>' +
    '<button class="btn" style="margin-top:10px" onclick="_crossDupForceSave()">' + _actT('act.trotzdem_speichern') + '</button></div>';
  document.body.appendChild(wrap);
  wrap.addEventListener('click', function (ev) { if (ev.target === wrap) _closeCrossDup(); });
}
function _closeCrossDup() { if (window._maCrossDup) { try { window._maCrossDup.remove(); } catch (e) {} window._maCrossDup = null; } }
function _crossDupForceSave() { _closeCrossDup(); window._maForce = true; saveManualActivity(); }
function dupOpenExisting(date, typ) { _closeDup(); closeManualActivity(); if (typeof openWorkoutCard === 'function') openWorkoutCard(date, typ); }
function dupMerge() { _closeDup(); window._maForce = true; saveManualActivity(); }        // Felder feldweise mergen
function dupReplace(date, typ) { _closeDup(); try { var e = entry(date); if (e.sessions) delete e.sessions[typ]; } catch (e2) {} window._maForce = true; saveManualActivity(); } // Slot ersetzen
function _numv(id) { var el = document.getElementById(id); if (!el || el.value === '') return null; var n = parseFloat(el.value.replace(',', '.')); return isNaN(n) ? null : n; }
function saveManualActivity() {
  var cfg = ORVIA.activityConfig;
  var sportId = window._maType || 'other';
  var vals = _maReadVals(sportId);
  var date = vals.date || (typeof todayStr === 'function' ? todayStr() : '');
  if (!isDay(date)) { if (typeof toast === 'function') toast('' + _actT('act.bitte_gueltiges_datum') + ''); return; }
  // Pflicht: Dauer ODER Distanz (Gym/Sonstige: Dauer reicht; Sonstige braucht zusätzlich Name).
  var dur = vals.durationMin != null ? vals.durationMin : null;
  var distKm = vals.distanceKm != null ? vals.distanceKm : null;
  var distM = vals.distanceM != null ? vals.distanceM : null;
  if (dur == null && distKm == null && distM == null) { if (typeof toast === 'function') toast('' + _actT('act.mindestens_dauer_oder_distanz') + ''); return; }
  if (sportId === 'other' && !vals.name) { if (typeof toast === 'function') toast('' + _actT('act.bitte_name_angeben') + ''); return; }
  var typ = cfg.sportLabel(sportId);                  // DB-Schlüssel = deutsches Label (kompatibel mit Edit/Move/openActivity)
  var e = entry(date); e.sessions = e.sessions || {};
  var prior = e.sessions[typ];
  var hasPrior = prior && ['dist', 'dur', 'hr', 'source', 'workoutSessionId'].some(function (k) { return prior[k] != null; });
  if (hasPrior && !window._maForce && typeof Calc !== 'undefined' && Calc.activityDuplicate) {
    var dup = Calc.activityDuplicate({ type: typ, date: date, dur: dur, dist: distKm != null ? distKm : (distM != null ? distM / 1000 : null) }, prior);
    if (dup && dup.match) { showActivityDuplicate(date, typ, prior, dup); return; }
  }
  // GM7.5d: Calc.activityDuplicate prueft ausschliesslich den Legacy-DB-Slot (e.sessions[typ]).
  // Eine bereits kanonisch vorhandene Aktivitaet aus einer ANDEREN Quelle (Garmin-/Server-Sync)
  // fuer denselben Tag+Sportart hat dort keinen Eintrag und wurde bislang gar nicht geprueft --
  // Duplikatschutz griff nur zwischen zwei manuellen/legacy Eingaben, nie Server<->manuell.
  if (!window._maForce) {
    var crossDup = gmFindCrossSourceDuplicateActivity(date, sportId);
    if (crossDup) { showCrossSourceDuplicate(date, typ, crossDup); return; }
  }
  window._maForce = false;
  // Schema → DB-Session (nur reale Werte; sportfremde Felder existieren dank Strip gar nicht erst).
  var s = Object.assign({}, e.sessions[typ] || {});
  if (dur != null) s.dur = Math.round(dur);
  if (distM != null) s.dist = distM; else if (distKm != null) s.dist = distKm;   // Schwimmen: Meter
  if (vals.avgHr != null) s.hr = Math.round(vals.avgHr);
  if (vals.elevationM != null) s.elev = Math.round(vals.elevationM); else delete s.elev;   // kein Alt-Höhenmeter bei sportfremd
  s.rpe = vals.rpe != null ? vals.rpe : (s.rpe != null ? s.rpe : 5);
  if (vals.note) s.note = vals.note; else s.note = s.note || 'Manuell';
  // Sportspezifische Extras roh sichern (für spätere Detail-Vertiefung), aber keine erfundenen Werte.
  ['environment', 'poolLengthM', 'stroke', 'sessionKind', 'format', 'role', 'result', 'avgSpeedKmh', 'avgPowerW', 'triType', 'discipline', 'name', 'time'].forEach(function (k) { if (vals[k] != null && vals[k] !== '') s[k] = vals[k]; });
  s.perf = s.perf != null ? s.perf : 6; s.sportId = sportId;
  // KANONISCH ZUERST: manuelle Activity in den Activity-Store (eine Wahrheit), dann Server-Sync.
  var canonId = null;
  try {
    if (window.ORVIA && ORVIA.activityStore && ORVIA.activityConfig) {
      var an = ORVIA.activityNormalize;
      var durSec = (dur != null) ? Math.round(dur * 60) : null;
      var summary = {};
      if (distKm != null) summary.distanceKm = distKm; if (distM != null) summary.distanceM = distM;
      if (vals.avgHr != null) summary.avgHr = Math.round(vals.avgHr);
      if (vals.elevationM != null && sportId !== 'swimming') summary.elevationM = Math.round(vals.elevationM);
      if (vals.rpe != null) summary.rpe = vals.rpe;
      var metrics = {};
      ['environment', 'poolLengthM', 'stroke', 'sessionKind', 'format', 'role', 'result', 'avgSpeedKmh', 'avgPowerW', 'triType', 'discipline', 'name', 'time'].forEach(function (k) { if (vals[k] != null && vals[k] !== '') metrics[k] = vals[k]; });
      var startedAt = date + 'T' + ((vals.time && /^\d{2}:\d{2}/.test(vals.time)) ? vals.time.slice(0, 5) : '00:00') + ':00';
      var ar = ORVIA.activityStore.upsertManualActivity({
        sportId: sportId, source: 'manual', sourceRecordId: 'manual:' + date + ':' + sportId,
        startedAt: startedAt, endedAt: null, durationSeconds: durSec, summary: summary, metrics: metrics
      });
      if (ar && ar.ok) canonId = ar.activity.clientRecordId;
    }
  } catch (e3) { try { console.error('[ORVIA activity] kanonische manuelle Activity fehlgeschlagen', e3); } catch (_) {} }
  // Legacy-DB-Eintrag nur noch als explizite PROJEKTION (Insights/Plan), keine zweite Wahrheit.
  if (canonId) { s.derivedFromActivity = true; s.canonicalActivityId = canonId; s.projectionType = 'legacy_db_projection'; }
  e.sessions[typ] = s; e.sessions._ts = Date.now();
  if (typeof save === 'function') save();
  closeManualActivity();
  if (typeof renderDay === 'function') renderDay();
  renderAkt();
  try { if (window.dispatchEvent) window.dispatchEvent(new CustomEvent('orvia:activity-updated', { detail: { activityId: canonId } })); } catch (e2) {}
  try { if (window.ORVIA && ORVIA.activitySync) ORVIA.activitySync.flushPendingActivities(); } catch (e4) {}   // Server-Sync anstoßen
  if (typeof toast === 'function') toast('' + _actT('act.aktivitaet_gespeichert') + '');
}
